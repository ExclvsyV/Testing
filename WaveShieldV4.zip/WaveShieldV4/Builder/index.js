const fs = require("fs");
const archiver = require("archiver");
const path = require("path");
const { exec } = require("child_process");
const { promisify } = require("util");
const { obfuscate, listOptions } = require("./luraph");

const execAsync = promisify(exec);

var isBETA = false;
var isDEV = false;
const args = process.argv.slice(2);
isBETA = args.includes("--beta");
isDEV = args.includes("--dev");

const GLOBAL_PATH = path.dirname(path.dirname(process.cwd()));
const DIR_PATH = GLOBAL_PATH + "/WaveShieldV4";
const clientsToMerge = [
  "luraphsdk.lua",
  "core/client/system/initializer.lua",
  "core/shared.lua",
  "core/encryption.lua",
  "core/client/system/debug.lua",
  "core/client/actorLoop.lua",
  "core/client/system/spawner.lua",
  "core/client/system/configUpdater.lua",
  "core/client/system/screenshots.lua",
  "core/client/system/webrtc.lua",
  "core/client/secured-events-list.lua",
  "modules/client/resourcesHandler.lua",
  "modules/client/execution.lua",
  "modules/heartbeat/client.lua",
  "modules/client/pedModel.lua",
  "modules/client/afkTasks.lua",
  "modules/client/antiExec.lua",
  "modules/client/entities.lua",
  "modules/client/events.lua",
  "modules/client/freecam.lua",
  "modules/client/godMode.lua",
  "modules/client/infiniteStamina.lua",
  "modules/client/invisible.lua",
  "modules/client/nightVisions.lua",
  "modules/client/teleport.lua",
  "modules/client/noclip.lua",
  "modules/client/noRagdoll.lua",
  "modules/client/spectate.lua",
  "modules/client/speedHack.lua",
  "modules/client/superJump.lua",
  "modules/client/textures.lua",
  "modules/client/inputBox.lua",
  "modules/client/sounds.lua",
  "modules/client/vehicles/teleportInVehicle.lua",
  "modules/client/vehicles/vehicleSpeed.lua",
  "modules/client/vehicles/vehicleModifications.lua",
  "modules/client/weapons/aimbot.lua",
  "modules/client/weapons/ammos.lua",
  "modules/client/weapons/hitbox.lua",
  "modules/client/weapons/pickups.lua",
  "modules/client/weapons/weaponDamages.lua",
  "modules/client/weapons/weaponSpawn.lua",
  "modules/client/misc.lua"
];

const serversToMerge = [
  "luraphsdk.lua",
  "core/server/system/initializer.lua",
  "core/shared.lua",
  "core/encryption.lua",
  "core/server/classes/cache.lua",
  "core/server/classes/player.lua",
  "core/server/classes/playerManager.lua",
  "core/server/utils.lua",
  "core/server/netApi.lua",
  "core/server/system/configUpdater.lua",
  "core/server/system/updater.lua",
  "core/server/system/webhooks.lua",
  "core/server/system/requirements.lua",
  "core/server/system/installer.lua",
  "core/server/system/logs.lua",
  "core/server/onLogIn.lua",
  "core/server/secured-events-list.lua",
  "modules/server/resourcesHandler.lua",
  "modules/server/autoWhiteList.lua",
  "modules/server/commands.lua",
  "modules/server/exploits-fixed.lua",
  "modules/heartbeat/server.lua",
  "modules/server/events/playerConnecting.lua",
  "modules/server/events/playerDropped.lua",
  "modules/server/events/chatMessage.lua",
  "modules/server/events/clearPedTasksEvent.lua",
  "modules/server/events/explosionEvent.lua",
  "modules/server/events/fireEvent.lua",
  "modules/server/events/ptFxEvent.lua",
  "modules/server/events/startProjectileEvent.lua",
  "modules/server/events/giveWeaponEvent.lua",
  "modules/server/events/removeWeaponEvent.lua",
  "modules/server/events/removeAllWeaponsEvent.lua",
  "modules/server/events/weaponDamageEvent.lua",
  "modules/server/events/givePedScriptedTaskEvent.lua",
  "modules/server/events/entityCreating.lua",
  "modules/server/events/entityCreated.lua",
  "modules/server/events/entityRemoved.lua",
  "modules/server/events/startNetworkSyncedSceneEvent.lua",
  "modules/server/events/premiumEvents.lua",
];

const exportsToMerge = [
  "luraphsdk.lua",
  "modules/server/anti-backdoors.lua",
];

const includesToMerge = [
  "luraphsdk.lua",
  "modules/include/shared.lua",
  "modules/include/client.lua",
  "modules/include/server.lua",
];

const filesToClone = [
  { source: "Public/fxmanifest.lua", destination: "Download/fxmanifest.lua" },
  { source: "Public/package.json", destination: "Download/package.json" },
  {
    source: "Public/auth/version.txt",
    destination: "Download/auth/version.txt",
  },
  {
    source: "Public/auth/license.txt",
    destination: "Download/auth/license.txt",
  },
  { source: "Auth/auth.lua", destination: "Files/auth.lua" },
  { source: "Load/modules/shared.js", destination: "Files/waveshield.js" },
  { source: "Public/fxmanifest.lua", destination: "Files/fxmanifest.lua" },
];

const filesToObfuscate = [
  "include.lua",
  "client.lua",
  "auth.lua",
  "server.lua",
  "exports.lua",
];

const filesToCopy = ["waveshield.js", "fxmanifest.lua"];

const webFiles = ["ui.html", "ui.js", "server.js"];

function readFile(path) {
  return fs.readFileSync(path, "utf8");
}

function writeFile(filename, content) {
  fs.writeFileSync(filename, content);
}

function copyFile(oldPath, newPath) {
  fs.copyFileSync(oldPath, newPath);
}

function deleteFile(path) {
  return fs.unlinkSync(path);
}

function deleteDirectory(dir) {
  if (fs.existsSync(dir)) fs.rmdirSync(dir, { recursive: true });
}

function mergeFiles(filesToMerge) {
  let filesMerged = "";

  filesToMerge.forEach((file) => {
    const filePath = `${DIR_PATH}/Source/Load/${file}`;
    const fileContent = readFile(filePath);
    filesMerged += fileContent + "\n\n";
  });

  return filesMerged;
}

function cloneFiles() {
  filesToClone.forEach((file) => {
    const oldPath = `${DIR_PATH}/Source/${file.source}`;
    const newPath = `${DIR_PATH}/${file.destination}`;
    copyFile(oldPath, newPath);
  });
}

async function obfuscateFiles() {
  for (const file of filesToObfuscate) {
    const filePath = `${DIR_PATH}/Files/${file}`;
    const fileContent = readFile(filePath);

    await obfuscate(fileContent, `${Date.now()}-${file}`, isBETA)
      .then((obfuscatedContent) => {
        writeFile(filePath, obfuscatedContent);
        console.log(`[*] Successfully obfuscated ${file}`);
      })
      .catch((error) =>
        console.error(`[*] Obfuscation failed for ${file}: ${error}`)
      );
  }
}

async function buildWebFiles() {
  if (isDEV) return true;

  console.log("Building web files...");

  try {
    const buildCommand = `cd ${GLOBAL_PATH}/waveshield-pkg && bun run build`;
    console.log(`Executing: ${buildCommand}`);

    const { stdout, stderr } = await execAsync(buildCommand);

    if (stdout) {
      console.log("Build output:", stdout);
    }

    if (stderr) {
      console.warn("Build warnings:", stderr);
    }

    console.log("✅ Web files built successfully");
    return true;
  } catch (error) {
    console.error("❌ Failed to build web files");
    return false;
  }
}

async function buildDownloadNodeModules() {
  try {
    const buildCommand = `cd ${DIR_PATH}/Download && npm install`;
    console.log(`Executing: ${buildCommand}`);

    const { stdout, stderr } = await execAsync(buildCommand);

    if (stdout) {
      console.log("Build output:", stdout);
    }

    if (stderr) {
      console.warn("Build warnings:", stderr);
    }

    console.log("✅ Download node modules built successfully");
    return true;
  } catch (error) {
    console.error("❌ Failed to build download node modules");
    return false;
  }
}

function copyFiles() {
  copyFile(
    `${DIR_PATH}/Files/auth.lua`,
    `${DIR_PATH}/Download/resource/server/auth.lua`
  );

  webFiles.forEach((file) => {
    copyFile(
      `${GLOBAL_PATH}/waveshield-pkg/dist/${file}`,
      `${DIR_PATH}/Files/${file}`
    );
  });

  if (!isDEV) {
    filesToObfuscate.forEach((file) => {
      if (isBETA) {
        copyFile(
          `${DIR_PATH}/Files/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/beta/${file}`
        );
      } else {
        copyFile(
          `${DIR_PATH}/Files/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/stable/${file}`
        );
      }
    });

    webFiles.forEach((file) => {
      if (isBETA) {
        copyFile(
          `${GLOBAL_PATH}/waveshield-pkg/dist/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/beta/${file}`
        );
      } else {
        copyFile(
          `${GLOBAL_PATH}/waveshield-pkg/dist/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/stable/${file}`
        );
      }
    });

    filesToCopy.forEach((file) => {
      if (isBETA) {
        copyFile(
          `${DIR_PATH}/Files/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/beta/${file}`
        );
      } else {
        copyFile(
          `${DIR_PATH}/Files/${file}`,
          `${GLOBAL_PATH}/waveshield-v3/apps/ingress-api/assets/stable/${file}`
        );
      }
    });
  }
}

function zipDownload() {
  const output = fs.createWriteStream(
    `${GLOBAL_PATH}/waveshield-v3/apps/server/assets/WaveShield.zip`
  );

  const archive = archiver("zip", { zlib: { level: 9 } });

  archive.pipe(output);
  archive.directory(`${DIR_PATH}/Download`, false);
  archive.finalize();
}

function buildZip() {
  const output = fs.createWriteStream(
    `${DIR_PATH}/Builds/WaveShield-Build-${Date.now()}${isDEV ? "-DEV" : ""}${
      isBETA ? "-BETA" : ""
    }.zip`
  );
  const archive = archiver("zip", { zlib: { level: 9 } });

  output.on("close", () => {
    console.log(`Written ${archive.pointer()} total bytes to zip file`);
    deleteDirectory(`${DIR_PATH}/Download`);
    deleteDirectory(`${DIR_PATH}/Files`);
  });

  archive.on("error", (err) => {
    console.error(err);
    deleteDirectory(`${DIR_PATH}/Download`);
    deleteDirectory(`${DIR_PATH}/Files`);
  });

  archive.pipe(output);
  archive.directory(`${DIR_PATH}/Download`, "Download");
  archive.directory(`${DIR_PATH}/Files`, "Files");
  archive.finalize();
}

async function main() {
  if (isBETA) console.log("BUILDING BETA...");

  const buildWebFilesResult = await buildWebFiles();
  if (!buildWebFilesResult) {
    return;
  }

  console.log("Merging files...");
  const clientsMerged = mergeFiles(clientsToMerge);
  const serversMerged = mergeFiles(serversToMerge);
  const exportsMerged = mergeFiles(exportsToMerge);
  const includeMerged = mergeFiles(includesToMerge);

  console.log("Deleting directories...");
  deleteDirectory(`${DIR_PATH}/Download`);
  deleteDirectory(`${DIR_PATH}/Files`);

  console.log("Creating directories...");
  fs.mkdirSync(`${DIR_PATH}/Download/resource/client`, { recursive: true });
  fs.mkdirSync(`${DIR_PATH}/Download/resource/server`, { recursive: true });
  fs.mkdirSync(`${DIR_PATH}/Download/auth`, { recursive: true });
  fs.mkdirSync(`${DIR_PATH}/Download/web`, { recursive: true });
  fs.mkdirSync(`${DIR_PATH}/Files`);

  console.log("Writing files...");
  writeFile(`${DIR_PATH}/Files/client.lua`, clientsMerged);
  writeFile(`${DIR_PATH}/Files/server.lua`, serversMerged);
  writeFile(`${DIR_PATH}/Files/exports.lua`, exportsMerged);
  writeFile(`${DIR_PATH}/Files/include.lua`, includeMerged);

  console.log("Cloning files...");
  cloneFiles();

  if (!isDEV) {
    console.log("Obfuscating files...");
    await obfuscateFiles();
  }

  console.log("Copying Files...");
  copyFiles();

  if (!isBETA) {
    console.log("building node_modules...");
    await buildDownloadNodeModules();

    console.log("zipping Download...");
    zipDownload();
  }

  console.log("Building zip...");
  buildZip();
}

main();
