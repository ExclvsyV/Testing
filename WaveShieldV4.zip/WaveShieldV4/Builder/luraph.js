const { Luraph } = require("luraph");

const apiKey = "cd5e9904b99785bc7266d44075b64b5f07b484fc96dff9c1221579dc5bd6ab8a";
const luraph = new Luraph(apiKey);

const listOptions = async () => {
	const nodes = await luraph.getNodes();
	console.log(`[*] recommended node: ${nodes.recommendedId}`);

	const node = nodes.nodes[nodes.recommendedId];
	console.log(`[*] cpu usage: ${node.cpuUsage}`);

	console.log("[*] options:");
	for (const [optionId, optionInfo] of Object.entries(node.options)) {
		console.log("  *", optionId, "-", optionInfo.name + ":");
		console.log("  |- desc:", optionInfo.description);
		console.log("  |- type:", optionInfo.type);
		console.log("  |- tier:", optionInfo.tier);
		console.log("  |- choices:", `[${optionInfo.choices.join(", ")}]`);
		console.log("  |- required:", optionInfo.required);
		if (optionInfo.dependencies) console.log("  |- dependencies: ", optionInfo.dependencies);
	}
};

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const obfuscate = async (script, fileName, isBeta) => {
	try {
		console.log("Obfuscating", fileName)
		const nodes = await luraph.getNodes();
		const { jobId } = await luraph.createNewJob(nodes.recommendedId, script, fileName, {
			TARGET_VERSION: "FiveM",
			INTENSE_VM_STRUCTURE: fileName.includes("include.lua") ? false : true,
			ENABLE_GC_FIXES: false,
			OPTIMIZATION_LEVEL: "Level 3",
			STATIC_ENVIRONMENT: false,
			VM_COMPRESSION: fileName.includes("include.lua") ? false : true,
			DISABLE_LINE_INFORMATION: fileName.includes("include.lua") ? true : false,
			USE_DEBUG_LIBRARY: false,
			ENABLE_FFI_LIBRARY: false,
			ENABLE_COMPATIBILITY_MODE: false,
			HARDCODE_GLOBALS: false,
		});

		const { success, error } = await luraph.getJobStatus(jobId);
		if (success) {
			const { fileName: resultName, data } = await luraph.downloadResult(jobId);
			return data;
		} else {
			throw error;
		}
	} catch (error) {
		console.error("Obfuscation failed", error)
		await sleep(15000);
		return obfuscate(script, fileName, isBeta)
	}
};

module.exports = { listOptions, obfuscate };
