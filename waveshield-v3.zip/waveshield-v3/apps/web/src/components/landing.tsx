﻿"use client";

import { Particles } from "@/components/magicui/particles";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
  CardFooter,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { authClient, signIn } from "@/lib/auth-client";
import {
  locales,
  useChangeLocale,
  useCurrentLocale,
  useScopedI18n,
} from "@/locales/client";
import { env } from "@/lib/env";
import { toast } from "sonner";
import { motion, useInView, useScroll, useTransform, useSpring } from "framer-motion";
import {
  ArrowRight,
  Brain,
  Check,
  CheckCircle,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  ExternalLink,
  Github,
  Languages,
  Menu,
  Monitor,
  Play,
  Plug2,
  Radar,
  ShieldCheck,
  Sparkles,
  Target,
  Users,
  X,
  Youtube,
  Zap,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { BorderBeam } from "./magicui/border-beam";
import { NeonGradientCard } from "./magicui/neon-gradient-card";
import { NumberTicker } from "./magicui/number-ticker";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import Link from "next/link";
import Image from "next/image";
import { LandingFAQSection } from "./faq-section";
import { cn } from "@/lib/utils";

// ... [Previous components remain unchanged: useDeviceDetection, DiscordIcon, AnimatedGridBackground, FloatingParticles, LanguageSwitcher, GlassmorphicNavbar, HeroSection, VideoModal, FeaturesSection, PaymentMethodModal]

// Performance optimization hook
const useDeviceDetection = () => {
  const [deviceInfo, setDeviceInfo] = useState({
    isMobile: false,
    reduceMotion: false,
  });

  useEffect(() => {
    const updateDeviceInfo = () => {
      setDeviceInfo({
        isMobile: window.innerWidth < 768,
        reduceMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches,
      });
    };

    updateDeviceInfo();
    const handleResize = () => updateDeviceInfo();

    window.addEventListener('resize', handleResize, { passive: true });
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return deviceInfo;
};

// Discord Icon Component (Memoized for performance)
const DiscordIcon = ({ className }: { className?: string }) => (
  <svg
    className={className}
    viewBox="0 0 24 24"
    fill="currentColor"
    xmlns="http://www.w3.org/2000/svg"
    aria-label="Discord"
  >
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
  </svg>
);

// Optimized animated grid background component
const AnimatedGridBackground = () => {
  const { isMobile, reduceMotion } = useDeviceDetection();

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      {/* Base gradient - simplified */}
      <div className="absolute inset-0 bg-gradient-to-br from-background via-blue-950/10 to-background" />

      {/* Static grid for mobile/reduced motion, animated for desktop */}
      {!isMobile && !reduceMotion ? (
        <motion.div
          className="absolute inset-0 opacity-8"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(59, 130, 246, 0.25) 1px, transparent 0)`,
            backgroundSize: "60px 60px",
            willChange: "transform",
            transform: "translateZ(0)", // Hardware acceleration
          }}
          animate={{
            backgroundPosition: ["0% 0%", "100% 100%"],
          }}
          transition={{
            duration: 60, // Slower for better performance
            repeat: Infinity,
            ease: "linear",
          }}
        />
      ) : (
        <div
          className="absolute inset-0 opacity-4 md:opacity-6"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, rgba(59, 130, 246, 0.15) 1px, transparent 0)`,
            backgroundSize: isMobile ? "80px 80px" : "60px 60px",
          }}
        />
      )}

      {/* Simplified spotlight effects */}
      {!isMobile && (
        <>
          <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl" />
          <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />
        </>
      )}

      {/* Single gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-transparent to-background/70" />
    </div>
  );
};

// Optimized floating particles - only for desktop, non-reduced motion
const FloatingParticles = () => {
  const { isMobile, reduceMotion } = useDeviceDetection();

  if (isMobile || reduceMotion) return null;

  const particles = Array.from({ length: 8 }, (_, i) => i); // Further reduced for performance

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map((particle) => (
        <motion.div
          key={particle}
          className="absolute w-1 h-1 bg-blue-400/15 rounded-full"
          style={{
            willChange: "transform",
            transform: "translateZ(0)", // Force hardware acceleration
          }}
          initial={{
            x: typeof window !== "undefined" ? Math.random() * window.innerWidth : 0,
            y: typeof window !== "undefined" ? Math.random() * window.innerHeight : 0,
            opacity: 0,
          }}
          animate={{
            x: typeof window !== "undefined" ? Math.random() * window.innerWidth : 0,
            y: typeof window !== "undefined" ? Math.random() * window.innerHeight : 0,
            opacity: [0, 0.3, 0],
          }}
          transition={{
            duration: Math.random() * 15 + 20, // Even slower for better performance
            repeat: Infinity,
            ease: "linear",
            repeatDelay: Math.random() * 5, // Add variation
          }}
        />
      ))}
    </div>
  );
};

const LanguageSwitcher = () => {
  const changeLocale = useChangeLocale();
  const currentLocale = useCurrentLocale();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full text-muted-foreground hover:text-primary hover:bg-primary/10 transition-colors"
          aria-label="Change language"
        >
          <Languages className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className="bg-background/95 backdrop-blur-xl border-border"
      >
        {locales.map((locale) => (
          <DropdownMenuItem
            key={locale.code}
            onClick={() => changeLocale(locale.code)}
            className="gap-3"
          >
            <span className="text-sm font-medium">{locale.name}</span>
            {currentLocale === locale.code && (
              <Check className="ml-auto h-3 w-3 text-primary" />
            )}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

// Glassmorphic Navbar - Redesigned
const GlassmorphicNavbar = () => {
  const t = useScopedI18n("landing");
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeTab, setActiveTab] = useState("Home");
  const [isManualSelection, setIsManualSelection] = useState(false);
  const { data: session } = authClient.useSession();

  useEffect(() => {
    let ticking = false;

    const handleScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => {
          setScrolled(window.scrollY > 20);

          if (!isManualSelection) {
            const sections = ["home", "features", "pricing", "faqs"];
            let current = null;
            let minDistance = Infinity;

            sections.forEach((section) => {
              const element = document.getElementById(section);
              if (element) {
                const rect = element.getBoundingClientRect();
                const elementCenter = rect.top + rect.height / 2;
                const viewportCenter = window.innerHeight / 2;
                const distance = Math.abs(elementCenter - viewportCenter);

                if (
                  rect.top < window.innerHeight &&
                  rect.bottom > 0 &&
                  distance < minDistance
                ) {
                  minDistance = distance;
                  current = section;
                }
              }
            });

            if (current) {
              const tabName =
                current === "faqs"
                  ? t("nav.faqs")
                  : current === "home"
                    ? t("nav.home")
                    : current === "features"
                      ? t("nav.features")
                      : current === "pricing"
                        ? t("nav.pricing")
                        : current;
              setActiveTab(tabName);
            }
          }
          ticking = false;
        });
        ticking = true;
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [isManualSelection, t]);

  const handleManualTabSelect = (item: string) => {
    setActiveTab(item);
    setIsManualSelection(true);
    setIsOpen(false);
    setTimeout(() => setIsManualSelection(false), 2000);
  };

  const navItems = [
    { key: "home", label: t("nav.home") },
    { key: "features", label: t("nav.features") },
    { key: "pricing", label: t("nav.pricing") },
    { key: "faqs", label: t("nav.faqs") },
  ];

  return (
    <motion.nav
      className={cn(
        "fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-300 rounded-full px-4 py-2",
        scrolled
          ? "bg-background/80 backdrop-blur-md border border-border shadow-md w-[calc(100%-2rem)] max-w-5xl"
          : "bg-transparent border border-transparent w-full max-w-6xl"
      )}
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <Image
            src="/logo.webp"
            alt="Logo"
            width={32}
            height={32}
            className="w-8 h-8 rounded-lg"
          />
          <span className={cn("font-bold text-lg hidden md:block", scrolled ? "opacity-100" : "opacity-0 md:opacity-100 transition-opacity")}>
            WaveShield
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const isActive = activeTab === item.label;
            return (
              <Link
                key={item.key}
                href={`#${item.key}`}
                className={cn(
                  "text-sm font-medium px-4 py-2 rounded-full transition-all duration-200 relative",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary/50"
                )}
                onClick={(e) => {
                  e.preventDefault();
                  document.getElementById(item.key)?.scrollIntoView({ behavior: 'smooth' });
                  handleManualTabSelect(item.label);
                }}
              >
                {item.label}
                {isActive && (
                  <motion.div
                    layoutId="navbar-indicator"
                    className="absolute inset-0 rounded-full bg-primary/10 -z-10"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                  />
                )}
              </Link>
            );
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <div className="hidden md:block">
            <LanguageSwitcher />
          </div>

          <motion.button
            className="group relative px-6 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white text-sm font-medium rounded-full shadow-md hover:shadow-lg transition-all duration-200 overflow-hidden border-0 cursor-pointer"
            onClick={() => {
              if (session?.user.id) {
                window.location.href = "/dashboard";
              } else {
                signIn();
              }
            }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            {session?.user.id ? t("nav.panel") : t("nav.signin")}
          </motion.button>

          {/* Mobile Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden rounded-full"
            onClick={() => setIsOpen(!isOpen)}
          >
            {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          className="absolute top-full left-0 right-0 mt-2 p-4 bg-background/95 backdrop-blur-xl border border-border rounded-2xl shadow-xl flex flex-col gap-2 md:hidden"
          initial={{ opacity: 0, y: -10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.95 }}
        >
          {navItems.map((item) => (
            <a
              key={item.key}
              href={`#${item.key}`}
              className={cn(
                "p-3 rounded-xl text-sm font-medium transition-colors text-center",
                activeTab === item.label
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-secondary"
              )}
              onClick={() => handleManualTabSelect(item.label)}
            >
              {item.label}
            </a>
          ))}
          <div className="flex justify-center pt-2">
            <LanguageSwitcher />
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

// Hero Section - Mobile Optimized with SEO enhancements
const HeroSection = () => {
  const t = useScopedI18n("landing");
  const ref = useRef(null);
  const { scrollY } = useScroll();

  // Use optimized device detection hook
  const { isMobile, reduceMotion } = useDeviceDetection();

  // Effects for the Hero content
  // Desktop only: Opacity and Scale fade out and shrink as user scrolls down
  // Mobile: No scroll effects, normal behavior
  const textOpacity = useTransform(scrollY, [0, 400],
    isMobile || reduceMotion ? [1, 1] : [1, 0]);

  const textScale = useTransform(scrollY, [0, 400],
    isMobile || reduceMotion ? [1, 1] : [1, 0.85]);

  // Pointer events: disable when faded out so panel is interactive
  // z-index: hero content starts above panel, goes below as it fades
  const textZIndex = useTransform(scrollY, [0, 200],
    isMobile || reduceMotion ? [30, 30] : [30, 10]);
  const textPointerEvents = useTransform(scrollY, (value) =>
    isMobile || reduceMotion ? "auto" : (value > 200 ? "none" : "auto"));

  // Snap hero content up on first scroll with smooth spring animation
  const textYRaw = useTransform(scrollY, [0, 1, 150],
    isMobile || reduceMotion ? [0, 0, 0] : [0, -60, -60]);
  const textY = useSpring(textYRaw, { stiffness: 300, damping: 30 });

  // Panel Parallax: Desktop only
  const panelY = useTransform(scrollY, [0, 1000],
    isMobile || reduceMotion ? [0, 0] : [0, -250]);

  return (
    <section
      id="home"
      ref={ref}
      className="relative min-h-screen md:min-h-[140vh] px-4 md:px-6"
    >
      {/* SEO-friendly header structure */}
      <header className="sr-only">
        <h1>WaveShield - Best FiveM Anticheat 2025</h1>
        <p>Advanced FiveM server protection and cheat detection system</p>
      </header>

      {/* ... Schema ... */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            "name": "WaveShield FiveM Anticheat",
            "description": "WaveShield is the best FiveM anticheat solution in 2025. Protect your FiveM server with advanced cheat detection, real-time monitoring, and comprehensive player intelligence. Trusted by 10,000+ servers worldwide. Easy setup, powerful protection.",
            "applicationCategory": "SecurityApplication",
            "operatingSystem": "Windows, Linux",
            "offers": {
              "@type": "Offer",
              "price": "50",
              "priceCurrency": "EUR",
              "availability": "https://schema.org/InStock"
            },
            "aggregateRating": {
              "@type": "AggregateRating",
              "ratingValue": "4.8",
              "reviewCount": "1247"
            },
            "publisher": {
              "@type": "Organization",
              "name": "WaveShield",
              "url": "https://waveshield.xyz"
            }
          })
        }}
      />

      {/* Background - Grid lines and particles - Only for hero section */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <div
          className="absolute inset-0 opacity-5 md:opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(59, 130, 246, 0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(59, 130, 246, 0.3) 1px, transparent 1px)
            `,
            backgroundSize: "60px 60px",
          }}
        />

        {/* MagicUI Particles - Optimized for performance */}
        <Particles
          className="absolute inset-0"
          quantity={
            typeof window !== "undefined" && window.innerWidth < 768 ? 30 : 80
          }
          ease={60}
          color="#3b82f6"
          size={0.4}
          staticity={70}
        />
      </div>

      {/* Text Content - Fixed on desktop, scrollable on mobile */}
      <motion.div
        className={cn(
          "text-center max-w-4xl mx-auto w-full px-4 md:px-6",
          // Mobile: relative positioning, scrolls normally
          // Desktop: fixed positioning with parallax effect
          "relative pt-24 pb-8 md:pt-0 md:pb-0",
          "md:fixed md:top-[36%] md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2"
        )}
        style={{
          opacity: textOpacity,
          scale: textScale,
          y: textY,
          zIndex: textZIndex,
          pointerEvents: textPointerEvents
        }}
      >
        {/* Enhanced Badge - Mobile Responsive */}
        <motion.div
          className="flex justify-center mb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          style={{ willChange: "transform, opacity" }}
        >
          <Badge className="bg-blue-500/10 text-blue-400 border-blue-500/20 px-3 md:px-4 py-1 md:py-2 text-xs md:text-sm font-medium rounded-full">
            {!reduceMotion && (
              <motion.div
                animate={{
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.05, 1],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                style={{ willChange: "transform" }}
              >
                <Sparkles
                  className="w-3 h-3 md:w-4 md:h-4 mr-2"
                  aria-hidden="true"
                />
              </motion.div>
            )}
            {reduceMotion && (
              <Sparkles
                className="w-3 h-3 md:w-4 md:h-4 mr-2"
                aria-hidden="true"
              />
            )}
            {t("hero.badge")}
          </Badge>
        </motion.div>

        {/* Main Headline - SEO Optimized */}
        <motion.div
          className="text-4xl md:text-5xl lg:text-5xl font-bold mb-4 leading-tight"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          style={{ willChange: "transform, opacity" }}
        >
          <h1 className="framer-text">
            <span className="bg-gradient-to-br from-white via-white to-gray-400 bg-clip-text text-transparent">
              {t("hero.title")} {" "}
            </span>
            <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              WaveShield
            </span>
          </h1>
        </motion.div>

        {/* Subtext - SEO Enhanced */}
        <motion.p
          className="text-sm sm:text-base md:text-xl mb-6 md:mb-8 max-w-3xl mx-auto text-gray-300"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          style={{ willChange: "transform, opacity" }}
        >
          {t("hero.subtitle")}
        </motion.p>

        {/* CTA Buttons - Clean Professional Design */}
        <motion.div
          className="flex flex-col sm:flex-row gap-4 items-center justify-center"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          style={{ willChange: "transform, opacity" }}
        >
          <motion.button
            className="group relative w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-medium rounded-4xl shadow-md hover:shadow-lg transition-all duration-200 overflow-hidden border-0 cursor-pointer"
            onClick={() => {
              document.getElementById("pricing")?.scrollIntoView({
                behavior: "smooth",
              });
            }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            aria-label="Get started with WaveShield FiveM anticheat"
          >
            <span className="relative flex items-center justify-center gap-2">
              {t("hero.get_started")}
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
            </span>
          </motion.button>

          <Link href="/dashboard/server/demo" className="w-full sm:w-auto">
            <motion.button
              className="group relative w-full px-6 py-2.5 border-2 bg-white/5 text-white border-white/10 backdrop-blur-md font-medium rounded-4xl transition-all duration-200 cursor-pointer overflow-hidden"
              initial="initial"
              whileHover="hover"
              whileTap={{ scale: 0.98 }}
              variants={{
                initial: { scale: 1 },
                hover: { scale: 1.02, transition: { duration: 0.2 } }
              }}
              aria-label="Learn more about WaveShield anticheat features"
            >
              <span className="relative z-10 flex items-center justify-center gap-2">
                <ExternalLink className="h-4 w-4" />
                {t("hero.try_demo")}
              </span>
              <motion.div
                className="absolute top-0 left-0 w-[60%] h-full bg-gradient-to-r from-transparent via-white/20 to-transparent"
                variants={{
                  initial: { x: '-100%', skewX: -30, opacity: 0 },
                  hover: {
                    x: '250%',
                    skewX: -30,
                    opacity: 1,
                    transition: {
                      x: {
                        repeat: Infinity,
                        duration: 1.2,
                        ease: "linear"
                      },
                      opacity: {
                        duration: 0
                      }
                    }
                  }
                }}
              />
            </motion.button>
          </Link>
        </motion.div>
      </motion.div>

      {/* Dashboard Panel - Positioned below hero text on mobile, parallax on desktop */}
      <motion.div
        className="relative w-full max-w-5xl md:max-w-7xl mx-auto z-20 pt-4 md:pt-[60vh] pb-16 md:pb-0"
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        style={{ willChange: "transform", y: panelY }}
      >
        <div className="relative group">
          {/* Glow effect - contained around the panel only */}
          <div className="absolute -inset-4 md:-inset-8">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 md:from-blue-500/40 via-cyan-400/20 md:via-cyan-400/40 to-blue-500/20 md:to-blue-500/40 blur-2xl md:blur-3xl animate-pulse rounded-3xl" />
          </div>

          <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 via-cyan-400 to-blue-500 rounded-2xl md:rounded-3xl blur-sm opacity-50 md:opacity-75" />

          <div className="relative bg-gradient-to-br from-background/95 to-background/90 rounded-xl md:rounded-2xl p-1 md:p-2 backdrop-blur-xl border border-blue-500/20">
            <div className="relative overflow-hidden rounded-lg md:rounded-xl">
              <Image
                src="/panel.webp"
                alt="WaveShield FiveM anticheat dashboard interface showing real-time player monitoring, ban statistics, and server security analytics"
                className="w-full h-auto shadow-2xl"
                style={{
                  filter: "drop-shadow(0 15px 35px rgba(59, 130, 246, 0.3))",
                }}
                priority
                width={1200}
                height={630}
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 90vw, 1200px"
                quality={85}
                placeholder="blur"
                fetchPriority="high"
                blurDataURL="data:image/webp;base64,UklGRpwAAABXRUJQVlA4IJAAAABwAQCdASoKAAYAAUAmJQBOgB7gAnQA/g7J+EX8T/9v/4+/j/+Pv4//j7+P/4+/j/+Pv4//j7+P/4+/j/+Pv4//j7+P/4+/j/+Pv4//j7+P/4+/j/+Pv4//j7+P/4+/j/+Pv4//j7+P/4+/j/+PAAA"
              />

              {/* Hover Overlay with Try Demo Button */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center z-10">
                <Link href="/dashboard/server/demo">
                  <motion.button
                    className="group/btn relative px-6 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer border border-blue-400/30 overflow-hidden"
                    initial="initial"
                    whileHover="hover"
                    whileTap={{ scale: 0.95 }}
                    variants={{
                      initial: { scale: 1, y: 0, opacity: 1 },
                      hover: { scale: 1.05, transition: { duration: 0.2 } }
                    }}
                    aria-label="Try WaveShield demo dashboard"
                  >
                    <span className="relative z-10 flex items-center gap-2">
                      <ExternalLink className="h-5 w-5 transition-transform group-hover/btn:translate-x-0.5" />
                      {t("hero.try_demo")}
                    </span>
                    <motion.div
                      className="absolute top-0 left-0 w-[60%] h-full bg-gradient-to-r from-transparent via-white/30 to-transparent"
                      variants={{
                        initial: { x: '-100%', skewX: -30, opacity: 0 },
                        hover: {
                          x: '250%',
                          skewX: -30,
                          opacity: 1,
                          transition: {
                            x: {
                              repeat: Infinity,
                              duration: 1.2,
                              ease: "linear"
                            },
                            opacity: {
                              duration: 0
                            }
                          }
                        }
                      }}
                    />
                  </motion.button>
                </Link>
              </div>

              {/* Subtle gradient overlay - only visible when not hovering */}
              <div className="absolute inset-0 rounded-lg md:rounded-xl bg-gradient-to-t from-blue-950/10 via-transparent to-transparent pointer-events-none group-hover:opacity-0 transition-opacity duration-300" />
            </div>
          </div>
        </div>
      </motion.div>

      {/* Seamless Gradient Transition */}
      <div className="absolute bottom-0 left-0 right-0 h-96 bg-gradient-to-b from-transparent via-transparent to-background pointer-events-none z-20" />
      <div className="absolute bottom-0 left-0 right-0 h-64 bg-gradient-to-b from-transparent via-background/40 to-background pointer-events-none z-20" />
    </section>
  );
};

// Video Modal Component
const VideoModal = ({
  isOpen,
  onClose,
  youtubeUrl,
  title
}: {
  isOpen: boolean;
  onClose: () => void;
  youtubeUrl: string;
  title: string;
}) => {
  // Extract video ID from YouTube URL
  const getYouTubeVideoId = (url: string) => {
    const regex = /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/;
    const match = url.match(regex);
    return match ? match[1] : null;
  };

  const videoId = getYouTubeVideoId(youtubeUrl);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl w-full p-0 bg-background/95 backdrop-blur-xl border border-white/10">
        <DialogHeader className="p-6 pb-0">
          <DialogTitle className="text-white text-lg font-semibold flex items-center">
            <Play className="h-5 w-5 text-red-400 mr-2" />
            {title} - Demo Video
          </DialogTitle>
        </DialogHeader>

        <div className="p-6 pt-4">
          {videoId ? (
            <div className="relative w-full" style={{ paddingBottom: '56.25%' /* 16:9 aspect ratio */ }}>
              <iframe
                className="absolute top-0 left-0 w-full h-full rounded-lg"
                src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`}
                title={`${title} Demo Video`}
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 bg-gray-800/50 rounded-lg">
              <p className="text-muted-foreground">Invalid YouTube URL</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Features Section - SEO Enhanced
const FeaturesSection = () => {
  const t = useScopedI18n("landing");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [videoModal, setVideoModal] = useState<{
    isOpen: boolean;
    youtubeUrl: string;
    title: string;
  }>({
    isOpen: false,
    youtubeUrl: '',
    title: '',
  });

  const openVideoModal = (youtubeUrl: string, title: string) => {
    setVideoModal({
      isOpen: true,
      youtubeUrl,
      title,
    });
  };

  const closeVideoModal = () => {
    setVideoModal({
      isOpen: false,
      youtubeUrl: '',
      title: '',
    });
  };

  const features = [
    {
      icon: Monitor,
      title: t("features.list.web_panel.title"),
      description: t("features.list.web_panel.description"),
      color: "from-blue-500 to-cyan-500",
    },
    {
      icon: Brain,
      title: t("features.list.network_intelligence.title"),
      description: t("features.list.network_intelligence.description"),
      color: "from-purple-500 to-pink-500",
    },
    {
      icon: Plug2,
      title: t("features.list.plug_play.title"),
      description: t("features.list.plug_play.description"),
      color: "from-green-500 to-emerald-500",
      youtubeUrl: "https://www.youtube.com/watch?v=XwDB0L01EBI",
    },
    {
      icon: Target,
      title: t("features.list.anti_aimbot.title"),
      description: t("features.list.anti_aimbot.description"),
      color: "from-red-500 to-orange-500",
      youtubeUrl: "https://www.youtube.com/watch?v=-ujLra-sWqM",
    },
    {
      icon: ShieldCheck,
      title: t("features.list.event_protection.title"),
      description: t("features.list.event_protection.description"),
      color: "from-cyan-500 to-blue-500",
    },
    {
      icon: Radar,
      title: t("features.list.advanced_detections.title"),
      description: t("features.list.advanced_detections.description"),
      color: "from-yellow-500 to-amber-500",
    },
  ];

  return (
    <section
      id="features"
      ref={ref}
      className="relative pt-16 md:pt-24 pb-16 md:pb-24 px-4 md:px-6 bg-background -mt-16 md:-mt-32"
    >
      <div className="max-w-7xl mx-auto relative z-30">
        <motion.div
          className="text-center mb-12 md:mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 md:mb-6 bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
            {t("features.title")}
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            {t("features.subtitle")}
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {features.map((feature, index) => (
            <motion.article
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                duration: 0.4,
                delay: index * 0.05,
                ease: "easeOut"
              }}
              className="h-full"
              style={{ willChange: "transform, opacity" }}
            >
              <NeonGradientCard
                neonColors={{
                  firstColor: "#8b5cf6",
                  secondColor: "#00ffff",
                }}
                cardBackground="bg-neutral-950"
              >
                <div className="relative">
                  <div className="flex items-center mb-3 md:mb-4">
                    <div
                      className={`w-8 h-8 md:w-10 md:h-10 rounded-lg bg-gradient-to-r ${feature.color} flex items-center justify-center mr-3`}
                    >
                      <feature.icon
                        className="h-4 w-4 md:h-5 md:w-5 text-white"
                        aria-hidden="true"
                      />
                    </div>
                    <CardTitle className="text-white text-base md:text-lg font-semibold flex-1">
                      {feature.title}
                    </CardTitle>

                    {/* YouTube Video Button */}
                    {feature.youtubeUrl && (
                      <motion.button
                        onClick={() => openVideoModal(feature.youtubeUrl!, feature.title)}
                        className="group relative w-8 h-8 md:w-9 md:h-9 rounded-full bg-red-600/20 hover:bg-red-600/30 border border-red-500/30 hover:border-red-500/50 flex items-center justify-center transition-all duration-300 ml-2"
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                        aria-label={`Watch ${feature.title} demo video`}
                      >
                        <Play className="h-3 w-3 md:h-4 md:w-4 text-red-400 group-hover:text-red-300 transition-colors duration-200 ml-0.5" />

                        {/* Subtle glow effect */}
                        <div className="absolute inset-0 rounded-full bg-red-500/20 opacity-0 group-hover:opacity-100 blur-sm transition-opacity duration-300" />

                        {/* Tooltip */}
                        <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-all duration-200 pointer-events-none">
                          <div className="bg-background/90 backdrop-blur-sm text-white text-xs px-2 py-1 rounded border border-white/10 whitespace-nowrap">
                            Watch Demo
                            <div className="absolute top-full right-3 w-0 h-0 border-l-2 border-r-2 border-t-2 border-transparent border-t-white/10"></div>
                          </div>
                        </div>
                      </motion.button>
                    )}
                  </div>

                  <CardDescription className="text-gray-300 leading-relaxed text-sm flex-1">
                    {feature.description}
                  </CardDescription>

                  {/* Optional: Video preview indicator */}
                  {feature.youtubeUrl && (
                    <div className="mt-3 flex items-center text-xs text-red-400/80">
                      <Play className="h-3 w-3 mr-1" />
                      <span>Video demo available</span>
                    </div>
                  )}
                </div>
              </NeonGradientCard>
            </motion.article>
          ))}
        </div>

        {/* Video Modal */}
        <VideoModal
          isOpen={videoModal.isOpen}
          onClose={closeVideoModal}
          youtubeUrl={videoModal.youtubeUrl}
          title={videoModal.title}
        />
      </div>
    </section>
  );
};

// Payment Method Selection Modal Component
const PaymentMethodModal = ({
  isOpen,
  onClose,
  planId,
  planName,
  planPrice
}: {
  isOpen: boolean;
  onClose: () => void;
  planId: string;
  planName: string;
  planPrice: string;
}) => {
  const t = useScopedI18n("landing");
  const { isMobile } = useDeviceDetection();
  const [selectedMethod, setSelectedMethod] = useState<'card' | 'crypto' | null>(null);
  const [customerEmail, setCustomerEmail] = useState('');
  const [discountCode, setDiscountCode] = useState('');
  const [isCollectingEmail, setIsCollectingEmail] = useState(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [isValidatingDiscount, setIsValidatingDiscount] = useState(false);
  const [discountError, setDiscountError] = useState('');
  const [acceptedTerms, setAcceptedTerms] = useState(true);
  const [priceDetails, setPriceDetails] = useState<{
    originalPrice: number;
    discountAmount: number;
    finalPrice: number;
    discount?: {
      id: string;
      code: string;
      type: string;
      description?: string | null;
    };
  } | null>(null);
  const [hasCheckedGlobalDiscount, setHasCheckedGlobalDiscount] = useState(false);
  const [embeddedCheckoutUrl, setEmbeddedCheckoutUrl] = useState<string | null>(null);
  const [isIframeLoading, setIsIframeLoading] = useState(false);
  const [iframeError, setIframeError] = useState(false);

  // Reset modal state when modal opens/closes
  useEffect(() => {
    if (!isOpen) {
      // Reset all state when modal closes
      setSelectedMethod(null);
      setCustomerEmail('');
      setDiscountCode('');
      setIsCollectingEmail(false);
      setIsProcessingPayment(false);
      setIsValidatingDiscount(false);
      setDiscountError('');
      setAcceptedTerms(true);
      setPriceDetails(null);
      setHasCheckedGlobalDiscount(false);
      setEmbeddedCheckoutUrl(null);
      setIsIframeLoading(false);
      setIframeError(false);
    }
  }, [isOpen]);

  // Fetch and apply global discount when modal opens
  useEffect(() => {
    const fetchGlobalDiscount = async () => {
      if (!isOpen || hasCheckedGlobalDiscount) return;

      try {
        const response = await fetch(`${env.API_URL}/trpc/discounts.getGlobalDiscount`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        const data = await response.json();
        if (response.ok && data.result?.data) {
          const globalDiscount = data.result.data;
          console.log('Global discount found in modal:', globalDiscount);

          // Set the discount code automatically
          setDiscountCode(globalDiscount.code);

          // Validate it immediately to show pricing
          const validateResponse = await fetch(
            `${env.API_URL}/trpc/discounts.validateDiscount?input=${encodeURIComponent(
              JSON.stringify({ code: globalDiscount.code, planId })
            )}`,
            {
              method: 'GET',
              headers: {
                'Content-Type': 'application/json',
              },
              credentials: 'include',
            }
          );

          const validateData = await validateResponse.json();
          if (validateResponse.ok && validateData.result?.data) {
            setPriceDetails({
              originalPrice: validateData.result.data.originalPrice,
              discountAmount: validateData.result.data.discountAmount,
              finalPrice: validateData.result.data.finalPrice,
              discount: validateData.result.data.discount,
            });
          }
        }

        setHasCheckedGlobalDiscount(true);
      } catch (error) {
        console.error('Error fetching global discount in modal:', error);
        setHasCheckedGlobalDiscount(true);
      }
    };

    fetchGlobalDiscount();
  }, [isOpen, hasCheckedGlobalDiscount, planId]);

  // Validate discount code when user types (or removes it)
  useEffect(() => {
    const validateDiscountCode = async () => {
      // If discount code is empty or too short, clear the discount
      if (!discountCode || discountCode.trim().length < 3) {
        setPriceDetails(null);
        setDiscountError('');
        return;
      }

      setIsValidatingDiscount(true);
      setDiscountError('');

      try {
        const response = await fetch(
          `${env.API_URL}/trpc/discounts.validateDiscount?input=${encodeURIComponent(
            JSON.stringify({ code: discountCode.trim(), planId })
          )}`,
          {
            method: 'GET',
            headers: {
              'Content-Type': 'application/json',
            },
            credentials: 'include',
          }
        );

        const data = await response.json();

        if (!response.ok) {
          setDiscountError(t("pricing.discount.invalid"));
          setPriceDetails(null);
        } else if (data.result?.data) {
          setPriceDetails({
            originalPrice: data.result.data.originalPrice,
            discountAmount: data.result.data.discountAmount,
            finalPrice: data.result.data.finalPrice,
            discount: data.result.data.discount,
          });
          setDiscountError('');
        }
      } catch (error) {
        console.error('Error validating discount:', error);
        setDiscountError(t("pricing.discount.invalid"));
        setPriceDetails(null);
      } finally {
        setIsValidatingDiscount(false);
      }
    };

    const debounceTimer = setTimeout(validateDiscountCode, 500);
    return () => clearTimeout(debounceTimer);
  }, [discountCode, planId, t]);

  const handleMolliePayment = async () => {
    try {
      // First, collect customer email for card payments
      setSelectedMethod('card');
      setIsCollectingEmail(true);
    } catch (error) {
      console.error('Error initiating Mollie payment:', error);
      setSelectedMethod(null);
    }
  };

  const handleCryptoPayment = async () => {
    try {
      // First, collect customer email
      setSelectedMethod('crypto');
      setIsCollectingEmail(true);

    } catch (error) {
      console.error('Error initiating crypto payment:', error);
      setSelectedMethod(null);
    }
  };

  const handleEmailSubmit = async () => {
    // More robust email validation
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!customerEmail || !emailRegex.test(customerEmail.trim())) {
      toast.error('Please enter a valid email address');
      return;
    }

    setIsProcessingPayment(true);
    setIframeError(false);

    // On mobile: Open placeholder window IMMEDIATELY (in user gesture context)
    // This prevents popup blockers from blocking the window
    let paymentWindow: Window | null = null;
    if (isMobile) {
      paymentWindow = window.open('about:blank', '_blank');
    }

    try {
      if (selectedMethod === 'crypto') {
        // Handle crypto payment
        const response = await fetch(`${env.API_URL}/trpc/payments.crypto.createInvoice`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({
            planId: planId as 'monthly' | 'quarterly' | 'lifetime' | 'premium',
            customerEmail,
            discountCode: discountCode.trim() || undefined,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error?.message || 'Failed to create payment');
        }

        if (data.result?.data?.success && data.result?.data?.invoice?.invoice_url) {
          let invoiceUrl = data.result.data.invoice.invoice_url;

          // Ensure HTTPS for iframe embedding (fixes Mixed Content errors)
          // Force HTTPS for any NOWPayments URL
          if (invoiceUrl.includes('nowpayments.io') && !invoiceUrl.startsWith('https://')) {
            invoiceUrl = invoiceUrl.replace(/^http:\/\//, 'https://');
            console.log('[WaveShield] Fixed NOWPayments URL to HTTPS:', invoiceUrl);
          } else if (invoiceUrl.startsWith('http://')) {
            invoiceUrl = invoiceUrl.replace(/^http:\/\//, 'https://');
            console.log('[WaveShield] Fixed URL to HTTPS:', invoiceUrl);
          }

          // Store price details if available
          if (data.result?.data?.priceDetails) {
            setPriceDetails(data.result.data.priceDetails);
          }

          // Mobile: redirect pre-opened window, Desktop: embed in iframe
          if (isMobile) {
            if (paymentWindow) {
              paymentWindow.location.href = invoiceUrl;
            } else {
              // Fallback: direct navigation if popup was blocked
              window.location.href = invoiceUrl;
            }
            onClose();
          } else {
            setIsIframeLoading(true);
            setEmbeddedCheckoutUrl(invoiceUrl);
          }
          return;
        } else {
          throw new Error('Invalid response from payment service');
        }
      } else if (selectedMethod === 'card') {
        // Handle Polar card payment
        const response = await fetch(`${env.API_URL}/trpc/payments.polar.createPayment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({
            planId: planId as 'monthly' | 'quarterly' | 'lifetime' | 'premium',
            customerEmail,
            discountCode: discountCode.trim() || undefined,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.error?.message || 'Failed to create payment');
        }

        if (data.result?.data?.success && data.result?.data?.payment?.checkout_url) {
          const paymentUrl = data.result.data.payment.checkout_url;

          // Store price details if available
          if (data.result?.data?.priceDetails) {
            setPriceDetails(data.result.data.priceDetails);
          }

          // Mobile: redirect pre-opened window, Desktop: embed in iframe
          if (isMobile) {
            if (paymentWindow) {
              paymentWindow.location.href = paymentUrl;
            } else {
              // Fallback: direct navigation if popup was blocked
              window.location.href = paymentUrl;
            }
            onClose();
          } else {
            setIsIframeLoading(true);
            setEmbeddedCheckoutUrl(paymentUrl);
          }
          return;
        } else {
          throw new Error('Invalid response from Polar payment service');
        }
      }
    } catch (error) {
      // Close the placeholder window if there's an error
      if (paymentWindow) {
        paymentWindow.close();
      }
      console.error(`Error creating ${selectedMethod} payment:`, error);
      toast.error(`Failed to create ${selectedMethod} payment. Please try again.`);
      setSelectedMethod(null);
      setIsCollectingEmail(false);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleOpenInNewTab = () => {
    if (embeddedCheckoutUrl) {
      window.open(embeddedCheckoutUrl, '_blank');
    }
  };

  const handleBackFromCheckout = () => {
    setEmbeddedCheckoutUrl(null);
    setIsIframeLoading(false);
    setIframeError(false);
  };

  const handlePaymentMethodSelect = (method: 'card' | 'crypto') => {
    if (method === 'card') {
      handleMolliePayment();
    } else if (method === 'crypto') {
      handleCryptoPayment();
    }
  };

  const handleBackToSelection = () => {
    setSelectedMethod(null);
    setIsCollectingEmail(false);
    setCustomerEmail('');
    setIsProcessingPayment(false);
  };

  // If showing embedded checkout, display iframe
  if (embeddedCheckoutUrl) {
    return (
      <Dialog open={isOpen} onOpenChange={() => { }} modal={true}>
        <DialogContent
          className="w-[calc(100vw-1rem)] sm:w-[calc(100vw-2rem)] max-w-2xl h-[90vh] sm:h-[85vh] bg-background/98 backdrop-blur-xl border border-white/10 p-0 flex flex-col [&>button]:hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10 shrink-0">
            <button
              onClick={handleBackFromCheckout}
              className="flex items-center space-x-1 text-muted-foreground hover:text-white transition-colors text-xs sm:text-sm"
            >
              <svg className="w-3 h-3 sm:w-4 sm:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
              <span>Back</span>
            </button>
            <span className="text-white text-sm sm:text-base font-medium">
              Complete Payment
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleOpenInNewTab}
                className="text-muted-foreground hover:text-white transition-colors p-1"
                title="Open in new tab"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
              <button
                onClick={onClose}
                className="text-muted-foreground hover:text-white transition-colors"
              >
                <X className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </div>
          </div>

          {/* Iframe Container */}
          <div className="flex-1 relative overflow-hidden">
            {/* Loading State */}
            {isIframeLoading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/95 z-10">
                <div className="w-8 h-8 border-3 border-amber-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                <p className="text-muted-foreground text-sm">Loading payment page...</p>
              </div>
            )}

            {/* Error State */}
            {iframeError && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-background/95 z-10 p-4">
                <div className="text-center max-w-sm">
                  <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mx-auto mb-4">
                    <X className="w-6 h-6 text-red-400" />
                  </div>
                  <p className="text-white font-medium mb-2">Unable to load payment page</p>
                  <p className="text-muted-foreground text-sm mb-4">
                    Your browser may be blocking the embedded checkout. Try opening in a new tab.
                  </p>
                  <button
                    onClick={handleOpenInNewTab}
                    className="bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-700 hover:to-orange-600 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300 inline-flex items-center gap-2"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Open in New Tab
                  </button>
                </div>
              </div>
            )}

            {/* Iframe */}
            <iframe
              src={embeddedCheckoutUrl?.replace(/^http:\/\//i, 'https://')}
              className="w-full h-full border-0"
              allow="payment"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-top-navigation allow-modals"
              onLoad={() => setIsIframeLoading(false)}
              onError={() => {
                setIsIframeLoading(false);
                setIframeError(true);
              }}
              title="Payment Checkout"
            />
          </div>

          {/* Footer hint */}
          <div className="px-4 py-2 border-t border-white/10 shrink-0">
            <p className="text-center text-xs text-muted-foreground">
              <ShieldCheck className="w-3 h-3 inline-block mr-1" />
              Secure payment processed by {selectedMethod === 'crypto' ? 'NOWPayments' : 'Stripe'}
            </p>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // If collecting email, show email form
  if (isCollectingEmail) {
    return (
      <Dialog open={isOpen} onOpenChange={() => { }} modal={true}>
        <DialogContent className="w-[calc(100vw-2rem)] max-w-md bg-background/95 backdrop-blur-xl border border-white/10 [&>button]:hidden">
          <DialogHeader className="p-4 md:p-6 pb-2 md:pb-4">
            <div className="flex items-center justify-between mb-2">
              <button
                onClick={handleBackToSelection}
                className="flex items-center space-x-1 text-muted-foreground hover:text-white transition-colors text-xs md:text-sm"
              >
                <svg className="w-3 h-3 md:w-4 md:h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
                <span>Back</span>
              </button>
              <button
                onClick={onClose}
                className="text-muted-foreground hover:text-white transition-colors"
              >
                <X className="w-4 h-4 md:w-5 md:h-5" />
              </button>
            </div>
            <DialogTitle className="text-white text-lg md:text-xl font-semibold text-center">
              Enter Your Email
            </DialogTitle>
            <p className="text-muted-foreground text-center text-sm md:text-base">
              We'll send your license key to this email address
            </p>
          </DialogHeader>

          <div className="p-4 md:p-6 pt-0">
            <div className="space-y-4">
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  id="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="your.email@example.com"
                  className="w-full px-3 py-2 bg-background/50 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  onKeyPress={(e) => e.key === 'Enter' && !discountCode && handleEmailSubmit()}
                  autoFocus
                />
              </div>

              <div>
                <label htmlFor="discountCode" className="block text-sm font-medium text-gray-300 mb-2">
                  {t("pricing.discount.label")} <span className="text-gray-500 text-xs">({t("pricing.discount.optional")})</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    id="discountCode"
                    value={discountCode}
                    onChange={(e) => {
                      setDiscountCode(e.target.value.toUpperCase());
                      setDiscountError('');
                    }}
                    placeholder={t("pricing.discount.placeholder")}
                    className={`w-full px-3 py-2 bg-background/50 border ${discountError ? 'border-red-500' : 'border-gray-600'} rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 ${discountError ? 'focus:ring-red-500' : 'focus:ring-blue-500'} focus:border-transparent uppercase`}
                    onKeyPress={(e) => e.key === 'Enter' && handleEmailSubmit()}
                    maxLength={20}
                  />
                  {priceDetails && priceDetails.discount && (
                    <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    </div>
                  )}
                </div>
                {discountError && (
                  <p className="text-red-400 text-xs mt-1">{discountError}</p>
                )}
                {priceDetails && priceDetails.discount && (
                  <p className="text-green-400 text-xs mt-1">
                    {t("pricing.discount.applied")}: {priceDetails.discount.code} - €{priceDetails.discountAmount.toFixed(2)} {t("pricing.discount.off")}
                  </p>
                )}
              </div>

              {/* Price Summary */}
              {priceDetails && (
                <div className="bg-background/30 border border-gray-700 rounded-lg p-3 space-y-2">
                  <div className="flex justify-between text-sm text-gray-400">
                    <span>{t("pricing.discount.original_price")}</span>
                    <span className={priceDetails.discountAmount > 0 ? 'line-through' : ''}>€{priceDetails.originalPrice.toFixed(2)}</span>
                  </div>
                  {priceDetails.discountAmount > 0 && (
                    <>
                      <div className="flex justify-between text-sm text-green-400">
                        <span>{t("pricing.discount.discount")}</span>
                        <span>-€{priceDetails.discountAmount.toFixed(2)}</span>
                      </div>
                      <div className="border-t border-gray-700 pt-2 flex justify-between text-base font-semibold text-white">
                        <span>{t("pricing.discount.final_price")}</span>
                        <span>€{priceDetails.finalPrice.toFixed(2)}</span>
                      </div>
                    </>
                  )}
                </div>
              )}

              <div className="flex items-center justify-center pt-2">
                <div className="flex items-center space-x-2 text-xs text-gray-500">
                  <ShieldCheck className="w-3 h-3" />
                  <span>{t("pricing.email_notice")}</span>
                </div>
              </div>

              {/* Terms & Conditions Checkbox */}
              <div className="flex items-start space-x-3 p-3 bg-background/30 border border-gray-700 rounded-lg">
                <Checkbox
                  id="acceptTerms"
                  checked={acceptedTerms}
                  onCheckedChange={(checked) => setAcceptedTerms(checked === true)}
                  className="mt-0.5"
                />
                <label htmlFor="acceptTerms" className="text-sm text-gray-300 cursor-pointer leading-relaxed">
                  {t("pricing.terms.accept")}{' '}
                  <a
                    href="https://waveshield.xyz/terms"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-amber-300 underline"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {t("pricing.terms.terms")}
                  </a>
                  {' '}{t("pricing.terms.and")}{' '}
                  <a
                    href="https://waveshield.xyz/privacy"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-amber-300 underline"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {t("pricing.terms.privacy")}
                  </a>
                </label>
              </div>

              <button
                onClick={handleEmailSubmit}
                disabled={
                  !customerEmail ||
                  !/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(customerEmail.trim()) ||
                  !acceptedTerms ||
                  isProcessingPayment ||
                  isValidatingDiscount
                }
                className="w-full bg-gradient-to-r from-amber-600 to-orange-500 hover:from-amber-700 hover:to-orange-600 disabled:from-gray-600 disabled:to-gray-700 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center"
              >
                {isProcessingPayment ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    <span>Creating Payment...</span>
                  </>
                ) : isValidatingDiscount ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    <span>Validating...</span>
                  </>
                ) : (
                  'Continue to Payment'
                )}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Note: NOWPayments iframe logic removed - we now redirect directly for better mobile compatibility

  // Default payment method selection
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[calc(100vw-2rem)] max-w-md bg-background/95 backdrop-blur-xl border border-white/10">
        <DialogHeader>
          <DialogTitle className="text-white text-lg md:text-xl font-semibold text-center">
            Choose Payment Method
          </DialogTitle>
          <p className="text-muted-foreground text-center mt-2 text-sm md:text-base">
            {planName} - {planPrice}
          </p>
        </DialogHeader>

        <div className="p-4 md:p-6 pt-4 space-y-3 md:space-y-4">
          {/* Card Payment Option */}
          <motion.button
            onClick={() => handlePaymentMethodSelect('card')}
            className="w-full p-3 md:p-4 bg-gradient-to-r from-blue-600/20 to-cyan-500/20 hover:from-blue-600/30 hover:to-cyan-500/30 border border-blue-500/30 hover:border-blue-400/50 rounded-xl transition-all duration-300 group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-lg flex items-center justify-center">
                  <svg className="w-4 h-4 md:w-5 md:h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M4 4a2 2 0 00-2 2v8a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2H4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h3a1 1 0 100-2H7z" />
                  </svg>
                </div>
                <div className="text-left">
                  <h3 className="text-white font-semibold text-sm md:text-base">Card Payment</h3>
                  <p className="text-muted-foreground text-xs md:text-sm">Card, PayPal, Apple Pay, Google Pay</p>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground group-hover:text-white transition-colors" />
            </div>
          </motion.button>

          {/* Crypto Payment Option */}
          <motion.button
            onClick={() => handlePaymentMethodSelect('crypto')}
            className="w-full p-3 md:p-4 bg-gradient-to-r from-amber-600/20 to-orange-500/20 hover:from-amber-600/30 hover:to-orange-500/30 border border-amber-500/30 hover:border-amber-400/50 rounded-xl transition-all duration-300 group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            disabled={selectedMethod === 'crypto'}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-r from-amber-600 to-orange-500 rounded-lg flex items-center justify-center">
                  {selectedMethod === 'crypto' ? (
                    <div className="w-3 h-3 md:w-4 md:h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <svg className="w-4 h-4 md:w-5 md:h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                    </svg>
                  )}
                </div>
                <div className="text-left">
                  <h3 className="text-white font-semibold text-sm md:text-base">
                    {selectedMethod === 'crypto' ? 'Creating Payment...' : 'Cryptocurrency'}
                  </h3>
                  <p className="text-muted-foreground text-xs md:text-sm">Bitcoin, Ethereum, USDT & more</p>
                </div>
              </div>
              {selectedMethod !== 'crypto' && (
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground group-hover:text-white transition-colors" />
              )}
            </div>
          </motion.button>

          <div className="flex items-center justify-center pt-2">
            <div className="flex items-center space-x-2 text-xs text-gray-500">
              <ShieldCheck className="w-3 h-3" />
              <span>Secure payment processing</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

// Pricing Section - Mobile Optimized
const PricingSection = () => {
  const t = useScopedI18n("landing");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });
  const [paymentModal, setPaymentModal] = useState<{
    isOpen: boolean;
    planId: string;
    planName: string;
    planPrice: string;
  }>({
    isOpen: false,
    planId: '',
    planName: '',
    planPrice: '',
  });
  const [globalDiscount, setGlobalDiscount] = useState<{
    code: string;
    description?: string | null;
    discountType: string;
    discountAmount: number;
    discountPercentage: number;
    expiresAt?: Date | null;
  } | null>(null);

  // Fetch global discount on mount
  useEffect(() => {
    const fetchGlobalDiscount = async () => {
      try {
        const response = await fetch(`${env.API_URL}/trpc/discounts.getGlobalDiscount`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });

        const data = await response.json();
        if (response.ok && data.result?.data) {
          setGlobalDiscount(data.result.data);
        }
      } catch (error) {
        console.error('Error fetching global discount:', error);
      }
    };

    fetchGlobalDiscount();
  }, []);

  const calculateDiscountedPrice = (originalPrice: number) => {
    if (!globalDiscount) return null;
    let discountAmount = 0;
    if (globalDiscount.discountType === 'PERCENTAGE') {
      discountAmount = (originalPrice * globalDiscount.discountPercentage) / 100;
    } else {
      discountAmount = globalDiscount.discountAmount;
    }
    return Math.max(originalPrice - discountAmount, 0);
  };

  const openPaymentModal = (planId: string, planName: string, planPrice: string) => {
    setPaymentModal({
      isOpen: true,
      planId,
      planName,
      planPrice,
    });
  };

  const closePaymentModal = () => {
    setPaymentModal({
      isOpen: false,
      planId: '',
      planName: '',
      planPrice: '',
    });
  };

  const plans = [
    {
      id: "monthly",
      name: t("pricing.plans.monthly.name"),
      price: t("pricing.plans.monthly.price"),
      period: t("pricing.plans.monthly.period"),
      popular: false,
      description: "Perfect for testing and short-term projects",
      features: [
        t("pricing.plans.monthly.feature_1"),
        "Live Web Panel",
        t("pricing.features.all_features"),
        "Network Intelligence Tools",
        "Players Tracking & Monitoring Tools",
        t("pricing.features.support"),
      ],
    },
    {
      id: "quarterly",
      name: t("pricing.plans.quarterly.name"),
      price: t("pricing.plans.quarterly.price"),
      period: t("pricing.plans.quarterly.period"),
      popular: false,
      description: "Great value for established servers",
      features: [
        t("pricing.plans.quarterly.feature_1"),
        "Live Web Panel",
        t("pricing.features.all_features"),
        "Network Intelligence Tools",
        "Players Tracking & Monitoring Tools",
        t("pricing.features.support"),
      ],
    },
    {
      id: "lifetime",
      name: t("pricing.plans.lifetime.name"),
      price: t("pricing.plans.lifetime.price"),
      period: t("pricing.plans.lifetime.period"),
      popular: true,
      description: "The ultimate choice for professional communities",
      features: [
        t("pricing.plans.lifetime.feature_1"),
        "Live Web Panel",
        t("pricing.features.all_features"),
        "Network Intelligence Tools",
        "Players Tracking & Monitoring Tools",
        t("pricing.features.support"),
      ],
    },
  ];

  return (
    <section id="pricing" ref={ref} className="py-24 px-4 md:px-6 bg-background">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 text-white">
            {t("pricing.title")}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t("pricing.subtitle")}
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid lg:grid-cols-3 gap-8 items-start max-w-6xl mx-auto">
          {plans.map((plan, index) => {
            const isPopular = plan.popular;
            const priceNum = parseFloat(plan.price.replace(/[€,]/g, ''));
            const discountedPrice = calculateDiscountedPrice(priceNum);
            const finalPrice = discountedPrice !== null && discountedPrice < priceNum
              ? discountedPrice.toFixed(0)
              : plan.price;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={cn(
                  "relative rounded-3xl flex flex-col h-full transition-all duration-300 overflow-hidden",
                  isPopular
                    ? "bg-card border-2 border-white shadow-2xl z-10 scale-105"
                    : "bg-card/50 border border-border/50 hover:bg-card hover:border-border"
                )}
              >
                {isPopular && (
                  <>
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-32 bg-blue-500/20 blur-[60px] -z-10" />
                    <div className="absolute top-6 right-6 z-20">
                      <Badge className="bg-blue-500 text-white hover:bg-blue-600 px-3 py-1 text-sm font-medium rounded-full shadow-lg">
                        ★ Most popular
                      </Badge>
                    </div>
                  </>
                )}

                <div className="p-6 md:p-8 flex flex-col h-full">
                  <div className="mb-6">
                    <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                    <p className="text-muted-foreground text-sm h-10">{plan.description}</p>
                  </div>

                  <div className="mb-6">
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold text-white">
                        {discountedPrice !== null && discountedPrice < priceNum ? `€${finalPrice}` : finalPrice}
                      </span>
                      <span className="text-muted-foreground text-sm">
                        / {plan.period}
                      </span>
                    </div>
                    {discountedPrice !== null && discountedPrice < priceNum && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className="text-muted-foreground line-through text-sm">
                          {plan.price}
                        </span>
                        <Badge variant="destructive" className="text-xs px-2 py-0.5 h-5">
                          SALE
                        </Badge>
                      </div>
                    )}
                  </div>

                  <motion.button
                    className={cn(
                      "w-full rounded-full py-3 font-semibold text-base mb-6 relative overflow-hidden group border-2 cursor-pointer",
                      isPopular
                        ? "bg-white text-black shadow-lg border-transparent"
                        : "bg-white/5 text-white border-white/10 backdrop-blur-md"
                    )}
                    initial="initial"
                    whileHover="hover"
                    variants={{
                      initial: { scale: 1 },
                      hover: { scale: 0.95, transition: { duration: 0.4 } }
                    }}
                    onClick={() => openPaymentModal(plan.id, plan.name, plan.price)}
                  >
                    <span className="relative z-10">{t("pricing.purchase")}</span>
                    <motion.div
                      className={cn(
                        "absolute top-0 left-0 w-[60%] h-full bg-gradient-to-r",
                        isPopular
                          ? "from-transparent via-black/10 to-transparent"
                          : "from-transparent via-white/20 to-transparent"
                      )}
                      variants={{
                        initial: { x: '-100%', skewX: -30, opacity: 0 },
                        hover: {
                          x: '250%',
                          skewX: -30,
                          opacity: 1,
                          transition: {
                            x: {
                              repeat: Infinity,
                              duration: 1.2,
                              ease: "linear"
                            },
                            opacity: {
                              duration: 0
                            }
                          }
                        }
                      }}
                    />
                  </motion.button>

                  <div className="space-y-4 flex-1">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <Check className="h-5 w-5 text-blue-500 shrink-0" />
                          <span className="text-sm text-gray-300 leading-tight">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Premium Plan Separate Card */}
        <motion.div
          className="mt-16 max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="relative rounded-2xl border border-amber-500/30 bg-gradient-to-r from-amber-950/30 to-black p-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Sparkles className="h-6 w-6 text-amber-500" />
                <h3 className="text-2xl font-bold text-white">{t("pricing.premium.name")}</h3>
              </div>
              <p className="text-muted-foreground max-w-md">
                {t("pricing.premium.description")}
              </p>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right hidden md:block">
                <div className="text-2xl font-bold text-amber-500">{t("pricing.premium.price")}</div>
                <div className="text-xs text-muted-foreground">One-time payment</div>
              </div>
              <motion.button
                className="relative bg-amber-600 hover:bg-amber-700 text-white rounded-full px-8 py-3 font-semibold overflow-hidden group border-2 border-transparent"
                initial="initial"
                whileHover="hover"
                variants={{
                  initial: { scale: 1 },
                  hover: { scale: 0.95, transition: { duration: 0.4 } }
                }}
                onClick={() => openPaymentModal("premium", t("pricing.premium.name"), t("pricing.premium.price"))}
              >
                <span className="relative z-10">Get Premium</span>
                <motion.div
                  className="absolute top-0 left-0 w-[60%] h-full bg-gradient-to-r from-transparent via-white/20 to-transparent"
                  variants={{
                    initial: { x: '-100%', skewX: -30, opacity: 0 },
                    hover: {
                      x: '250%',
                      skewX: -30,
                      opacity: 1,
                      transition: {
                        x: {
                          repeat: Infinity,
                          duration: 1.2,
                          ease: "linear"
                        },
                        opacity: {
                          duration: 0
                        }
                      }
                    }
                  }}
                />
              </motion.button>
            </div>
          </div>
        </motion.div>

        <PaymentMethodModal
          isOpen={paymentModal.isOpen}
          onClose={closePaymentModal}
          planId={paymentModal.planId}
          planName={paymentModal.planName}
          planPrice={paymentModal.planPrice}
        />
      </div>
    </section>
  );
};

// ... [Previous footer and export remain unchanged]

// CTA Section - Redesigned with modern aesthetic (Warp/Hyperspace Theme)
const CTASection = () => {
  const t = useScopedI18n("landing");
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const stats = [
    {
      value: 5,
      label: t("need_help.stats.experience.label"),
      suffix: "+",
    },
    {
      value: 15000,
      label: t("need_help.stats.servers.label"),
      suffix: "+",
    },
    {
      value: 4,
      label: t("need_help.stats.bans.label"),
      suffix: "M+",
    },
  ];

  return (
    <section
      id="cta"
      ref={ref}
      className="relative py-24 md:py-32 px-4 md:px-6 overflow-hidden flex flex-col items-center justify-center bg-black/70"
    >
      {/* Background - Solid black to hide cuts, with subtle top fade for integration */}
      <div className="absolute inset-0 z-0 bg-black/30" />

      {/* Top Gradient Overlay for smooth transition from previous section */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-background to-transparent z-10 pointer-events-none" />

      {/* Hyperspace Effect - Scaled down and more subtle */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-60 mix-blend-screen z-0">
        {/* Central Glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60vw] h-[60vw] md:w-[30vw] md:h-[30vw] bg-blue-600/10 blur-[80px] rounded-full" />

        {/* Radiating Lines */}
        <div className="absolute inset-0 opacity-30">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
            <defs>
              <radialGradient id="fadeGradient" cx="50%" cy="50%" r="50%" fx="50%" fy="50%">
                <stop offset="0%" stopColor="white" stopOpacity="0" />
                <stop offset="30%" stopColor="white" stopOpacity="1" />
                <stop offset="100%" stopColor="white" stopOpacity="0" />
              </radialGradient>
              <mask id="fadeMask">
                <rect x="0" y="0" width="100" height="100" fill="url(#fadeGradient)" />
              </mask>
            </defs>
            <g mask="url(#fadeMask)" stroke="white" strokeWidth="0.05" strokeDasharray="0.5 1" fill="none">
              {Array.from({ length: 30 }).map((_, i) => {
                const angle = (i / 30) * Math.PI * 2;
                const x1 = 50;
                const y1 = 50;
                const cx = 50 + Math.cos(angle) * 25;
                const cy = 50 + Math.sin(angle) * 25;
                const x2 = 50 + Math.cos(angle) * 100;
                const y2 = 50 + Math.sin(angle) * 100;
                return (
                  <path
                    key={i}
                    d={`M${x1},${y1} Q${cx},${cy} ${x2},${y2}`}
                    className="animate-pulse"
                    style={{ animationDelay: `${i * 0.1}s`, animationDuration: '4s' }}
                  />
                );
              })}
            </g>
          </svg>
        </div>
      </div>

      <div className="relative z-20 max-w-5xl mx-auto w-full">
        <motion.div
          className="flex flex-col items-center text-center"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          {/* Headline - Reduced size, better fit */}
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tighter text-white mb-10 uppercase leading-[0.95]">
            JOIN THE WAVESHIELD <br />
            <span className="bg-clip-text text-transparent bg-gradient-to-b from-white to-white/60">
              REVOLUTION.
            </span>
          </h2>

          {/* Stats Grid - More compact */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-16 mb-12 w-full max-w-3xl mx-auto">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 15 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.2 + index * 0.1, duration: 0.5 }}
                className="flex flex-col items-center group"
              >
                <div className="text-4xl md:text-5xl font-bold text-[#4ade80] tracking-tight mb-2 group-hover:scale-105 transition-transform duration-300 font-mono">
                  {stat.suffix === "M+" ? (
                    <span className="flex items-center">
                      <NumberTicker value={stat.value} />M+
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <NumberTicker value={stat.value} />{stat.suffix}
                    </span>
                  )}
                </div>
                <div className="text-muted-foreground text-xs md:text-sm font-medium uppercase tracking-widest">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="h-11 px-8 rounded-full bg-[#3b82f6] hover:bg-[#2563eb] text-white text-sm font-bold tracking-wide transition-all hover:scale-105 shadow-[0_0_30px_-5px_rgba(59,130,246,0.5)] border border-white/10"
              onClick={() => {
                document.getElementById("pricing")?.scrollIntoView({
                  behavior: "smooth",
                });
              }}
            >
              {t("need_help.get_started").toUpperCase()}
              <ArrowRight className="ml-2 w-4 h-4" />
            </Button>

            <Button
              size="lg"
              className="h-11 px-8 rounded-full bg-[#5865F2] hover:bg-[#4752c4] text-white text-sm font-bold tracking-wide transition-all hover:scale-105 shadow-[0_0_30px_-5px_rgba(88,101,242,0.5)] border border-white/10"
              onClick={() => {
                window.open("https://discord.gg/waveshield", "_blank");
              }}
            >
              {t("need_help.join_discord")}
              <DiscordIcon className="ml-2 w-4 h-4" />
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

// Footer Section - Clean, modern, and functional
const FooterSection = () => {
  const t = useScopedI18n("landing");
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    {
      title: t("footer.navigation.title"),
      links: [
        { label: t("footer.navigation.home"), href: "#home" },
        { label: t("footer.navigation.features"), href: "#features" },
        { label: t("footer.navigation.pricing"), href: "#pricing" },
        { label: t("footer.navigation.faqs"), href: "#faqs" },
      ]
    },
    {
      title: "Resources",
      links: [
        { label: t("footer.support.documentation"), href: "https://docs.waveshield.xyz", external: true },
        { label: "API Reference", href: "/api-docs" },
        { label: "Status", href: "https://status.waveshield.xyz", external: true },
        { label: "Community", href: "https://discord.gg/waveshield", external: true },
      ]
    },
    {
      title: t("footer.legal.title"),
      links: [
        { label: t("footer.legal.terms"), href: "/terms" },
        { label: t("footer.legal.privacy"), href: "/privacy" },
        { label: t("footer.legal.refund"), href: "/refund" },
      ]
    }
  ];

  return (
    <footer className="relative border-t border-white/10 bg-background pt-16 pb-8 overflow-hidden">
      {/* Subtle bottom glow */}
      <div className="absolute bottom-0 left-0 right-0 h-[300px] bg-gradient-to-t from-blue-900/10 to-transparent pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 mb-16">

          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
              <Image
                src="/logo.webp"
                alt="WaveShield Logo"
                width={40}
                height={40}
                className="rounded-xl"
              />
              <span className="text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                WaveShield
              </span>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
              {t("footer.description")}
            </p>
            <div className="flex items-center gap-3">
              <a
                href="https://discord.gg/waveshield"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#5865F2] hover:border-[#5865F2] transition-all duration-300 group"
              >
                <DiscordIcon className="w-5 h-5 text-muted-foreground group-hover:text-white" />
              </a>
              <a
                href="https://github.com/WaveShieldDev"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#24292e] hover:border-[#24292e] transition-all duration-300 group"
              >
                <svg viewBox="0 0 24 24" className="w-5 h-5 text-muted-foreground group-hover:text-white fill-current" aria-hidden="true">
                  <path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
                </svg>
              </a>
              <a
                href="https://youtube.com/@waveshield"
                target="_blank"
                rel="noreferrer"
                className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center hover:bg-[#FF0000] hover:border-[#FF0000] transition-all duration-300 group"
              >
                <Youtube className="w-5 h-5 text-muted-foreground group-hover:text-white" />
              </a>
            </div>
          </div>

          {/* Links Columns */}
          {footerLinks.map((column, idx) => (
            <div key={idx} className="lg:col-span-1">
              <h3 className="font-semibold text-white mb-6">{column.title}</h3>
              <ul className="space-y-4">
                {column.links.map((link, linkIdx) => (
                  <li key={linkIdx}>
                    <a
                      href={link.href}
                      target={link.external ? "_blank" : undefined}
                      rel={link.external ? "noreferrer" : undefined}
                      className="text-sm text-muted-foreground hover:text-blue-400 transition-colors duration-200 flex items-center gap-1 group"
                    >
                      {link.label}
                      {link.external && <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity -translate-y-0.5" />}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Status Widget Column (Optional addition for premium feel) */}
          <div className="lg:col-span-1">
            <h3 className="font-semibold text-white mb-6">{t("footer.status")}</h3>
            <a
              href="https://status.waveshield.xyz"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-500/10 border border-green-500/20 hover:bg-green-500/20 transition-colors group"
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <span className="text-xs font-medium text-green-400">Operational</span>
              <ExternalLink className="w-3 h-3 text-green-400 group-hover:text-green-300 transition-colors" />
            </a>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">
            {t("footer.copyright", { year: currentYear })}
          </p>
          <div className="flex items-center gap-6 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-gray-600" />
              Made with ❤️ for FiveM
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};

// Main Component
const Landing = () => {
  return (
    <div className="min-h-screen bg-background text-white relative overflow-x-hidden">
      <AnimatedGridBackground />
      <GlassmorphicNavbar />
      <HeroSection />
      <FeaturesSection />
      <PricingSection />
      <LandingFAQSection />
      <CTASection />
      <FooterSection />
    </div>
  );
};

export default Landing;

