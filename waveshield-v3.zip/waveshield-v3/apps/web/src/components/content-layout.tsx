import { SiteHeader } from "./panel-header";

export function ContentLayout({
  title,
  breadcrumb,
  children,
}: {
  title: string | React.ReactNode;
  breadcrumb?: { title: string; url: string };
  children: React.ReactNode;
}) {
  return (
    <>
      <SiteHeader
        title={title}
        breadcrumb={
          breadcrumb
            ? { title: breadcrumb.title, url: breadcrumb.url }
            : undefined
        }
      />
      <div className="flex flex-1 flex-col">
        <div className="@container/main flex flex-1 flex-col gap-2">
          <div className="flex flex-col gap-4 pt-4 pb-4 md:gap-6 md:pb-6">
            <div className="grid grid-cols-1 gap-4 px-4">{children}</div>
          </div>
        </div>
      </div>
    </>
  );
}
