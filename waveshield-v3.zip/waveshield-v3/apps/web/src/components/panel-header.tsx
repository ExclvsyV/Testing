import { SidebarTrigger } from "@/components/ui/sidebar";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "./ui/breadcrumb";

export function SiteHeader({
  title,
  breadcrumb,
}: {
  title: string | React.ReactNode;
  breadcrumb?: {
    title: string;
    url: string;
  };
}) {
  return (
    <header className="sticky top-0 z-50 bg-background rounded-md group-has-data-[collapsible=icon]/sidebar-wrapper:h-14 flex h-14 shrink-0 items-center gap-2 transition-[width,height] ease-linear">
      <div className="flex w-full items-center gap-1 px-4 lg:gap-2">
        <SidebarTrigger className="" variant="outline" size="lg" />

        <Breadcrumb className="ml-1 h-9 inline-flex items-center justify-center rounded-md gap-2 px-3 has-[>svg]:px-2.5 border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50">
          <BreadcrumbList>
            {breadcrumb && (
              <>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href={breadcrumb.url}>
                    {breadcrumb.title}
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
              </>
            )}
            <BreadcrumbItem>
              <BreadcrumbPage>{title}</BreadcrumbPage>
            </BreadcrumbItem>
          </BreadcrumbList>
        </Breadcrumb>
      </div>
    </header>
  );
}
