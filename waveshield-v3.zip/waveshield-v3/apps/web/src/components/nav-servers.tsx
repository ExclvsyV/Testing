"use client";

import { ChevronRight, type LucideIcon } from "lucide-react";
import { useRef } from "react";

import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  SidebarGroup,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { formatServerName } from "./format-server-name";

// Helper function to strip color codes for tooltip text
function stripColorCodes(text: string): string {
  return text.replace(/\^[0-9]/g, "");
}

export function NavServers({
  items,
}: {
  items: {
    serverId: string;
    serverName: string;
    icon: LucideIcon;
    isActive?: boolean;
    items?: {
      title: string;
      url: string;
      icon?: LucideIcon;
      visible?: boolean;
    }[];
  }[];
}) {
  if (items.length === 0) {
    return null;
  }

  const pathname = usePathname();

  // Ref to track the last opened server (persists without causing re-renders)
  const lastOpenedServerRef = useRef<string | null>(
    items.length > 0 ? items[0].serverId : null
  );

  // Check if we're in a server path and extract serverId
  const isInServerPath = pathname.includes("/dashboard/server/");
  const currentServerId = isInServerPath
    ? pathname.split("/dashboard/server/")[1]?.split("/")[0]
    : null;

  // Update last opened server when navigating to a server
  if (currentServerId) {
    lastOpenedServerRef.current = currentServerId;
  }

  // Helper function to determine if this server should be open by default
  const shouldBeOpen = (item: (typeof items)[0], index: number) => {
    if (!isInServerPath) {
      // If not in a server path, keep the last opened server open
      return item.serverId === lastOpenedServerRef.current;
    }

    // If in a server path, check if this server's serverId matches the current one
    return currentServerId === item.serverId;
  };

  return (
    <SidebarGroup>
      <SidebarGroupLabel>My Servers</SidebarGroupLabel>
      <SidebarMenu>
        {items.map((item, index) => (
          <Collapsible
            key={`${item.serverId}-${
              currentServerId || lastOpenedServerRef.current || "default"
            }`}
            asChild
            defaultOpen={shouldBeOpen(item, index)}
            className="group/collapsible"
          >
            <SidebarMenuItem>
              <CollapsibleTrigger asChild>
                <SidebarMenuButton
                  tooltip={stripColorCodes(item.serverName)}
                  className="flex items-center"
                >
                  {item.icon && <item.icon />}
                  <span className="flex-1 min-w-0 truncate whitespace-nowrap">
                    {formatServerName(item.serverName)}
                  </span>
                  <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                </SidebarMenuButton>
              </CollapsibleTrigger>
              {item.items?.length ? (
                <>
                  <CollapsibleContent>
                    <SidebarMenuSub>
                      {item.items
                        ?.filter((subItem) => subItem.visible)
                        .map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                            <SidebarMenuSubButton
                              asChild
                              isActive={pathname.endsWith(subItem.url) || false}
                            >
                              <Link href={subItem.url}>
                                <div className="flex items-center gap-2">
                                  {subItem.icon && (
                                    <subItem.icon className="h-4 w-4" />
                                  )}
                                  <span>{subItem.title}</span>
                                </div>
                              </Link>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                    </SidebarMenuSub>
                  </CollapsibleContent>
                </>
              ) : null}
            </SidebarMenuItem>
          </Collapsible>
        ))}
      </SidebarMenu>
    </SidebarGroup>
  );
}
