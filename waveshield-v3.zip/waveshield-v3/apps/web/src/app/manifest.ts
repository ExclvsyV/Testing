import type { MetadataRoute } from "next";

export const dynamicParams = false // Prevents dynamic route parameters.
export const dynamic = 'force-static' // Forces the page to be statically rendered.
export const fetchCache = 'force-cache' // Force caching of fetch requests.
export const revalidate = 0 // Disable Incremental Static Regeneration (ISR).

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "WaveShield - Best FiveM Anticheat 2025",
    short_name: "WaveShield",
    description:
      "WaveShield is the best FiveM anticheat solution in 2025. Advanced server protection, real-time cheat detection, trusted by 10,000+ servers worldwide.",
    start_url: "/",
    display: "standalone",
    background_color: "#0a0a0a",
    theme_color: "#005eff",
    orientation: "portrait-primary",
    scope: "/",
    categories: ["security", "utilities", "productivity"],
    lang: "en-US",
    dir: "ltr",
    icons: [
      {
        src: "/logo.webp",
        sizes: "512x512",
        type: "image/webp",
        purpose: "any",
      },
    ],
    shortcuts: [
      {
        name: "WaveShield Dashboard",
        short_name: "Dashboard",
        description: "Access your WaveShield anticheat dashboard",
        url: "/dashboard",
        icons: [{ src: "/logo.webp", sizes: "512x512", type: "image/webp" }],
      },
    ],
    related_applications: [],
    prefer_related_applications: false,
    screenshots: [
      {
        src: "/panel.webp",
        sizes: "1200x630",
        type: "image/webp",
        form_factor: "wide",
        label: "WaveShield FiveM Anticheat Dashboard Interface",
      },
    ],
  };
}
