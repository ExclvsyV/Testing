"use client";

import { ContentLayout } from "@/components/content-layout";
import { formatServerName } from "@/components/format-server-name";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { authClient } from "@/lib/auth-client";
import { useScopedI18n } from "@/locales/client";
import { trpc } from "@/utils/trpc";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { TRPCClientErrorLike } from "@trpc/client";
import {
  CheckCircle,
  Loader2,
  Plus,
  ShieldCheck,
  Sparkles,
  Clock,
  AlertTriangle,
  Star,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";

// Form schema for redeeming a license key
const redeemSchema = z
  .object({
    licenseKey: z.string().min(1, "License key is required"),
    serverOption: z.enum(["new", "existing"]),
    existingServerId: z.string().optional(),
  })
  .refine(
    (data) => {
      // If "existing" option is selected, existingServerId must be provided
      if (data.serverOption === "existing" && !data.existingServerId) {
        return false;
      }
      return true;
    },
    {
      message: "Please select a server",
      path: ["existingServerId"],
    }
  );

type RedeemFormValues = z.infer<typeof redeemSchema>;

export default function Redeem() {
  const t = useScopedI18n("redeem");
  const { data: session } = authClient.useSession();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [redeemSuccess, setRedeemSuccess] = useState(false);
  const [userHasMadeSelection, setUserHasMadeSelection] = useState(false);
  const [successDetails, setSuccessDetails] = useState<{
    licenseId: string;
    serverName: string;
    message: string;
    expiresAt?: Date;
    licenseType?: string;
  } | null>(null);

  // Get user servers from the same query used by the sidebar (reuse cached data)
  const { data: allUserServers, isLoading: serversLoading } = useQuery(
    trpc.users.getUserServersList.queryOptions("all", {
      enabled: session?.user !== undefined,
      staleTime: 30000, // Same as sidebar - consider data stale after 30 seconds
    })
  );

  // Filter to only owned servers for the redeem dropdown
  const userServers = allUserServers?.filter((server) => server.isOwner) || [];

  // Check if user has any servers and if any are expiring soon
  const hasServers = userServers && userServers.length > 0;
  const expiringSoonServers = userServers.filter((server) => {
    if (!server.expiresAt) return false;
    const expiryDate = new Date(server.expiresAt);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry <= 30; // Servers expiring within 30 days
  });
  const hasExpiringSoon = expiringSoonServers.length > 0;

  // Form setup - Default to "existing" if user has servers, especially if they have expiring servers
  const defaultServerOption = hasServers ? "existing" : "new";
  
  const form = useForm<RedeemFormValues>({
    resolver: zodResolver(redeemSchema),
    defaultValues: {
      licenseKey: "",
      serverOption: defaultServerOption,
    },
  });

  const { mutate: redeemLicense, isPending } = useMutation(
    trpc.licenses.redeemLicenseKey.mutationOptions({
      onSuccess: (data: any) => {
        // Extract license type from the message
        const licenseTypeMatch = data.message.match(/with a (\w+) license/i);
        const licenseType = licenseTypeMatch ? licenseTypeMatch[1] : undefined;

        setRedeemSuccess(true);
        setSuccessDetails({
          licenseId: data.licenseId,
          serverName: data.serverName,
          message: data.message,
          ...(data.expiresAt ? { expiresAt: new Date(data.expiresAt) } : {}),
          ...(licenseType ? { licenseType } : {}),
        });

        // Invalidate the user servers query to refresh the sidebar
        queryClient.invalidateQueries({
          queryKey: [["users", "getUserServersList"]],
        });

        toast.success("License key redeemed successfully!");
        form.reset();
      },
      onError: (error: TRPCClientErrorLike<any>) => {
        toast.error(error.message || "Failed to redeem license key");
      },
    })
  );

  const watchServerOption = form.watch("serverOption");

  // Update the server option when server list changes
  useEffect(() => {
    // If no servers are available, force the "new" option
    if (
      userServers &&
      userServers.length === 0 &&
      watchServerOption === "existing"
    ) {
      form.setValue("serverOption", "new");
    }
    // If servers become available and user hasn't made any manual selections yet, default to "existing"
    else if (
      userServers &&
      userServers.length > 0 &&
      watchServerOption === "new" &&
      !userHasMadeSelection // Only auto-switch if user hasn't manually selected anything
    ) {
      form.setValue("serverOption", "existing");
    }
  }, [userServers, form, watchServerOption, userHasMadeSelection]);

  const onSubmit = (values: RedeemFormValues) => {
    if (values.serverOption === "new") {
      redeemLicense({
        ...values,
      });
    } else {
      redeemLicense(values);
    }
  };

  const handleGoToDashboard = (licenseId: string | undefined) => {
    if (licenseId) {
      router.push(`/dashboard/server/${licenseId}`);
    }
  };

  // Helper function to get server expiry info
  const getServerExpiryInfo = (server: any) => {
    if (!server.expiresAt) return null;
    const expiryDate = new Date(server.expiresAt);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysUntilExpiry <= 0) return { status: 'expired', days: Math.abs(daysUntilExpiry) };
    if (daysUntilExpiry <= 7) return { status: 'critical', days: daysUntilExpiry };
    if (daysUntilExpiry <= 30) return { status: 'warning', days: daysUntilExpiry };
    return { status: 'good', days: daysUntilExpiry };
  };

  return (
    <ContentLayout title={t("title")}>
      <div className="max-w-4xl mx-auto w-full my-8">
        {!redeemSuccess ? (
          <Card className="shadow-lg border-t-4 border-t-blue-500 dark:border-t-blue-400">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <ShieldCheck className="h-6 w-6 text-blue-500" />
                {t("redeem_your_license")}
              </CardTitle>
              <CardDescription>
                {hasExpiringSoon 
                  ? `You have ${expiringSoonServers.length} server${expiringSoonServers.length === 1 ? '' : 's'} expiring soon. Consider extending them with your new license key.`
                  : t("enter_license_key_description")
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form
                onSubmit={form.handleSubmit(onSubmit)}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <Label htmlFor="licenseKey" className="text-sm font-medium">
                    {t("license_key")}
                  </Label>
                  <Input
                    id="licenseKey"
                    placeholder="waveshield-XXXX-XXXX-XXXX"
                    className="font-mono"
                    {...form.register("licenseKey")}
                  />
                  {form.formState.errors.licenseKey && (
                    <p className="text-sm text-red-500">
                      {form.formState.errors.licenseKey.message}
                    </p>
                  )}
                </div>

                <div className="space-y-4">
                  <Label className="text-sm font-medium mb-2 block">
                    {t("redeem_option")}
                  </Label>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Existing Server Option - Show first and emphasized when servers available */}
                    {hasServers && (
                      <div
                        className={`relative cursor-pointer border-2 rounded-lg p-4 transition-all duration-200 ${
                          watchServerOption === "existing"
                            ? "border-green-500 bg-green-50 dark:bg-green-900/20 ring-2 ring-green-200 dark:ring-green-800"
                            : "border-gray-200 hover:border-green-300 dark:border-gray-700 hover:bg-green-50/50 dark:hover:bg-green-900/10"
                        }`}
                        onClick={() => {
                          form.setValue("serverOption", "existing");
                          setUserHasMadeSelection(true);
                        }}
                      >
                        {/* Recommended badge */}
                        {hasExpiringSoon && (
                          <div className="absolute -top-2 -right-2">
                            <Badge className="bg-green-500 text-white text-xs font-medium px-2 py-1 rounded-full shadow-lg">
                              <Star className="h-3 w-3 mr-1" />
                              Recommended
                            </Badge>
                          </div>
                        )}
                        
                        <div className="flex gap-3 items-start">
                          <Sparkles className="h-5 w-5 text-green-500 mt-0.5" />
                          <div className="flex-1">
                            <div className="font-medium text-green-700 dark:text-green-400">
                              {t("extend_existing_server")} 
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">
                              {t("extend_existing_server_description")}
                            </p>
                            
                            {/* Show expiring servers preview */}
                            {hasExpiringSoon && (
                              <div className="mt-2 space-y-1">
                                <p className="text-xs font-medium text-amber-600 dark:text-amber-400">
                                  Expiring soon:
                                </p>
                                {expiringSoonServers.slice(0, 2).map((server) => {
                                  const expiryInfo = getServerExpiryInfo(server);
                                  return (
                                    <div key={server.id} className="flex items-center gap-2 text-xs">
                                      <Clock className="h-3 w-3 text-amber-500" />
                                      <span className="font-medium">
                                        {formatServerName(server.serverName)}
                                      </span>
                                      <span className="text-amber-600 dark:text-amber-400">
                                        ({expiryInfo?.days} day{expiryInfo?.days === 1 ? '' : 's'} left)
                                      </span>
                                    </div>
                                  );
                                })}
                                {expiringSoonServers.length > 2 && (
                                  <p className="text-xs text-gray-500 dark:text-gray-400">
                                    +{expiringSoonServers.length - 2} more expiring soon
                                  </p>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* New Server Option */}
                    <div
                      className={`cursor-pointer border-2 rounded-lg p-4 transition-all duration-200 ${
                        watchServerOption === "new"
                          ? "border-blue-500 bg-blue-50 dark:bg-slate-800"
                          : "border-gray-200 hover:border-blue-200 dark:border-gray-700"
                      } ${hasServers ? 'order-2 md:order-1' : ''}`}
                      onClick={() => {
                        form.setValue("serverOption", "new");
                        setUserHasMadeSelection(true);
                      }}
                    >
                      <div className="flex gap-3 items-start">
                        <Plus className="h-5 w-5 text-blue-500 mt-0.5" />
                        <div>
                          <div className="font-medium">
                            {t("create_new_server")}
                          </div>
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            {t("create_new_server_description")}
                          </p>
                          {hasServers && (
                            <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                              Start fresh with new settings and data
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* No servers available option */}
                    {!hasServers && (
                      <div className="opacity-60 cursor-not-allowed bg-gray-50 dark:bg-gray-900 border-2 border-gray-300 dark:border-gray-700 rounded-lg p-4">
                        <div className="flex gap-3 items-start">
                          <Sparkles className="h-5 w-5 text-gray-400 mt-0.5" />
                          <div>
                            <div className="font-medium text-gray-500">
                              {t("extend_existing_server")}
                            </div>
                            <p className="text-sm text-gray-400">
                              {t("no_servers_available_description")}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Hidden input for form handling */}
                  <input type="hidden" {...form.register("serverOption")} />

                  {/* Server selection dropdown - enhanced with expiry information */}
                  {watchServerOption === "existing" && hasServers && (
                    <div className="space-y-2 mt-4">
                      <Label
                        htmlFor="existingServerId"
                        className="text-sm font-medium"
                      >
                        {t("select_server")}
                      </Label>
                      <Select
                        onValueChange={(value) =>
                          form.setValue("existingServerId", value)
                        }
                        defaultValue={form.watch("existingServerId") ?? ""}
                        disabled={serversLoading}
                      >
                        <SelectTrigger id="existingServerId" className="w-full">
                          <SelectValue
                            placeholder={t("select_server_placeholder")}
                          />
                        </SelectTrigger>
                        <SelectContent>
                          {/* Show expiring servers first */}
                          {expiringSoonServers.length > 0 && (
                            <>
                              <div className="px-2 py-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-900/20">
                                ⚠️ Expiring Soon
                              </div>
                              {expiringSoonServers.map((server) => {
                                const expiryInfo = getServerExpiryInfo(server);
                                return (
                                  <SelectItem key={server.id} value={server.id} className="bg-amber-50/50 dark:bg-amber-900/10">
                                    <div className="flex items-center justify-between w-full">
                                      <span>{formatServerName(server.serverName)}</span>
                                      <Badge variant="destructive" className="ml-2 text-xs">
                                        {expiryInfo?.days} day{expiryInfo?.days === 1 ? '' : 's'} left
                                      </Badge>
                                    </div>
                                  </SelectItem>
                                );
                              })}
                            </>
                          )}
                          
                          {/* Other servers */}
                          {userServers.filter(server => !expiringSoonServers.includes(server)).length > 0 && (
                            <>
                              {expiringSoonServers.length > 0 && (
                                <div className="px-2 py-1.5 text-xs font-medium text-gray-500 dark:text-gray-400 border-t">
                                  Other Servers
                                </div>
                              )}
                              {userServers
                                .filter(server => !expiringSoonServers.includes(server))
                                .map((server) => {
                                  const expiryInfo = getServerExpiryInfo(server);
                                  return (
                                    <SelectItem key={server.id} value={server.id}>
                                      <div className="flex items-center justify-between w-full">
                                        <span>{formatServerName(server.serverName)}</span>
                                        {expiryInfo && expiryInfo.status !== 'good' && (
                                          <Badge variant="outline" className="ml-2 text-xs">
                                            {expiryInfo.days} days
                                          </Badge>
                                        )}
                                      </div>
                                    </SelectItem>
                                  );
                                })}
                            </>
                          )}
                        </SelectContent>
                      </Select>
                      {form.formState.errors.existingServerId && (
                        <p className="text-sm text-red-500">
                          {form.formState.errors.existingServerId.message}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                <Button
                  type="submit"
                  className="w-full"
                  disabled={
                    isPending ||
                    (watchServerOption === "existing" &&
                      !form.watch("existingServerId"))
                  }
                >
                  {isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      {t("processing")}
                    </>
                  ) : (
                    t("redeem_license")
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        ) : (
          <Card className="shadow-lg border-t-4 border-t-green-500">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <CheckCircle className="h-6 w-6 text-green-500" />
                {t("redemption_successful")}
              </CardTitle>
              <CardDescription>{successDetails?.message}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="rounded-lg bg-gray-50 dark:bg-gray-800 p-4 border border-gray-200 dark:border-gray-700">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {t("server_name")}:
                    </span>
                    <span className="font-medium">
                      {formatServerName(successDetails?.serverName)}
                    </span>
                  </div>

                  {successDetails?.licenseType && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {t("license_type")}:
                      </span>
                      <Badge
                        variant={getLicenseBadgeVariant(
                          successDetails.licenseType
                        )}
                        className="font-medium uppercase"
                      >
                        {successDetails.licenseType}
                      </Badge>
                    </div>
                  )}

                  {successDetails?.expiresAt &&
                    successDetails.licenseType !== "lifetime" && (
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {t("expires_on")}:
                        </span>
                        <span className="font-medium">
                          {new Date(
                            successDetails.expiresAt
                          ).toLocaleDateString()}
                        </span>
                      </div>
                    )}

                  {successDetails?.licenseType === "lifetime" && (
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {t("expires_on")}:
                      </span>
                      <span className="font-medium">{t("never_expires")}</span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                onClick={() => {
                  handleGoToDashboard(successDetails?.licenseId);
                }}
              >
                {t("go_to_dashboard")}
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </ContentLayout>
  );
}

// Helper function to determine badge variant based on license type
function getLicenseBadgeVariant(
  licenseType?: string
): "default" | "secondary" | "destructive" | "outline" | null | undefined {
  if (!licenseType) return "default";

  switch (licenseType.toLowerCase()) {
    case "monthly":
      return "default";
    case "quarterly":
      return "secondary";
    case "bianually":
      return "secondary";
    case "yearly":
      return "outline";
    case "lifetime":
      return "destructive"; // Use destructive for emphasis
    default:
      return "default";
  }
}
