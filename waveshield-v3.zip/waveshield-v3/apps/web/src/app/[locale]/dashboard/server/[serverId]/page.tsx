"use client";
import { ContentLayout } from "@/components/content-layout";
import { formatServerName } from "@/components/format-server-name";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  ChartContainer,
  ChartLegend,
  ChartLegendContent,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useSession } from "@/hooks/use-session";
import { hasPermission } from "@/lib/utils";
import { useScopedI18n } from "@/locales/client";
import { trpc } from "@/utils/trpc";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { Permission } from "@waveshield/database";
import { format, formatDistanceToNow } from "date-fns";
import {
  BarChart3,
  Calendar,
  Copy,
  Eye,
  EyeOff,
  FileWarning,
  Key,
  Network,
  RotateCcw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from "recharts";
import { toast } from "sonner";

export default function ServerDashboard() {
  const t = useScopedI18n("server_dashboard");
  const params = useParams();
  const router = useRouter();
  const serverId = params.serverId as string;
  const { data: session } = useSession();
  const [showLicenseKey, setShowLicenseKey] = useState(false);
  const [timeRange, setTimeRange] = useState<"today" | "week" | "month">(
    "today"
  );

  const { data: server, isLoading } = useQuery(
    trpc.servers.getServer.queryOptions(serverId, {
      enabled: !!session?.user,
      staleTime: 30000,
    })
  );

  // Fetch analytics data
  const { data: analyticsData, isLoading: isAnalyticsLoading } = useQuery(
    trpc.servers.getServerAnalytics.queryOptions(
      { serverId, timeRange },
      {
        enabled: !!session?.user && !!server,
        staleTime: 60000, // Cache for 1 minute
      }
    )
  );

  // Fetch latest version data
  const { data: latestVersion } = useQuery({
    ...trpc.versions.getLatestVersion.queryOptions(),
    enabled: !!session?.user,
    staleTime: 60000,
  });

  // Check permissions - user must be a server member (have ANY permission)
  const isAllowed = useMemo(() => {
    if (!server) return false;
    if (server.isOwner) return true;
    if (server.permissions && Array.isArray(server.permissions)) {
      const permissions = server.permissions.map((p) =>
        String(p)
      ) as Permission[];
      return hasPermission(permissions, "ANY");
    }
    return false;
  }, [server, serverId]);

  // Mock server info (to be replaced with actual API data)
  const serverInfo = {
    version: server?.serverInfo.version || "0.0.0",
    isOnline: server?.serverInfo.isOnline || false,
    playerCount: server?.serverInfo.playerCount || 0,
    banCount: server?.serverInfo.banCount || 0,
    maxSlots: server?.serverInfo.maxSlots || 0,
    peakPlayers: analyticsData?.peakPlayers || 0,
    avgPlayers: analyticsData?.avgPlayers || 0,
  };

  // Check if server version is outdated
  const isVersionOutdated =
    latestVersion &&
    serverInfo.version &&
    serverInfo.version !== latestVersion.version;

  // Function to handle copying license key
  const copyLicenseKey = () => {
    if (server?.licenseKey) {
      navigator.clipboard.writeText(server.licenseKey);
      toast.success(t("license_key_copied"));
    }
  };

  // Format expiration date and calculate if it's imminent (within 7 days)
  const formatExpirationDate = () => {
    if (!server?.expiresAt) return null;

    const expirationDate = new Date(server.expiresAt);
    const now = new Date();
    const daysLeft = Math.ceil(
      (expirationDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    );
    const isImminent = daysLeft <= 14;

    return {
      formatted: format(expirationDate, "PPP"),
      fromNow: formatDistanceToNow(expirationDate, { addSuffix: true }),
      isImminent,
      isExpired: daysLeft <= 0,
      daysLeft,
    };
  };

  const expirationInfo = formatExpirationDate();
  const queryClient = useQueryClient();

  // Check user permissions
  const canResetIp = server?.isOwner;
  const canViewLicenseKey = server?.isOwner;
  const canDelete = server?.isOwner;
  const canRenew = server?.isOwner && expirationInfo?.isImminent;

  const resetIp = useMutation(
    trpc.servers.resetIp.mutationOptions({
      onSuccess: () => {
        toast.success(t("ip_reset_success"), {});

        queryClient.invalidateQueries({
          queryKey: [
            ["servers", "getServer"],
            {
              input: serverId,
            },
          ],
        });
      },
      onError: (error) => {
        toast.error(t("ip_reset_error"), {
          description: error.message,
        });
      },
    })
  );

  const deleteServer = useMutation(
    trpc.servers.deleteServer.mutationOptions({
      onSuccess: () => {
        toast.success(t("server_deleted"), {});

        queryClient.invalidateQueries({
          queryKey: [["users", "getUserServersList"]],
        });

        router.push("/dashboard");
      },
      onError: () => {
        toast.error(t("server_delete_error"), {});
      },
    })
  );

  return (
    <ContentLayout
      title={formatServerName(server?.serverName || t("server_dashboard"))}
      breadcrumb={{
        title: t("dashboard"),
        url: `/dashboard/server/${serverId}`,
      }}
    >
      {isLoading ? (
        <div className="grid gap-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-36" />
            ))}
          </div>
          <Skeleton className="h-[400px]" />
        </div>
      ) : !isAllowed ? (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <ShieldAlert className="h-16 w-16 text-destructive/60 mb-4" />
          <h2 className="text-2xl font-bold">Access Denied</h2>
          <p className="text-muted-foreground mt-2 max-w-md">
            You don't have permission to access this server dashboard. Contact
            the server owner to get added as a server member.
          </p>
        </div>
      ) : server ? (
        <div className="grid gap-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
                {t("server_dashboard")}
              </h1>
              <p className="text-muted-foreground">
                {t("server_dashboard_description")}
              </p>
            </div>
          </div>
          {/* Server Banner */}
          {server.bannerUrl && (
            <div className="relative w-full h-40 overflow-hidden rounded-xl">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${server.bannerUrl})` }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
            </div>
          )}

          {/* Server Cards */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4 sm:gap-4">
            {/* Server Status Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    <Shield className="h-4 w-4 text-primary" />
                  </div>
                  <CardTitle className="text-sm font-medium">
                    {t("server_status")}
                  </CardTitle>
                </div>
                <Badge
                  variant={server.isBanned ? "destructive" : serverInfo.isOnline ? "success" : "destructive"}
                  className="ml-2"
                >
                  {server.isBanned ? "Banned" : serverInfo.isOnline ? t("online") : t("offline")}
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold tracking-tight truncate">
                  {formatServerName(server.serverName)}
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    v{serverInfo.version}
                  </div>
                  {isVersionOutdated && (
                    <Badge
                      variant="outline"
                      className="text-amber-500 border-amber-500"
                    >
                      {t("update_to_version", {
                        version: latestVersion?.version,
                      })}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Server IP Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10">
                    <Network className="h-4 w-4 text-blue-500" />
                  </div>
                  <CardTitle className="text-sm font-medium">
                    {t("server_ip")}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {canResetIp ? (
                  <>
                    <div className="text-2xl font-bold tracking-tight truncate">
                      {server.serverIp || t("not_set")}
                    </div>
                    <div className="mt-2 flex items-center">
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm" className="mt-2">
                            <RotateCcw className="mr-1 h-3 w-3" />
                            {t("reset_ip")}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>
                              {t("reset_server_ip")}
                            </AlertDialogTitle>
                            <AlertDialogDescription>
                              {t("reset_ip_confirmation")}
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => resetIp.mutate(serverId)}
                            >
                              {t("reset_ip")}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="blur-sm select-none text-2xl font-bold tracking-tight">
                      xxx.xxx.xxx.xxx
                    </div>
                    <div className="mt-2 text-sm text-muted-foreground">
                      {t("restricted_access")}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* License Key Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-500/10">
                    <Key className="h-4 w-4 text-purple-500" />
                  </div>
                  <CardTitle className="text-sm font-medium">
                    {t("license_key")}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                {canViewLicenseKey ? (
                  <>
                    <div className="font-mono text-lg font-bold tracking-tight truncate">
                      {showLicenseKey
                        ? server.licenseKey
                        : server.licenseKey?.replace(/./g, "•")}
                    </div>
                    <div className="mt-2 flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowLicenseKey(!showLicenseKey)}
                      >
                        {showLicenseKey ? (
                          <>
                            <EyeOff className="mr-1 h-3 w-3" />
                            {t("hide")}
                          </>
                        ) : (
                          <>
                            <Eye className="mr-1 h-3 w-3" />
                            {t("show")}
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={copyLicenseKey}
                      >
                        <Copy className="mr-1 h-3 w-3" />
                        {t("copy")}
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="blur-sm select-none font-mono text-lg font-bold tracking-tight">
                      ••••••••••••••••••••••••
                    </div>
                    <div className="mt-2 text-sm text-muted-foreground">
                      {t("restricted_access")}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            {/* License Expiration Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500/10">
                    <Calendar className="h-4 w-4 text-green-500" />
                  </div>
                  <CardTitle className="text-sm font-medium">
                    {t("license_expiration")}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <div
                  className={`text-2xl font-bold tracking-tight ${
                    expirationInfo?.daysLeft && expirationInfo?.daysLeft <= 0 && "text-red-500"
                  }`}
                >
                  {expirationInfo?.daysLeft && expirationInfo?.daysLeft > 0
                    ? expirationInfo?.daysLeft + " " + t("days")
                    : t("expired")}
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    {expirationInfo?.formatted}
                  </div>
                  <Badge
                    variant={
                      expirationInfo?.isExpired
                        ? "destructive"
                        : expirationInfo?.isImminent
                        ? "outline"
                        : "outline"
                    }
                    className={
                      expirationInfo?.isExpired
                        ? ""
                        : expirationInfo?.isImminent
                        ? "border-amber-500 text-amber-500"
                        : "border-green-500 text-green-500"
                    }
                  >
                    {expirationInfo?.fromNow}
                  </Badge>
                </div>
                <div className="mt-4 flex flex-col gap-2">
                  {canRenew && (
                    <Button size="sm" className="w-full" asChild>
                      <Link href="/#pricing">
                        <ShieldCheck className="mr-1 h-3 w-3" />
                        {t("renew_license")}
                      </Link>
                    </Button>
                  )}
                  {canDelete && expirationInfo?.isExpired && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="w-full"
                        >
                          <Trash2 className="mr-1 h-3 w-3" />
                          {t("delete_server")}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>
                            {t("delete_server")}
                          </AlertDialogTitle>
                          <AlertDialogDescription>
                            {t("delete_server_confirmation")}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
                          <AlertDialogAction
                            className="bg-destructive text-destructive-foreground"
                            onClick={() => deleteServer.mutate(serverId)}
                          >
                            {t("delete_server")}
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}

          {/* Analytics Section */}
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <CardTitle>{t("server_analytics")}</CardTitle>
                  <CardDescription>
                    {t("server_analytics_description")}
                  </CardDescription>
                </div>
                <Tabs
                  defaultValue="today"
                  onValueChange={(value) => {
                    setTimeRange(value as "today" | "week" | "month");
                  }}
                >
                  <TabsList>
                    <TabsTrigger value="today">{t("today")}</TabsTrigger>
                    <TabsTrigger value="week">{t("last_7_days")}</TabsTrigger>
                    <TabsTrigger value="month">{t("last_30_days")}</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent>
              {/* Overview Stats */}
              <div className="grid grid-cols-4 gap-4">
                <div className="flex flex-col">
                  <span className="text-sm text-muted-foreground">
                    {t("current_players")}
                  </span>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-2xl font-bold">
                      {serverInfo.playerCount}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      / {serverInfo.maxSlots}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-sm text-muted-foreground">
                    {t("banned_players")}
                  </span>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-2xl font-bold">
                      {serverInfo.banCount}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-sm text-muted-foreground">
                    {t("peak_players")}
                  </span>
                  <div className="flex items-baseline gap-1 mt-1">
                    {isAnalyticsLoading ? (
                      <Skeleton className="h-8 w-12" />
                    ) : analyticsData?.chartData &&
                      analyticsData.chartData.length > 0 ? (
                      <span className="text-2xl font-bold">
                        {serverInfo.peakPlayers}
                      </span>
                    ) : (
                      <span className="text-2xl font-bold text-muted-foreground">
                        --
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {timeRange === "today"
                        ? t("last_24h")
                        : timeRange === "week"
                        ? t("this_week")
                        : t("this_month")}
                    </span>
                  </div>
                </div>

                <div className="flex flex-col">
                  <span className="text-sm text-muted-foreground">
                    {t("average_players")}
                  </span>
                  <div className="flex items-baseline gap-1 mt-1">
                    {isAnalyticsLoading ? (
                      <Skeleton className="h-8 w-12" />
                    ) : analyticsData?.chartData &&
                      analyticsData.chartData.length > 0 ? (
                      <span className="text-2xl font-bold">
                        {serverInfo.avgPlayers}
                      </span>
                    ) : (
                      <span className="text-2xl font-bold text-muted-foreground">
                        --
                      </span>
                    )}
                    <span className="text-xs text-muted-foreground">
                      {timeRange === "today"
                        ? t("last_24h")
                        : timeRange === "week"
                        ? t("this_week")
                        : t("this_month")}
                    </span>
                  </div>
                </div>
              </div>

              <ChartContainer
                className="mt-4 aspect-auto h-[250px] w-full"
                config={{
                  players: { label: t("players"), color: "#3b82f6" },
                  bans: { label: t("bans"), color: "#ef4444" },
                }}
              >
                {!analyticsData?.chartData ||
                analyticsData.chartData.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <BarChart3 className="h-12 w-12 text-muted-foreground/60 mb-4" />
                    <div className="text-muted-foreground mb-2">
                      {isAnalyticsLoading
                        ? "Loading analytics data..."
                        : "No analytics data available yet"}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {!isAnalyticsLoading &&
                        "Data will be available once the server has been running for some time"}
                    </div>
                  </div>
                ) : (
                  <AreaChart
                    data={analyticsData.chartData}
                    margin={{ left: -30 }}
                  >
                    <defs>
                      <linearGradient
                        id="colorPlayers"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#3b82f6"
                          stopOpacity={0.8}
                        />
                        <stop
                          offset="95%"
                          stopColor="#3b82f6"
                          stopOpacity={0}
                        />
                      </linearGradient>
                      <linearGradient
                        id="colorBans"
                        x1="0"
                        y1="0"
                        x2="0"
                        y2="1"
                      >
                        <stop
                          offset="5%"
                          stopColor="#ef4444"
                          stopOpacity={0.8}
                        />
                        <stop
                          offset="95%"
                          stopColor="#ef4444"
                          stopOpacity={0}
                        />
                      </linearGradient>
                    </defs>
                    <CartesianGrid vertical={false} strokeDasharray="3 3" />
                    <XAxis
                      dataKey="date"
                      tickLine={false}
                      axisLine={false}
                      tickMargin={8}
                      minTickGap={32}
                      tickFormatter={(value) => {
                        // Parse the ISO string date
                        let date;
                        try {
                          date = new Date(value);
                        } catch (e) {
                          return value; // Return as is if parsing fails
                        }

                        if (timeRange === "today") {
                          return format(date, "HH:mm"); // Format for hours
                        } else {
                          return format(date, "MMM dd"); // Format for dates
                        }
                      }}
                    />
                    <YAxis
                      tick={{ fontSize: 11 }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <ChartTooltip
                      labelFormatter={(label) => {
                        // Parse the ISO string date
                        try {
                          const date = new Date(label);
                          if (timeRange === "today") {
                            return format(date, "HH:mm");
                          } else {
                            return format(date, "MMM dd");
                          }
                        } catch (e) {
                          return label;
                        }
                      }}
                      content={<ChartTooltipContent />}
                    />
                    <Area
                      type="natural"
                      dataKey="players"
                      stroke="#3b82f6"
                      fillOpacity={1}
                      fill="url(#colorPlayers)"
                    />
                    <Area
                      type="natural"
                      dataKey="bans"
                      stroke="#ef4444"
                      fillOpacity={1}
                      fill="url(#colorBans)"
                    />
                    <ChartLegend content={<ChartLegendContent />} />
                  </AreaChart>
                )}
              </ChartContainer>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <FileWarning className="h-16 w-16 text-muted-foreground mb-4" />
          <h3 className="text-xl font-semibold mb-2">
            {t("server_not_found")}
          </h3>
          <p className="text-muted-foreground mb-6">
            {t("server_not_found_description")}
          </p>
          <Button asChild>
            <Link href="/dashboard">{t("return_to_dashboard")}</Link>
          </Button>
        </div>
      )}
    </ContentLayout>
  );
}
