"use client";

import { ContentLayout } from "@/components/content-layout";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { authClient } from "@/lib/auth-client";
import { hasPermission } from "@/lib/utils";
import { useScopedI18n } from "@/locales/client";
import { trpc } from "@/utils/trpc";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  AlertTriangle,
  DownloadIcon,
  Gift,
  HelpCircle,
  Terminal,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useState } from "react";
import { toast } from "sonner";

export default function Download() {
  const t = useScopedI18n("download");
  const { data: session } = authClient.useSession();
  const router = useRouter();

  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  // Query to fetch user's servers/licenses
  const { data: servers = [], isLoading: loading } = useQuery(
    trpc.users.getUserServersList.queryOptions("all", {
      enabled: session?.user !== undefined,
      staleTime: 30000,
    })
  );

  const canDownload = servers.filter((server) => {
    const expiryDate = new Date(server.expiresAt);
    return (
      expiryDate > new Date() &&
      (server.isOwner || hasPermission(server.permissions, "DOWNLOAD_FILES"))
    );
  });

  // Function to download the anti-cheat
  const { mutate: downloadAntiCheat } = useMutation(
    trpc.licenses.downloadAntiCheat.mutationOptions({
      onError: (error: any) => {
        toast.error(error.message || "Failed to download anti-cheat");
        setIsDownloading(false);
        setDownloadProgress(0);
      },
    })
  );

  const handleDownload = useCallback(async () => {
    if (!canDownload) {
      toast.error("No active license found");
      return;
    }

    try {
      setIsDownloading(true);
      setDownloadProgress(10);

      // Simulate progress while downloading
      const progressInterval = setInterval(() => {
        setDownloadProgress((prev) => {
          const next = prev + Math.random() * 15;
          return next > 90 ? 90 : next;
        });
      }, 300);

      // Request the file from the server
      downloadAntiCheat(void 0, {
        onSuccess: (response) => {
          clearInterval(progressInterval);
          setDownloadProgress(95);

          // Convert the base64 to a Blob
          const binaryString = atob(response.fileContent);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          const blob = new Blob([bytes], { type: "application/zip" });

          // Create a download link and trigger download
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = response.fileName;
          document.body.appendChild(a);

          setDownloadProgress(100);

          // Wait a moment for visual feedback before triggering download
          setTimeout(() => {
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            setIsDownloading(false);
            setDownloadProgress(0);
            toast.success("Anti-cheat successfully downloaded!");
          }, 500);
        },
      });
    } catch (error) {
      console.error("Download error:", error);
      toast.error(
        error instanceof Error ? error.message : "Failed to download anti-cheat"
      );
      setIsDownloading(false);
      setDownloadProgress(0);
    }
  }, [downloadAntiCheat]);

  return (
    <ContentLayout title={t("title")}>
      <div className="mx-auto w-full max-w-7xl px-4 sm:px-6">
        <div className="mb-6">
          <h2 className="text-xl font-bold sm:text-2xl">{t("description")}</h2>
        </div>

        {/* Mobile-first grid layout with improved spacing */}
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3 lg:gap-8">
          {/* License Selection Card */}
          <Card className="h-full lg:col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg sm:text-xl">
                {t("download_waveshield")}
              </CardTitle>
              <CardDescription className="text-sm">
                {t("download_description")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="flex h-32 items-center justify-center">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
                </div>
              ) : true ? (
                <div className="flex flex-col items-center justify-center py-8">
                  {/* Animated Download Button */}
                  <div
                    onClick={handleDownload}
                    className={`
                      group relative mx-auto w-40 h-40 flex items-center justify-center
                      ${
                        !canDownload || isDownloading
                          ? "cursor-not-allowed"
                          : "cursor-pointer"
                      }
                    `}
                  >
                    {/* Outer ring animation */}
                    <div
                      className={`
                      absolute w-full h-full rounded-full
                      ${
                        isDownloading
                          ? "border-4 border-primary/30"
                          : "border-2 border-primary/20 group-hover:border-primary/30 transition-colors duration-300"
                      }
                    `}
                    ></div>

                    {/* Middle animated ring */}
                    {!isDownloading && (
                      <div
                        className="absolute w-[90%] h-[90%] rounded-full border-2 border-primary/10 
                        group-hover:scale-105 group-hover:border-primary/20 transition-all duration-500"
                      ></div>
                    )}

                    {/* Inner button circle */}
                    <div
                      className={`
                      relative z-10 w-28 h-28 rounded-full flex flex-col items-center justify-center
                      shadow-lg bg-card border border-border
                      ${
                        isDownloading
                          ? ""
                          : "group-hover:shadow-primary/20 transition-shadow duration-300"
                      }
                    `}
                    >
                      {isDownloading ? (
                        <div className="w-full h-full flex flex-col items-center justify-center">
                          {/* Circular progress */}
                          <svg
                            className="w-full h-full absolute inset-0"
                            viewBox="0 0 100 100"
                          >
                            <circle
                              cx="50"
                              cy="50"
                              r="40"
                              stroke="hsl(var(--muted))"
                              strokeWidth="4"
                              fill="none"
                            />
                            <circle
                              cx="50"
                              cy="50"
                              r="40"
                              stroke="hsl(var(--primary))"
                              strokeWidth="4"
                              fill="none"
                              strokeLinecap="round"
                              strokeDasharray="251.2"
                              strokeDashoffset={
                                251.2 - (downloadProgress / 100) * 251.2
                              }
                              transform="rotate(-90 50 50)"
                              className="transition-all duration-300 ease-in-out"
                            />
                          </svg>

                          {/* Progress percentage */}
                          <div className="flex flex-col items-center justify-center z-10">
                            <span className="text-xl font-semibold">
                              {Math.round(downloadProgress)}%
                            </span>
                            <span className="text-xs text-muted-foreground">
                              {t("downloading")}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center gap-2">
                          <DownloadIcon className="h-8 w-8 text-primary group-hover:scale-110 transition-transform duration-300" />
                          <span className="text-sm font-medium">
                            {t("title")}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center space-y-4 py-8">
                  <AlertTriangle className="h-12 w-12 text-muted-foreground" />
                  <div className="text-center">
                    <h3 className="font-medium">{t("no_licenses")}</h3>
                    <p className="text-sm text-muted-foreground mt-1">
                      {t("no_licenses_description")}
                    </p>
                  </div>
                  <Button onClick={() => router.push("/dashboard/redeem")}>
                    <Gift className="mr-2 h-4 w-4" />
                    {t("redeem_license")}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Installation Guide Card */}
          <Card className="h-full lg:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg sm:text-xl">
                {t("installation_guide")}
              </CardTitle>
              <CardDescription>
                <Link
                  href="https://ayznnn.gitbook.io/waveshield-v4/getting-started/installation-guide"
                  target="_blank"
                  className="text-primary underline-offset-4 hover:underline"
                >
                  {t("read_more")}
                </Link>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs defaultValue="steps" className="w-full">
                <TabsList className="w-full grid grid-cols-2 mb-4">
                  <TabsTrigger value="steps" className="text-xs sm:text-sm">
                    <Terminal className="mr-1 h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline mr-1">
                      {t("installation_steps_title")}
                    </span>
                    <span className="sm:hidden">Steps</span>
                  </TabsTrigger>
                  <TabsTrigger value="issues" className="text-xs sm:text-sm">
                    <AlertTriangle className="mr-1 h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline mr-1">
                      {t("common_issues")}
                    </span>
                    <span className="sm:hidden">Issues</span>
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="steps" className="mt-0 space-y-6">
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-medium">1</span>
                      </div>
                      <div className="ml-0 sm:ml-2">
                        <p className="font-medium">
                          {t("installation_step_1")}
                        </p>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-medium">2</span>
                      </div>
                      <div className="ml-0 sm:ml-2">
                        <p className="font-medium">
                          {t("installation_step_2")}
                        </p>
                        <div className="mt-2 rounded-md bg-muted p-2 overflow-x-auto">
                          <code className="text-sm whitespace-nowrap">
                            ensure WaveShield<br />
                            add_ace resource.WaveShield command allow
                          </code>
                        </div>
                      </div>
                    </div>

                    <Separator />

                    <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border bg-background">
                        <span className="text-sm font-medium">3</span>
                      </div>
                      <div className="ml-0 sm:ml-2">
                        <p className="font-medium">
                          {t("installation_step_3")}
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="issues" className="mt-0">
                  <Alert variant="destructive" className="mb-4">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle className="ml-2">
                      {t("common_issues")}
                    </AlertTitle>
                    <AlertDescription>
                      <ul className="list-disc pl-4 sm:pl-5 mt-2 space-y-2 text-sm sm:text-base">
                        <li>{t("common_issue_1")}</li>
                        <li>{t("common_issue_2")}</li>
                        <li>{t("common_issue_3")}</li>
                      </ul>
                    </AlertDescription>
                  </Alert>

                  <div className="p-3 sm:p-4 rounded-lg border">
                    <div className="flex items-center gap-2 text-amber-500">
                      <HelpCircle className="h-4 w-4 sm:h-5 sm:w-5" />
                      <h3 className="font-medium text-sm sm:text-base">
                        {t("need_help")}
                      </h3>
                    </div>
                    <p className="text-xs sm:text-sm mt-2">
                      {t("join_discord")}:{" "}
                      <Link
                        href="https://discord.gg/waveshield"
                        target="_blank"
                        className="text-primary underline-offset-4 hover:underline"
                      >
                        discord.gg/waveshield
                      </Link>
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </ContentLayout>
  );
}
