"use client";

import { ContentLayout } from "@/components/content-layout";
import { formatServerName } from "@/components/format-server-name";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { authClient } from "@/lib/auth-client";
import { useScopedI18n } from "@/locales/client";
import { trpc } from "@/utils/trpc";
import { useQuery } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import {
  Activity,
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  Code,
  GitCommit,
  Info,
  InfoIcon,
  MoveDownRight,
  MoveUpRight,
  Server,
  Shield,
  Users,
  XCircle,
} from "lucide-react";
import Image from "next/image";
import Link from "next/link";

// GitHub commit interface
interface GitHubCommit {
  message: string;
  authorName: string;
  authorDate: string;
}

export default function Dashboard() {
  const t = useScopedI18n("dashboard");
  const { data: session } = authClient.useSession();

  const healthCheck = useQuery(trpc.healthCheck.queryOptions());

  // Add type assertion here
  type VersionData = {
    version: string;
    updatedAt: Date;
    changelog: string | null;
  };

  const latestVersion = useQuery(
    trpc.versions.getLatestVersion.queryOptions(undefined, {
      staleTime: 60000,
    })
  ) as {
    data: VersionData | undefined;
    isLoading: boolean;
  };

  // Fetch WaveShield stats - will be replaced with actual API call
  const { data: waveshieldStats, isLoading: isLoadingStats } = useQuery(
    trpc.stats.getGlobalStats.queryOptions(undefined, {
      staleTime: 60000, // 1 minute
    })
  );

  // Fetch user servers - will be replaced with actual API call
  const { data: userServers, isLoading: isLoadingServers } = useQuery(
    trpc.users.getUserServersList.queryOptions(undefined, {
      staleTime: 30000,
    })
  );

  // Fetch GitHub commits using tRPC with TanStack Query
  const { data: changelogCommits, isLoading: isLoadingChangelogs } = useQuery(
    trpc.versions.getGitHubCommits.queryOptions(undefined, {
      staleTime: 120000,
    })
  ) as { data: GitHubCommit[] | undefined; isLoading: boolean };

  // Fetch recent activities - will be replaced with actual API call
  const { data: recentActivities, isLoading: isLoadingActivities } = useQuery({
    queryKey: ["recent-activities"],
    queryFn: async () => {
      // This is mockup data that will be replaced with actual API calls
      return [
        {
          id: "act1",
          type: "ban",
          server: "My Server",
          details: "",
          player: "xX_H4cker_Xx",
          reason: "Illegal Object Spawn",
          timestamp: new Date(Date.now() - 3600000 * 2), // 2 hours ago
        },
      ];
    },
    staleTime: 60000, // 1 minute
  });

  // Calculate aggregated server stats
  const serverStats = {
    totalServers: userServers?.length || 0,
    onlineServers:
      userServers?.filter((server) => server.serverInfo.isOnline).length || 0,
    totalPlayers:
      userServers?.reduce(
        (sum, server) => sum + (server.serverInfo.playerCount || 0),
        0
      ) || 0,
    totalBans:
      userServers?.reduce(
        (sum, server) => sum + (server.serverInfo.banCount || 0),
        0
      ) || 0,
  };

  return (
    <ContentLayout title={t("title")}>
      {/* Welcome Section */}
      <div className="mb-2">
        <h1 className="text-2xl font-bold tracking-tight md:text-3xl">
          Welcome back, {session?.user?.name || "User"}!
        </h1>
        <p className="text-muted-foreground mt-1">
          Here's what's happening on WaveShield today.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4 sm:gap-4">
        {/* WaveShield Version Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                <Shield className="h-4 w-4 text-primary" />
              </div>
              <CardTitle className="text-sm font-medium">
                {t("waveshield_version")}
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {latestVersion.isLoading ? (
              <Skeleton className="h-12 w-36" />
            ) : (
              <>
                <div className="text-3xl font-bold tracking-tight">
                  v{latestVersion.data?.version || "0.0.0"}
                </div>
                <div className="mt-2 flex items-center">
                  <div className="flex items-center text-sm font-medium text-muted-foreground">
                    <span className="text-primary mr-1">{t("released")}</span>
                    {formatDistanceToNow(
                      latestVersion.data?.updatedAt || new Date(),
                      {
                        addSuffix: true,
                      }
                    )}
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Connected Servers Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-500/10">
                <Server className="h-4 w-4 text-blue-500" />
              </div>
              <CardTitle className="text-sm font-medium">
                {t("connected_servers")}
              </CardTitle>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <InfoIcon className="h-5 w-5 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Servers currently online</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-12 w-36" />
            ) : (
              <>
                <div className="text-3xl font-bold tracking-tight">
                  {waveshieldStats?.current.onlineServers.toLocaleString()}
                </div>
                <div className="mt-2 flex items-center">
                  {waveshieldStats?.trends.servers && (
                    <>
                      <div
                        className={`flex items-center text-sm font-medium ${
                          waveshieldStats.trends.servers.isPositive
                            ? "text-green-600"
                            : waveshieldStats.trends.servers.absoluteChange ===
                              0
                            ? "text-muted-foreground"
                            : "text-red-600"
                        }`}
                      >
                        {waveshieldStats.trends.servers.absoluteChange === 0 ? (
                          <span>—</span>
                        ) : waveshieldStats.trends.servers.isPositive ? (
                          <MoveUpRight className="mr-1 h-4 w-4" />
                        ) : (
                          <MoveDownRight className="mr-1 h-4 w-4" />
                        )}
                        <span>
                          {waveshieldStats.trends.servers.absoluteChange === 0
                            ? "0%"
                            : `${Math.abs(
                                waveshieldStats.trends.servers.percentageChange
                              )}%`}
                        </span>
                      </div>
                      <div className="ml-1 text-sm text-muted-foreground">
                        {waveshieldStats.trends.servers.absoluteChange === 0
                          ? "No change"
                          : `${
                              waveshieldStats.trends.servers.isPositive
                                ? "+"
                                : ""
                            }${
                              waveshieldStats.trends.servers.absoluteChange
                            } today`}
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Protected Players Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-purple-500/10">
                <Users className="h-4 w-4 text-purple-500" />
              </div>
              <CardTitle className="text-sm font-medium">
                {t("online_players")}
              </CardTitle>
            </div>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <InfoIcon className="h-5 w-5 text-muted-foreground" />
                </TooltipTrigger>
                <TooltipContent>
                  <p>Players currently online across all servers</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-12 w-36" />
            ) : (
              <>
                <div className="text-3xl font-bold tracking-tight">
                  {waveshieldStats?.current.onlinePlayers.toLocaleString()}
                </div>
                <div className="mt-2 flex items-center">
                  {waveshieldStats?.trends.players && (
                    <>
                      <div
                        className={`flex items-center text-sm font-medium ${
                          waveshieldStats.trends.players.isPositive
                            ? "text-green-600"
                            : waveshieldStats.trends.players.absoluteChange ===
                              0
                            ? "text-muted-foreground"
                            : "text-red-600"
                        }`}
                      >
                        {waveshieldStats.trends.players.absoluteChange === 0 ? (
                          <span>—</span>
                        ) : waveshieldStats.trends.players.isPositive ? (
                          <MoveUpRight className="mr-1 h-4 w-4" />
                        ) : (
                          <MoveDownRight className="mr-1 h-4 w-4" />
                        )}
                        <span>
                          {waveshieldStats.trends.players.absoluteChange === 0
                            ? "0%"
                            : `${Math.abs(
                                waveshieldStats.trends.players.percentageChange
                              )}%`}
                        </span>
                      </div>
                      <div className="ml-1 text-sm text-muted-foreground">
                        {waveshieldStats.trends.players.absoluteChange === 0
                          ? "No change"
                          : `${
                              waveshieldStats.trends.players.isPositive
                                ? "+"
                                : ""
                            }${waveshieldStats.trends.players.absoluteChange.toLocaleString()} today`}
                      </div>
                    </>
                  )}
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* WaveShield Status Card */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <div className="flex items-center gap-2">
              {healthCheck.isLoading ? (
                <Skeleton className="h-8 w-8 rounded-full" />
              ) : healthCheck.data ? (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-green-500/10">
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
              ) : (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-red-500/10">
                  <XCircle className="h-4 w-4 text-red-500" />
                </div>
              )}
              <CardTitle className="text-sm font-medium">
                {t("waveshield_status")}
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {isLoadingStats ? (
              <Skeleton className="h-12 w-36" />
            ) : (
              <>
                <div className="text-3xl font-bold tracking-tight">
                  {healthCheck.isLoading ? (
                    <Skeleton className="h-12 w-36" />
                  ) : healthCheck.data ? (
                    t("online")
                  ) : (
                    t("offline")
                  )}
                </div>
                <div className="mt-2 flex items-center">
                  <div className="text-sm text-muted-foreground">
                    {healthCheck.isLoading ? (
                      <Skeleton className="h-4 w-12" />
                    ) : healthCheck.data ? (
                      <span className="text-sm font-medium text-green-600">
                        99.8%
                      </span>
                    ) : (
                      <span className="text-sm font-medium text-red-600">
                        99.8%
                      </span>
                    )}{" "}
                    uptime this month
                  </div>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3 mt-4">
        {/* Servers Summary Section */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader className="sm:flex-row sm:items-center sm:justify-between">
              <div>
                <CardTitle>{t("my_servers")}</CardTitle>
                <CardDescription>
                  {t("servers_summary", {
                    online: serverStats.onlineServers,
                    total: serverStats.totalServers,
                    players: serverStats.totalPlayers,
                    bans: serverStats.totalBans,
                  })}
                </CardDescription>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingServers ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="flex flex-col space-y-3">
                      <Skeleton className="h-[140px] w-full rounded-md" />
                    </div>
                  ))}
                </div>
              ) : userServers && userServers.length > 0 ? (
                <div className="space-y-4">
                  {userServers.map((server) => (
                    <div
                      key={server.id}
                      className="relative overflow-hidden rounded-lg border hover:shadow-md transition-shadow"
                    >
                      <div className="absolute inset-0 z-10 bg-gradient-to-t from-black/70 via-black/40 to-transparent dark:from-black/90 dark:via-black/60" />
                      <div className="relative z-20 flex flex-col gap-1 p-4 text-white">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-semibold">
                              {formatServerName(server.serverName)}
                            </h3>
                            <Badge
                              variant={
                                server.serverInfo.isOnline
                                  ? "success"
                                  : "destructive"
                              }
                              className="text-[10px] px-2 h-5"
                            >
                              {server.serverInfo.isOnline
                                ? t("online")
                                : t("offline")}
                            </Badge>
                          </div>
                          <Link href={`/dashboard/server/${server.id}`}>
                            <Button
                              size="sm"
                              className="w-full sm:w-auto mt-1 sm:mt-0"
                            >
                              {t("manage")}
                            </Button>
                          </Link>
                        </div>
                        <div className="flex flex-wrap items-center gap-4 text-sm mt-2">
                          <div className="flex items-center gap-1">
                            <Users className="h-3.5 w-3.5" />
                            <span>
                              {server.serverInfo.playerCount || 0}{" "}
                              {t("players")}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Shield className="h-3.5 w-3.5" />
                            <span>
                              {server.serverInfo.banCount || 0} {t("bans")}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3.5 w-3.5" />
                            <span>
                              {server.serverInfo.isOnline
                                ? t("currently_active")
                                : t("last_active", {
                                    time: formatDistanceToNow(
                                      server.serverInfo.lastActiveAt ||
                                        new Date(),
                                      { addSuffix: true }
                                    ),
                                  })}
                            </span>
                          </div>
                        </div>
                      </div>
                      {server.bannerUrl && (
                        <Image
                          src={server.bannerUrl}
                          alt={server.serverName}
                          width={800}
                          height={100}
                          className="absolute inset-0 h-full w-full object-cover opacity-75 dark:opacity-20"
                        />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
                  <Server className="h-10 w-10 text-muted-foreground" />
                  <h3 className="mt-4 text-lg font-semibold">
                    {t("no_servers_found")}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {t("no_servers_description")}
                  </p>
                  <Link href="/dashboard/redeem">
                    <Button>{t("add_server")}</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Side Column */}
        <div className="space-y-4">
          {/* Changelogs Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <GitCommit className="mr-2 h-5 w-5" />
                {t("latest_updates")}
              </CardTitle>
              <CardDescription>{t("recent_changes")}</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[280px] pr-4">
                {isLoadingChangelogs ? (
                  <div className="space-y-4">
                    {[1, 2, 3, 4].map((i) => (
                      <div key={i} className="flex gap-3">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <div className="space-y-2 flex-1">
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-3 w-3/4" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {changelogCommits?.map(
                      (commit: GitHubCommit, index: number) => (
                        <div key={index} className="flex gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full border bg-muted">
                            <Code className="h-4 w-4" />
                          </div>
                          <div>
                            {commit.message}
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <span>{commit.authorName}</span>
                              <span>•</span>
                              <span>
                                {formatDistanceToNow(
                                  new Date(commit.authorDate),
                                  {
                                    addSuffix: true,
                                  }
                                )}
                              </span>
                            </div>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>

          {/* Recent Activity Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="mr-2 h-5 w-5" />
                {t("recent_activity")}
              </CardTitle>
              <CardDescription>{t("latest_events")}</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[220px] pr-4">
                {isLoadingActivities ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex gap-3">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <div className="space-y-2 flex-1">
                          <Skeleton className="h-4 w-full" />
                          <Skeleton className="h-3 w-3/4" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {recentActivities?.map((activity) => (
                      <div key={activity.id} className="flex gap-3">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full ${
                            activity.type === "ban"
                              ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
                              : activity.type === "detection"
                              ? "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
                              : "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                          }`}
                        >
                          {activity.type === "ban" ? (
                            <Shield className="h-4 w-4" />
                          ) : activity.type === "detection" ? (
                            <AlertTriangle className="h-4 w-4" />
                          ) : (
                            <Info className="h-4 w-4" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium">
                            {activity.type === "ban" &&
                              t("was_banned", {
                                player: activity.player,
                                server: activity.server,
                              })}
                            {activity.type === "detection" &&
                              t("triggered_detection", {
                                player: activity.player,
                                server: activity.server,
                              })}
                            {activity.type === "update" &&
                              t("server_updated", {
                                server: activity.server,
                                details: activity.details,
                              })}
                          </p>
                          <div className="flex items-center text-xs text-muted-foreground">
                            <Calendar className="mr-1 h-3 w-3" />
                            <span>
                              {formatDistanceToNow(activity.timestamp, {
                                addSuffix: true,
                              })}
                            </span>
                            {(activity.type === "ban" ||
                              activity.type === "detection") && (
                              <>
                                <span className="mx-1">•</span>
                                <span>{activity.reason}</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>
      </div>
    </ContentLayout>
  );
}
