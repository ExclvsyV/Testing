export default {
  sidebar: {
    customer_area: "고객 영역",
    dashboard: "대시보드",
    redeem: "코드 등록",
    download: "다운로드",
    support: "고객 지원",
    documentation: "문서",
    logout: "로그아웃",
    theme: "테마",
    language: "언어",
    light: "라이트",
    dark: "다크",
    system: "시스템",
    configuration: "설정",
    admins: "관리자",
    console: "콘솔",
    players: "플레이어",
    bans: "차단 목록",
    logs: "로그",
    configuration_library: "설정 라이브러리",
    models: "모델 검색",
    lookup: "플레이어 조회",
    map: "실시간 맵",
    multistream: "멀티 스트림",
  },
  dashboard: {
    title: "대시보드",
    waveshield_version: "WaveShield 버전",
    connected_servers: "연결된 서버",
    protected_players: "보호 중인 플레이어",
    waveshield_status: "WaveShield 상태",
    my_servers: "내 서버",
    servers_summary:
      "{total}개 중 {online}개 서버 온라인 • 플레이어 {players}명 • 차단 {bans}건",
    view_all: "모두 보기",
    manage: "관리",
    no_servers_found: "서버가 없습니다.",
    no_servers_description:
      "아직 서버가 없습니다. 서버를 추가하여 시작하세요.",
    add_server: "서버 추가",
    latest_updates: "최신 업데이트",
    recent_changes: "WaveShield 최근 변경사항",
    recent_activity: "최근 활동",
    latest_events: "모든 서버의 최신 이벤트",
    online: "온라인",
    offline: "오프라인",
    players: "플레이어",
    bans: "차단",
    currently_active: "현재 활성화됨",
    last_active: "마지막 활동 {time}",
    across_network: "전체 WaveShield 네트워크에서",
    online_players: "모든 서버의 온라인 플레이어",
    online_servers: "모든 서버의 온라인 상태",
    global_status: "WaveShield 네트워크 전체 상태",
    uptime: "가동률 {uptime}%",
    was_banned: "{server}에서 {player} 차단됨",
    triggered_detection: "{server}에서 {player} 탐지됨",
    server_updated: "{server} 업데이트됨: {details}",
    released: "출시됨",
  },
  server_dashboard: {
    dashboard: "대시보드",
    server_dashboard: "서버 대시보드",
    server_dashboard_description:
      "모니터링 및 관리를 위한 서버 관리 도구",
    server_status: "서버 상태",
    online: "온라인",
    offline: "오프라인",
    update_to_version: "v{version}으로 업데이트",
    server_ip: "서버 IP",
    not_set: "설정 안됨",
    reset_ip: "IP 재설정",
    reset_server_ip: "서버 IP 재설정",
    reset_ip_confirmation:
      "정말로 서버 IP를 재설정하시겠습니까? 이 작업은 되돌릴 수 없습니다.",
    cancel: "취소",
    restricted_access: "접근 제한",
    license_key: "라이선스 키",
    license_key_copied: "라이선스 키 복사됨",
    hide: "숨기기",
    show: "보기",
    copy: "복사",
    license_expiration: "라이선스 만료일",
    days: "일",
    expired: "만료됨",
    renew_license: "라이선스 갱신",
    delete_server: "서버 삭제",
    delete_server_confirmation:
      "정말로 서버를 삭제하시겠습니까? 이 작업은 되돌릴 수 없습니다.",
    server_analytics: "서버 분석",
    server_analytics_description:
      "플레이어 통계 및 서버 성능 지표",
    today: "오늘",
    last_7_days: "최근 7일",
    last_30_days: "최근 30일",
    current_players: "현재 플레이어",
    banned_players: "차단된 플레이어",
    peak_players: "최대 플레이어",
    average_players: "평균 플레이어",
    last_24h: "(최근 24시간)",
    this_week: "(이번 주)",
    this_month: "(이번 달)",
    server_not_found: "서버를 찾을 수 없음",
    server_not_found_description:
      "존재하지 않거나 접근 권한이 없습니다.",
    return_to_dashboard: "대시보드로 돌아가기",
    bans: "차단",
    players: "플레이어",
    ip_reset_success: "IP 재설정 성공",
    ip_reset_error: "IP 재설정 실패",
    server_deleted: "서버 삭제 성공",
    server_delete_error: "서버 삭제 실패",
  },
    redeem: {
    title: "코드 등록",
    redeem_your_license: "라이선스 키 등록",
    enter_license_key_description:
      "제품을 활성화하거나 기존 서버를 갱신하기 위해 아래에 라이선스 키를 입력하세요.",
    license_key: "라이선스 키",
    redeem_option: "등록 옵션",
    create_new_server: "새 서버 생성",
    create_new_server_description: "이 라이선스 키로 새 서버를 생성합니다.",
    extend_existing_server: "기존 서버 연장",
    extend_existing_server_description:
      "기존 서버에 사용 기간을 추가합니다.",
    no_servers_available_description:
      "연장 가능한 서버가 없습니다.",
    server_name: "서버 이름",
    enter_server_name: "새 서버의 이름을 입력하세요.",
    select_server: "서버 선택",
    select_server_placeholder: "연장할 서버를 선택하세요.",
    no_servers_available: "서버 없음",
    redeem_license: "라이선스 등록",
    processing: "처리 중...",
    redemption_successful: "등록 완료",
    server_name_label: "서버 이름",
    expires_on: "만료일",
    go_to_dashboard: "대시보드로 이동",
    license_type: "라이선스 유형",
    never_expires: "만료 없음",
  },
  download: {
    title: "다운로드",
    download_description: "지금 WaveShield를 다운로드하고 보호 기능을 시작하세요!",
    download_waveshield: "WaveShield 다운로드",
    description:
      "서버용 최신 WaveShield 안티치트 버전을 다운로드합니다.",
    choose_license: "라이선스 선택",
    select_server: "서버 선택",
    no_licenses: "활성 라이선스 없음",
    no_licenses_description:
      "활성 라이선스가 없습니다. 시작하려면 라이선스 키를 등록하세요.",
    redeem_license: "라이선스 등록",
    downloading: "다운로드 중...",
    installation_guide: "설치 가이드",
    installation_steps_title: "빠른 설치 단계",
    installation_step_1:
      "/resources 디렉토리에 WaveShield 폴더를 직접 넣으세요 (하위 폴더 아님)",
    installation_step_2:
      "server.cfg 파일의 시작 부분에 다음을 추가합니다:",
    installation_step_3: "서버를 시작하고 보호 기능을 즐기세요!",
    read_more: "전체 설치 가이드 읽기",
    common_issues: "자주 발생하는 문제",
    common_issue_1:
      "스크립트 이름을 변경할 수 없습니다. 반드시 `WaveShield`여야 합니다.",
    common_issue_2: "다른 리소트보다 먼저 시작해야 합니다.",
    common_issue_3:
      "폴더는 /resources에 직접 위치해야 합니다 (하위 폴더 금지).",
    server_name: "서버 이름",
    expires_on: "만료",
    need_help: "도움이 필요하신가요?",
    join_discord: "디스코드 참여",
    expired: "만료됨",
    never_expires: "만료 없음",
  },
  server_configuration: {
    configuration: "설정",
    configuration_description: "서버 설정을 관리하세요",
    dashboard: "대시보드",
    my_server: "내 서버",
    access_denied: "접근 거부",
    access_denied_description:
      "이 서버의 설정에 접근할 권한이 없습니다. 서버 소유자에게 문의하세요.",
    search_placeholder: "설정 옵션 검색...",
    import: "가져오기",
    share: "공유",
    reset: "기본값으로 재설정",
    cancel_changes: "변경 취소",
    save_changes: "변경 저장",
    search_results: "검색 결과",
    search_results_description: "일치하는 설정 옵션을 찾았습니다.",
    import_config: "설정 가져오기",
    import_config_description:
      "다른 서버의 설정을 가져오기 위해 설정 ID를 입력하세요.",
    import_id_placeholder: "설정 ID 입력 (예: ws1a2b3c4)",
    import_id_required: "설정 ID를 입력하세요.",
    share_config: "설정 공유",
    reset_config: "설정 재설정",
    reset_config_description:
      "모든 설정이 기본값으로 재설정됩니다. 이 작업은 되돌릴 수 없습니다.",
    cancel: "취소",
    copy: "복사",
    config_saved_success: "설정이 저장되었습니다.",
    config_saved_error: "설정 저장에 실패했습니다.",
    config_shared_success: "설정이 공유되었습니다.",
    config_shared_id: "설정 ID: {id}",
    copied_to_clipboard: "클립보드에 복사됨",
    config_imported_success: "설정이 가져와졌습니다.",
    config_imported_error: "설정 가져오기에 실패했습니다.",
    main_description: "핵심 보호 및 탐지 기능",
    weapons_description: "무기 관련 보호 기능",
    entities_description: "엔티티 관리 및 보호 기능",
    explosions_description: "폭발 및 파티클 제어",
    premium_description: "고급 보호 기능 (프리미엄)",
    beta_description: "실험적 베타 기능",
    settings_description: "일반 설정 및 옵션",
    unsaved_changes: "저장되지 않은 변경사항이 있습니다.",
    loading_configuration: "설정 불러오는 중...",
    share_dialog_description:
      "다른 사용자와 설정을 공유하세요. 공개 설정은 마켓플레이스에서 검색됩니다.",
    configuration_name: "이름",
    configuration_name_placeholder: "나만의 설정 이름",
    description_optional: "설명 (선택 사항)",
    description_placeholder:
      "이 설정의 특징을 설명하세요...",
    tags_max_5: "태그 (최대 5개)",
    tags_selected: "{count}/5 태그 선택됨",
    make_public_marketplace: "공개(마켓플레이스 검색 가능)",
    share_configuration: "설정 공유",
  },
  config_library: {
    title: "설정 라이브러리",
    dashboard: "대시보드",
    browse_public: "공개 설정 찾아보기",
    my_configurations: "내 설정",
    search_filters: "검색 및 필터",
    search_placeholder: "설정 검색...",
    sort_by: "정렬 기준",
    newest_first: "최신순",
    oldest_first: "오래된순",
    most_popular: "인기순",
    name_az: "이름순(A-Z)",
    tags: "태그",
    no_configs_found: "설정을 찾을 수 없음",
    no_configs_description: "검색 조건을 변경하거나 나중에 다시 확인해보세요.",
    configs_found: "개의 설정이 검색됨",
    previous: "이전",
    next: "다음",
    sign_in_required: "로그인 필요",
    sign_in_description: "내 설정을 보려면 로그인해야 합니다.",
    your_shared_configs: "내가 공유한 설정",
    no_configs_shared: "아직 공유한 설정이 없습니다",
    no_configs_shared_description: "첫 번째 설정을 공유하면 여기에 표시됩니다.",
    preview: "미리보기",
    import: "가져오기",
    importing: "가져오는 중...",
    created_by: "작성자",
    public: "공개",
    private: "비공개",
    edit_details: "세부 정보 수정",
    make_private: "비공개로 전환",
    make_public: "공개로 전환",
    copy_share_id: "공유 ID 복사",
    delete: "삭제",
    config_preview: "설정 미리보기",
    config_data: "설정 데이터:",
    failed_to_load: "설정 정보를 불러오지 못했습니다",
    edit_config: "설정 수정",
    edit_config_description: "공유한 설정의 세부 정보를 수정하세요.",
    name: "이름",
    description: "설명",
    make_public_searchable: "공개(라이브러리에서 검색 가능)",
    cancel: "취소",
    save_changes: "변경사항 저장",
    delete_config: "설정 삭제",
    delete_config_description:
      "정말로 이 설정을 삭제하시겠습니까? 이 작업은 되돌릴 수 없으며 라이브러리에서 영구적으로 삭제됩니다.",
    share_id_copied: "공유 ID가 클립보드에 복사됨",
    config_id_copied: "설정 ID가 클립보드에 복사됨",
    config_id_copied_description: "서버 설정 페이지에서 가져오기 할 수 있습니다",
    failed_to_copy: "설정 ID 복사에 실패했습니다",
    config_updated: "설정이 성공적으로 수정됨",
    failed_to_update: "설정 수정에 실패했습니다",
    config_deleted: "설정이 성공적으로 삭제됨",
    failed_to_delete: "설정 삭제에 실패했습니다",
    no_description: "설명이 없습니다",
    no_tags: "태그 없음",
    unknown_user: "알 수 없는 사용자",
    you: "나",
    max_tags: "{count}/5개 태그 선택됨",
    page_of: "{total} 중 {page}페이지",
  },
  bans_page: {
    // Page header
    ban_management: "차단 관리",
    manage_player_bans_description:
      "서버의 플레이어 차단 및 차단 기록을 관리합니다",
    ban_offline: "오프라인 차단",
    unban_all: "모두 차단 해제",
    unbanning_all: "모든 플레이어 차단 해제 중...",
    confirm_unban_all: "정말 모든 플레이어의 차단을 해제하시겠습니까?",
    confirm_unban_all_description:
      "이 작업은 서버의 모든 플레이어 차단을 해제합니다. 되돌릴 수 없는 영구적인 작업입니다.",
    // Access denied
    access_denied: "접근 거부",
    access_denied_description:
      "이 서버의 차단을 관리할 권한이 없습니다.",

    // Filters & Search
    filters_search: "필터 및 검색",
    filters_search_description:
      "차단 ID, 사유, 또는 플레이어 이름으로 차단 내역을 검색/필터하세요",
    search_placeholder: "차단 ID, 사유, 플레이어 이름으로 검색...",

    // Sort options
    newest_first: "최신순",
    oldest_first: "오래된순",
    expires_latest: "만료 늦은순",
    expires_soonest: "곧 만료순",
    most_playtime: "플레이 시간 많은순",
    least_playtime: "플레이 시간 적은순",

    // Table headers
    player: "플레이어",
    ban_id: "차단 ID",
    reason: "사유",
    evidence: "증거",
    status: "상태",
    banned_at: "차단일",
    first_join: "최초 접속",
    actions: "동작",

    // Table content
    played: "플레이함",
    no_reason_provided: "사유 없음",
    no_evidence: "증거 없음",
    view_evidence: "증거 보기",
    view_video: "영상 보기",

    // Ban status
    permanent: "영구",
    expired: "만료됨",
    expires_in: "{time} 후 만료",

    // Pagination
    showing_results: "{start}~{end} / 총 {total}개 결과",
    previous: "이전",
    next: "다음",

    // Loading states
    loading: "로딩 중...",
    loading_ban_records: "차단 기록 불러오는 중...",

    // Empty states
    no_bans_found: "차단 내역 없음",
    no_bans_description: "현재 검색 조건에 맞는 차단 기록이 없습니다.",

    // Ban records
    ban_records: "차단 기록",
    total_bans_found: "총 {count}개 차단 기록{plural} 발견됨",

    // Actions
    unban_confirmation: "{playerName} 님의 차단을 해제하시겠습니까?",
    unban_success: "{playerName} 님 차단 해제 성공",
    unban_error: "플레이어 차단 해제에 실패했습니다",
    unbanning: "차단 해제 중...",
    unban_player: "차단 해제",

    // Ban Details Dialog
    ban_details: "차단 세부 정보",
    ban_details_description: "이 차단 기록에 대한 자세한 정보",
    ban_infos: "차단 정보",
    player_infos: "플레이어 정보",
    identifiers: "식별자",
    ban_expiration: "차단 만료",
    additional_details: "추가 세부 정보",
    cross_server_bans: "서버 간 차단",
    banned_identifiers: "차단된 식별자",
    close: "닫기",

    // Player info
    player_name: "플레이어 이름",
    play_time: "플레이 시간",
    last_join: "마지막 접속",

    // Ban Player Dialog
    ban_player: "플레이어 차단",
    ban_player_description:
      "플레이어를 검색하거나 직접 식별자를 입력해 차단할 수 있습니다.",
    player_selection: "플레이어 선택",
    search_player_placeholder:
      "이름, 라이선스, 스팀 ID, 디스코드 ID 등으로 플레이어 검색...",
    no_players_found: "플레이어를 찾을 수 없습니다.",
    matches: "건 일치",
    more: "더보기",
    joined: "접속함",
    clear: "초기화",
    or: "또는",
    enter_identifier_placeholder:
      "플레이어 식별자를 직접 입력 (라이선스, 이름, 스팀 ID 등)",
    enter_identifier_description: "모든 식별자를 입력할 수 있습니다.",

    // Ban form
    ban_reason: "차단 사유",
    ban_reason_placeholder: "차단 사유를 입력하세요...",
    ban_reason_description: "명확한 차단 사유를 입력하세요 (필수)",
    evidence_url: "증거 URL",
    evidence_url_placeholder: "https://example.com/evidence.png",
    evidence_url_description:
      "이미지, 영상 또는 문서 등 증거 링크 (선택 사항)",
    ban_type: "차단 유형",
    permanent_ban: "영구 차단",
    temporary_ban: "임시 차단",
    ban_duration: "차단 기간",
    ban_duration_description: "차단 기간을 설정하세요",
    hours: "시간",
    days: "일",
    weeks: "주",
    months: "개월",

    // Selected player
    selected_player: "선택한 플레이어",
    name: "이름",
    license: "라이선스",

    // Form actions
    cancel: "취소",
    banning: "차단 중...",

    // Form validation
    player_identifier_required: "플레이어 식별자가 필요합니다",
    player_identifier_too_long: "플레이어 식별자가 너무 깁니다",
    ban_reason_required: "차단 사유를 입력해야 합니다",
    ban_reason_too_long: "차단 사유가 너무 깁니다 (최대 1000자)",
    evidence_url_invalid: "올바른 URL을 입력하세요",
    evidence_url_too_long: "증거 URL이 너무 깁니다",
    duration_min: "차단 기간은 최소 1시간 이상이어야 합니다",
    duration_max: "차단 기간은 1년을 초과할 수 없습니다",

    // Cross-server bans
    banned_on_servers: "다른 {count}개 서버에서도 차단됨",
    banned: "차단됨",
    no_banned_identifiers: "차단된 식별자가 없습니다",

    // Model lookup
    view_in_models: "모델에서 검색",
  },
  lookup: {
    // Page header
    player_lookup: "플레이어 조회",
    lookup_dashboard: "조회 대시보드",
    search_analyze_description: "여러 서버에서 플레이어의 평판을 검색하고 분석하세요",

    // Access denied
    access_denied: "접근 거부",
    access_denied_description:
      '이 서버에서 플레이어를 조회할 권한이 없습니다. 서버 소유자에게 "플레이어 조회" 권한 요청을 문의하세요.',

    // Search section
    search_players: "플레이어 검색",
    search_players_description:
      "이름, 라이선스 또는 식별자로 플레이어를 검색해 평판을 분석하세요",
    search_placeholder: "플레이어 이름, 라이선스, 식별자로 검색...",
    searching_players: "플레이어 검색 중...",
    no_players_found: '"{search}"(으)로 일치하는 플레이어가 없습니다',
    type_characters: "플레이어 검색을 위해 3글자 이상 입력하세요",
    clear: "초기화",

    // Search results
    played: "플레이함",
    last_seen: "마지막 확인",
    matches: "일치",
    identifier: "식별자",
    identifiers: "식별자",

    // Trust Score
    trust_score: "위험 점수",
    trust_score_description: "플레이어 평판 분석",
    perfect_trust: "완벽(0)",
    neutral: "중립(50)",
    maximum_risk: "최대 위험(100)",

    // Risk levels
    risk_low: "낮음",
    risk_medium: "보통",
    risk_high: "높음",
    risk_critical: "위험",

    // Trust score factors
    cross_server_bans: "서버 간 차단",
    account_age: "계정 생성일",
    play_time_factor: "플레이 시간",
    patterns: "패턴",
    identifier_stability: "식별자 안정성",
    server_history: "서버 이력",
    recent_activity: "최근 활동",

    // Factor descriptions
    factor_risk: "위험",
    factor_none: "없음",
    factor_trusted: "신뢰됨",
    factor_new: "신규",
    factor_unknown: "알 수 없음",
    factor_low: "낮음",
    factor_neutral: "중립",
    factor_suspicious: "의심됨",
    factor_clean: "깨끗함",

    // Warnings
    warnings: "경고",

    // Player info
    player_name_label: "플레이어 이름",
    player_reputation_analysis: "플레이어 평판 분석",
    play_time_label: "플레이 시간",
    first_join: "최초 접속",
    last_join: "마지막 접속",
    license_label: "라이선스",

    // Tabs
    current_identifiers: "현재 식별자",
    previous_identifiers: "이전 식별자",
    alt_accounts: "부계정",
    active_bans_tab: "활성 차단 기록",

    // Identifier section
    identifier_summary: "식별자 요약",
    total_identifiers: "총 식별자",
    identifier_changes: "식별자 변경",
    frequent_changes_warning:
      "식별자 변경이 잦으면 차단 우회 시도로 간주될 수 있습니다.",

    // Alt accounts
    no_alt_accounts: "부계정이 발견되지 않았습니다",
    matching_ids: "일치하는 ID",
    current_server: "현재 서버",

    // Bans section
    no_bans_found: "차단 기록 없음",
    server_bans: "서버 차단 기록",
    cross_server_bans_section: "서버 간 차단 기록",
    server: "서버",
    player_column: "플레이어",
    reason: "사유",
    evidence: "증거",
    date: "날짜",
    direct_ban: "직접 차단",
    alt_account: "부계정",
    no_reason_provided: "사유 없음",
    no_evidence: "증거 없음",
    view_evidence: "증거 보기",
    view_video: "영상 보기",

    // Actions
    ban_player_action: "플레이어 차단",
    banned_status: "차단됨",
    close: "닫기",

    // Ban dialog
    ban_player_description:
      "{playerName} 님을 서버에서 차단합니다. 이 작업은 되돌릴 수 없습니다.",
    ban_reason_dialog: "차단 사유",
    ban_reason_placeholder_dialog:
      "이 플레이어의 차단 사유를 입력하세요...",
    ban_reason_description_dialog: "글자",
    evidence_url_dialog: "증거 URL (선택)",
    evidence_url_placeholder_dialog: "https://example.com/evidence.png",
    ban_type_dialog: "차단 유형",
    permanent_ban_dialog: "영구 차단",
    temporary_ban_dialog: "임시 차단",
    duration_hours: "차단 기간(시간)",
    duration_max: "최대: 8760시간(1년)",
    cancel_dialog: "취소",
    banning: "차단 중...",

    // Help section
    how_to_use: "플레이어 조회 사용법",
    search_players_help: "플레이어 검색",
    search_players_help_description:
      "이름, 라이선스 또는 식별자로 플레이어를 검색하세요. 현재 및 과거의 식별자까지 모두 검색합니다.",
    trust_score_help: "위험 점수",
    trust_score_help_description:
      "각 플레이어는 서버 간 차단, 계정 나이, 플레이 시간 등 다양한 지표로 위험 점수를 받습니다.",
    alt_accounts_help: "부계정",
    alt_accounts_help_description:
      "여러 서버에서 식별자 일치를 통해 잠재적 부계정을 찾습니다. 타 서버의 개인정보는 보호됩니다.",
    ban_history_help: "차단 이력",
    ban_history_help_description:
      "서버 및 서버 간 모든 차단 기록을 확인해 플레이어 평판을 평가할 수 있습니다.",

    // Media modal
    evidence_modal: "증거",

    // Loading states
    loading: "로딩 중...",
    loading_player_data: "플레이어 데이터 불러오는 중...",

    // Error states
    player_not_found: "플레이어를 찾을 수 없음",
    unable_to_load: "플레이어 데이터를 불러올 수 없습니다. 다시 시도해 주세요.",

    // Success messages
    ban_success: "{playerName} 님 차단 성공",
    ban_error: "플레이어 차단에 실패했습니다",
    identifier_copied: "식별자가 클립보드에 복사됨",
  },
  models: {
    // Page header
    title: "모델 조회",
    dashboard: "대시보드",
    description:
      "이름 또는 해시로 GTA V 모델을 검색하세요. 차량, 인물, 무기, 오브젝트까지 모두 찾을 수 있습니다.",

    // Header info
    models_count: "{count}개 모델",

    // View modes
    grid_view: "그리드 보기",
    list_view: "목록 보기",

    // Actions
    export_csv: "CSV로 내보내기",
    copy_name: "이름 복사",
    copy_hash: "해시 복사",

    // Search and filters
    search_filters: "검색 및 필터",
    search_filters_description:
      "모델 이름 또는 해시로 검색하고, 모델 유형별로 필터링하세요",
    search_placeholder: "모델 이름 또는 해시로 검색...",
    filter_by_type: "유형별 필터",

    // Model types
    all_types: "전체 유형",
    vehicles: "차량",
    peds: "인물",
    weapons: "무기",
    objects: "오브젝트",
    vehicle: "차량",
    ped: "인물",
    weapon: "무기",
    object: "오브젝트",
    explosions: "폭발",
    explosion: "폭발",

    // Quick filters
    all_models: "전체 ({count})",
    vehicles_count: "차량 ({count})",
    peds_count: "인물 ({count})",
    weapons_count: "무기 ({count})",
    objects_count: "오브젝트 ({count})",
    explosions_count: "폭발 ({count})",

    // Active filters
    active_filters: "적용된 필터:",
    search_filter: '검색: "{query}"',
    type_filter: "유형: {type}",

    // Table headers
    preview: "미리보기",
    model_name: "모델 이름",
    hash: "해시",
    type: "유형",
    actions: "동작",

    // Empty states
    no_models_found: "모델을 찾을 수 없습니다",
    no_models_search: '"{query}"(으)로 일치하는 모델 없음',
    no_models_filter: "선택한 필터에 해당하는 모델 없음",

    // Pagination
    showing_results: "{start}~{end} / 총 {total}개 모델",
    previous: "이전",
    next: "다음",
    page_of: "{total} 중 {page}페이지",

    // Toast messages
    name_copied: "모델 이름이 클립보드에 복사됨!",
    hash_copied: "해시가 클립보드에 복사됨!",
    csv_exported: "{count}개 모델을 CSV로 내보냈습니다!",

    // Fallback messages
    image_not_available: "이미지 없음",

    // Loading states
    loading: "로딩 중...",
    loading_models: "모델 불러오는 중...",
  },
  interactive_map: {
    // Page header
    title: "인터랙티브 지도",
    dashboard: "대시보드",
    description:
      "지도에서 실시간으로 플레이어와 소환된 엔티티를 확인하고 모니터링하세요.",

    // Map controls
    map_controls: "지도 컨트롤",
    map_style: "지도 스타일",

    // Player filters
    filter_players: "플레이어 필터",
    search_placeholder: "이름 또는 ID로 검색...",
    player_filters: "플레이어 필터",
    recently_connected: "최근 접속",
    recently_connected_desc: "온라인 접속 < 1시간인 플레이어",
    low_playtime: "플레이 시간 짧음",
    low_playtime_desc: "플레이 시간 < 60분",
    show_admins: "관리자만 보기",
    show_admins_desc: "관리자 권한 플레이어만 표시",

    // Player list
    players: "플레이어",
    no_players_found: "플레이어를 찾을 수 없습니다",

    // Player info
    player: "플레이어",
    id: "ID",
    status: "상태",
    online: "온라인",
    vehicle: "차량",
    in_vehicle: "차량 탑승 중",
    role: "역할",
    administrator: "관리자",
    playtime: "플레이 시간",

    // Coordinates
    marker_position: "마커 위치",
    coordinates: "좌표",

    // Area selection
    clear_selection: "선택 해제 ({count})",

    // Map styles
    atlas: "지도",
    satellite: "위성",
    grid: "격자",

    // Loading
    loading_map: "지도 불러오는 중...",

    // Actions
    copy_coordinates: "좌표 복사",
    center_on_player: "플레이어 중심으로 이동",
  },
  server_admins: {
    // Page header
    title: "서버 관리자",
    description: "WaveShield 서버의 관리자 권한을 관리하세요",
    dashboard: "대시보드",
    admin_dashboard: "관리자 대시보드",

    // Access denied
    access_denied: "접근 거부",
    access_denied_description:
      '이 서버의 관리자 권한을 관리할 수 없습니다. 서버 소유자에게 "관리자 관리" 권한을 요청하세요.',

    // Actions
    add_admin: "관리자 추가",
    edit_permissions: "권한 수정",
    remove_admin: "관리자 삭제",
    protected: "보호됨",

    // Add Admin Dialog
    add_new_admin: "새 관리자 추가",
    add_admin_description:
      "사용자를 검색해 권한을 할당하여 관리자로 지정하세요.",
    select_user: "사용자 선택",
    search_user_placeholder: "사용자 검색...",
    search_user_detailed_placeholder:
      "디스코드 ID, 사용자명, 이름으로 검색...",
    permissions_label: "권한",
    no_users_found: "사용자를 찾을 수 없습니다.",
    type_to_search: "사용자 검색어를 입력하세요...",
    searching: "검색 중...",
    adding: "추가 중...",
    add_admin_button: "관리자 추가",
    cancel: "취소",

    // Edit Admin Dialog
    edit_admin_permissions: "관리자 권한 수정",
    edit_admin_description: "{name} (@{username})님의 권한을 수정합니다",
    updating: "업데이트 중...",
    update_permissions: "권한 업데이트",

    // Delete Dialog
    remove_admin_title: "관리자 삭제",
    remove_admin_description:
      "{name} (@{username}) 님을 관리자로 삭제하시겠습니까? 이 작업은 되돌릴 수 없으며, 모든 관리자 권한이 사라집니다.",
    removing: "삭제 중...",

    // Filters & Search
    filters_search: "필터 및 검색",
    filters_search_description:
      "이름, 디스코드 ID 또는 권한으로 관리자를 검색/필터하세요",
    search_placeholder: "이름, 사용자명, 디스코드 ID로 검색...",
    permissions_filter: "권한",

    // Table
    admin_column: "관리자",
    discord_id_column: "디스코드 ID",
    permissions_column: "권한",
    added_column: "추가일",
    actions_column: "동작",
    owner_badge: "소유자",

    // Permissions
    all_permissions: "모든 권한",
    all_permissions_description: "서버의 모든 기능에 완전 접근",
    configuration: "설정 관리",
    configuration_description: "서버 설정 관리",
    download_files: "파일 다운로드",
    download_files_description: "서버 파일 다운로드",
    manage_admins: "관리자 관리",
    manage_admins_description: "관리자 추가, 수정, 삭제",
    bypass: "우회",
    bypass_description: "안티치트 감지 우회",
    players_kick: "플레이어 킥",
    players_kick_description: "서버에서 플레이어 강제 퇴장",
    view_logs: "로그 보기",
    view_logs_description: "서버 로그 보기",
    view_console: "콘솔 보기",
    view_console_description: "서버 콘솔 보기",
    run_commands: "명령어 실행",
    run_commands_description: "서버 콘솔에서 명령어 실행",
    manage_bans: "차단 관리",
    manage_bans_description: "서버 차단 관리",
    unban_all: "전체 차단 해제",
    unban_all_description: "서버의 모든 플레이어 차단 해제",
    players_lookup: "플레이어 조회",
    players_lookup_description: "서버에서 플레이어 조회",
    more_permissions: "추가 권한 {count}개 더 보기",

    // Empty states
    no_admins_found: "관리자를 찾을 수 없습니다",
    no_admins_description: "검색어나 필터를 변경해보세요",
    no_admins_description_empty: "첫 관리자를 추가해 시작해보세요",

    // Pagination
    page_of_pages: "{total} 중 {page}페이지",
    previous: "이전",
    next: "다음",

    // Status messages
    admin_count: "{count}명의 관리자{plural} 발견됨",
    admin_added_success: "관리자 추가 완료",
    admin_updated_success: "관리자 권한이 업데이트됨",
    admin_removed_success: "관리자 삭제 완료",
    admin_add_error: "관리자 추가에 실패했습니다",
    admin_update_error: "관리자 권한 업데이트에 실패했습니다",
    admin_remove_error: "관리자 삭제에 실패했습니다",

    // Validation
    select_user_and_permissions: "사용자와 최소 1개 이상의 권한을 선택하세요",
    select_at_least_one_permission: "최소 1개 이상의 권한을 선택하세요",

    // Loading states
    loading: "로딩 중...",
  },
  server_players: {
    // Page header
    title: "플레이어",
    online_players: "온라인 플레이어",
    dashboard: "대시보드",

    // Access denied
    access_denied: "접근 거부",
    access_denied_description:
      "이 서버의 플레이어 정보에 접근할 수 없습니다. 서버 소유자에게 멤버로 추가해 달라고 요청하세요.",

    // Server offline
    server_offline: "서버 오프라인",
    server_offline_description:
      "서버가 현재 오프라인 상태입니다. 서버가 온라인일 때만 플레이어 정보를 확인할 수 있습니다.",

    // Player statuses
    status: {
      on_foot: "도보 이동",
      in_vehicle: "차량 탑승 중",
      swimming: "수영 중",
      armed: "무장함",
      dead: "사망",
    },

    // Player badges
    admin: "관리자",
    new: "신규",
    just_joined: "방금 접속",
    off: "오프라인",

    // Time formats
    joined_time_ago: "{hours}시간 {minutes}분 전에 접속",
    played_time: "{hours}시간 {minutes}분 플레이",
    time_online: "온라인 시간",

    // Health
    health: "체력",

    // Ping
    ping_ms: "{ping}ms",

    // Search and filters
    search_placeholder: "이름 또는 ID로 플레이어 검색...",
    sort_filter: "정렬 및 필터",
    sort_by: "정렬 기준",
    name: "이름",
    player_id: "플레이어 ID",
    play_time: "플레이 시간",
    ping: "핑",
    time_online_sort: "온라인 시간",
    ascending: "오름차순 ✓",
    descending: "내림차순 ✓",

    // Threat score
    threat_score: "위험 점수",
    high_threat: "위험도 높음",
    medium_threat: "위험도 보통",
    low_threat: "위험도 낮음",
    minimal_threat: "위험도 최소",
    show_potential_threats: "잠재적 위협 보기",

    // Filter by status
    filter_by_status: "상태별 필터",
    all_players: "전체 플레이어",
    dead: "사망",
    armed: "무장함",
    in_vehicle: "차량 탑승 중",
    on_foot: "도보 이동",

    // Player type filters
    show_new_players: "신규 플레이어 보기 (플레이 시간 <1시간)",
    show_recently_joined: "최근 접속 플레이어 보기 (온라인 <30분)",

    // Empty states
    no_players_found: "플레이어를 찾을 수 없습니다",
    no_players_filters: "현재 필터에 일치하는 플레이어가 없습니다.",
    no_players_online: "현재 이 서버에 온라인 플레이어가 없습니다.",

    // Pagination
    showing_results: "{start}~{end} / 총 {total}명 플레이어",
    page_of: "{total} 중 {page}페이지",
    previous_page: "이전",
    next_page: "다음",

    // Player details modal
    player_details: "플레이어 상세 정보",
    player_details_description: "이 플레이어의 상세 정보 및 가능한 작업",
    player_name: "플레이어 이름",
    status_label: "상태",
    total_play_time: "총 플레이 시간",
    trust_score: "위험 점수",
    lookup_notice: "이 플레이어에 대한 더 자세한 정보를 원하시나요?",
    open_in_lookup: "플레이어 조회에서 열기",

    // Actions
    kick_player: "플레이어 킥",
    ban_player: "플레이어 차단",
    screenshot: "스크린샷",
    watch_player: "관전하기",
    watch_player_title: "플레이어 관전",
    watch_player_description: "플레이어의 현재 시점을 관전합니다",
    connecting_to_stream: "스트림에 연결 중...",
    stop_watching: "관전 중지",

    // Ban modal
    ban_player_title: "플레이어 차단",
    ban_player_description: "이 작업을 실행하면 플레이어가 서버에서 차단됩니다",
    ban_reason: "차단 사유",
    ban_reason_required: "차단 사유 *",
    ban_reason_placeholder: "이 플레이어 차단 사유를 입력하세요...",
    permanent_ban: "영구 차단",
    permanent_ban_description: "이 차단은 자동으로 만료되지 않습니다",
    temporary_ban_description:
      "설정한 시간이 지나면 이 차단은 자동으로 해제됩니다",
    duration_hours: "기간 (시간)",
    banning: "차단 중...",
    reason_required_error: "차단 사유를 입력해주세요",
    cancel_ban: "취소",

    // Kick modal
    kick_player_title: "플레이어 킥",
    kick_player_description:
      "이 작업을 실행하면 플레이어가 임시로 서버에서 퇴장됩니다",
    kick_reason: "킥 사유 (선택)",
    kick_reason_placeholder: "이 플레이어 킥 사유를 입력하세요...",
    kicking: "킥 중...",
    cancel_kick: "취소",

    // Screenshot modal
    screenshot_player_title: "플레이어 스크린샷",
    screenshot_player_description:
      "이 작업은 플레이어의 현재 시점 스크린샷을 캡처합니다",
    screenshot_notice:
      "스크린샷 요청이 플레이어 클라이언트로 전송됩니다. 캡처된 이미지는 서버에 설정된 디스코드 채널에 저장됩니다.",
    take_screenshot: "스크린샷 찍기",
    screenshot_title: "스크린샷",
    screenshot_description: "플레이어 클라이언트에서 캡처된 스크린샷",
    capturing_screenshot: "플레이어 클라이언트에서 스크린샷 캡처 중...",
    screenshot_wait_notice:
      "플레이어의 연결 상태에 따라 수 초 정도 소요될 수 있습니다",
    screenshot_captured: "스크린샷이 성공적으로 캡처됨",
    open_in_new_tab: "새 탭에서 열기",
    cancel_screenshot: "취소",

    // Screenshot failure
    screenshot_failed: "스크린샷 캡처 실패",
    screenshot_failed_description:
      "스크린샷 요청이 실패하거나 시간 초과되었습니다. 가능한 원인:",
    screenshot_error_1: "플레이어가 스크린샷 요청에 응답하지 않음",
    screenshot_error_2: "네트워크 연결 문제",
    screenshot_error_3: "플레이어 클라이언트가 스크린샷을 지원하지 않음",

    // Spectate
    spectate_notice: "관전 기능은 곧 지원될 예정입니다",

    // Loading states
    loading_players: "로딩 중...",
  },
  server_multistream: {
    // Page title
    title: "멀티 스트림",

    // Access denied
    access_denied: "접근 거부",
    access_denied_description:
      "이 서버의 멀티 스트림에 접근할 수 없습니다. 서버 소유자에게 멤버로 추가해 달라고 요청하세요.",

    // Server offline
    server_offline: "서버 오프라인",
    server_offline_description:
      "이 서버는 현재 오프라인입니다. 멀티 스트림은 서버가 온라인일 때만 사용할 수 있습니다.",

    // Sidebar header
    players: "플레이어",

    // Search and controls
    search_placeholder: "이름 또는 ID로 검색...",
    sort_field_name: "이름",
    sort_field_playtime: "플레이 시간",
    sort_field_threat_score: "위험 점수",
    sort_field_join_time: "접속 시간",
    select_all: "전체 선택",
    select_none: "전체 해제",

    // Filters
    filters: "필터",
    recently_joined: "최근 접속",
    new_players: "신규 플레이어",
    potential_threats: "잠재적 위협",
    admins: "관리자",

    // Player badges and status
    admin: "관리자",
    just_joined: "방금 접속",
    low_playtime: "플레이 시간 짧음",
    threat_score_tooltip:
      "플레이어의 위험 점수를 표시합니다. 모든 서버의 과거 데이터를 기반으로 산출됩니다.",
    admin_tooltip: "서버 관리자(특별 권한 보유)",
    just_joined_tooltip: "30분 이내에 서버에 접속한 플레이어",
    low_playtime_tooltip: "총 플레이 시간이 1시간 미만인 플레이어",

    // Ping status
    ping_off: "오프라인",

    // Empty states
    no_players_match_filters: "필터에 맞는 플레이어 없음",
    no_players_match_filters_description:
      "검색어나 필터 설정을 변경해 다시 시도해 보세요.",
    no_players_selected: "선택된 플레이어 없음",
    no_players_selected_description:
      "스트리밍을 시작하려면 사이드바에서 플레이어를 선택하세요.",
    scroll_to_load_stream: "스트림을 불러오려면 스크롤하세요.",

    // Stream quality indicators
    stream_quality: "화질",
    stream_latency: "지연 시간",

    // Loading states
    loading: "로딩 중...",
    connecting_to_stream: "스트림에 연결 중...",
  },
  landing: {
    // Navigation
    nav: {
      home: "홈",
      features: "기능",
      pricing: "요금제",
      faqs: "자주 묻는 질문",
      signin: "로그인",
      panel: "패널",
    },

    // Hero Section
    hero: {
      badge: "신규: 대형 업데이트 출시!",
      title: "FiveM 서버를 5분 만에 안전하게 지키세요",
      subtitle:
        "궁극의 안티치트 및 플레이어 인텔리전스 솔루션. 한 곳에서 플레이어를 추적, 분석, 모니터링하세요.",
      get_started: "시작하기",
      try_demo: "데모 사용해보기",
      dashboard_alt: "WaveShield 대시보드",
    },

    // Features Section
    features: {
      title: "한 차원 높은 보호, 강력한 기능",
      subtitle:
        "실시간 모니터링부터 AI 기반 감지까지, 다양한 기능이 서버를 완벽히 보호합니다.",
      list: {
        web_panel: {
          title: "실시간 웹 패널",
          description:
            "인터랙티브 지도와 멀티 스트림 뷰로 모든 플레이어를 실시간으로 모니터링하세요. 플레이어 상세 정보 확인, 라이브 차단, 서버 관리까지 하나의 대시보드에서 가능합니다.",
        },
        network_intelligence: {
          title: "네트워크 인텔리전스",
          description:
            "WaveShield는 전체 생태계의 플레이어 행동을 분석하여, 의심스러운 패턴과 알려진 치터를 사전 탐지합니다.",
        },
        plug_play: {
          title: "간편 설치",
          description:
            "WaveShield는 모든 스크립트와 즉시 호환됩니다. AI 기반 설정 덕분에 복잡한 설정 없이 바로 사용하세요.",
        },
        anti_aimbot: {
          title: "안티-에임봇",
          description:
            "최첨단 알고리즘으로 고급 에임봇도 정밀 탐지 — 부드러운 에임, 랜덤 타깃까지 오탐 없이 잡아냅니다.",
        },
        event_protection: {
          title: "이벤트 보호",
          description:
            "클라이언트와 서버 이벤트를 자동으로 보호하고 암호화합니다. 익스플로잇 시도를 차단하기 위해 이름과 페이로드까지 난독화합니다.",
        },
        advanced_detections: {
          title: "고급 탐지",
          description:
            "WaveShield는 업계 최고 수준의 치트 탐지력과 0% 오탐률을 자랑합니다. 각종 익스플로잇과 인젝션을 실시간으로 차단하며, 매일 업데이트로 항상 최신 위협을 방어합니다.",
        },
      },
    },

    // Pricing Section
    pricing: {
      title: "보호 플랜을 선택하세요",
      subtitle:
        "오늘 바로 서버를 보호하세요. 모든 요금제는 모든 기능이 포함됩니다.",
      popular_badge: "🏆 인기 요금제",
      features: {
        instant_delivery: "즉시 제공",
        all_features: "WaveShield 전체 기능",
        web_panel: "실시간 웹 패널",
        support: "24/7 지원",
      },
      plans: {
        monthly: {
          name: "월간",
          price: "€50",
          period: "월",
          feature_1: "1개월 이용권",
        },
        quarterly: {
          name: "분기",
          price: "€100",
          period: "3개월",
          feature_1: "3개월 이용권",
        },
        lifetime: {
          name: "평생",
          price: "€250",
          period: "영구",
          feature_1: "영구 이용권",
        },
      },
      premium: {
        name: "프리미엄 패키지",
        price: "€60",
        period: "1회 설치",
        description: "전문가 설치 및 설정 서비스",
        perfect_for: "대형 서버에 적합",
        expert_setup: "전문가 셋업 및 최적화",
        features: {
          installation: "전문가 설치 및 설정",
          optimization: "서버 맞춤 최적화",
          updates: "사전 업데이트 제공",
          premium_features: "프리미엄 전용 기능",
          discount: "추가 서버 할인",
          support: "우선 1:1 지원",
        },
      },
      purchase: "구매하기",
      email_notice: "귀하의 이메일은 라이센스 키 전송에만 사용됩니다",
      discount: {
        label: "할인 코드",
        optional: "선택사항",
        placeholder: "할인 코드 입력",
        applied: "할인 적용됨",
        off: "할인",
        original_price: "정상가",
        discount: "할인",
        final_price: "최종 가격",
        invalid: "유효하지 않거나 만료된 할인 코드",
      },
      terms: {
        accept: "다음에 동의합니다",
        terms: "서비스 약관",
        and: "및",
        privacy: "개인정보 보호정책",
      },
    },

    // FAQ Section
    faq: {
      title: "자주 묻는 질문",
      subtitle: "궁금한 점이 있으신가요? 답변을 확인하세요.",
      questions: {
        how_prevents: {
          question: "WaveShield는 어떻게 치트를 방지하나요?",
          answer:
            "WaveShield는 실시간으로 치트, 핵, 의심스러운 행동을 똑똑하게 감지하여 즉시 관리자에게 알립니다.",
        },
        what_detections: {
          question: "WaveShield는 어떤 종류의 치트를 감지하나요?",
          answer:
            "WaveShield는 모든 종류의 치트, 익스플로잇, 인젝션을 감지합니다. 새로운 위협을 항상 앞서 감지하고, WaveShield를 지속적으로 업데이트하여 최상의 보호를 제공합니다.",
        },
        slow_server: {
          question: "WaveShield를 사용하면 서버가 느려지나요?",
          answer:
            "아니요. 백그라운드에서 조용히 동작하여 렉이나 일반 플레이어에게 영향을 주지 않습니다.",
        },
        free_trial: {
          question: "WaveShield에서 무료 평가판을 제공하나요?",
          answer:
            "네, 대화형 데모를 통해 패널을 탐색할 수 있습니다. 디스코드를 통해 요청하면 무료 짧은 평가판도 제공됩니다.",
        },
        easy_install: {
          question: "WaveShield 설치가 쉬운가요?",
          answer:
            "네! 간단한 가이드만 따르면 5분 내에 완벽 보호를 시작할 수 있습니다. 설정은 자동으로 이루어지며, WaveShield를 즉시 사용할 수 있습니다. 필요시 지원팀이 도와드립니다.",
        },
        bypass: {
          question: "치터가 WaveShield를 우회할 수 있나요?",
          answer:
            "WaveShield는 지속적으로 업데이트되어 새로운 치트를 잡아냅니다. 완벽한 시스템은 없지만, 저희가 치터 방어에는 최고입니다.",
        },
        works_scripts: {
          question: "WaveShield는 내 스크립트와 호환되나요?",
          answer:
            "물론입니다. 기존 스크립트와 완벽하게 호환되며 충돌이 없습니다.",
        },
        after_buying: {
          question: "구매 후에는 무엇을 해야 하나요?",
          answer:
            "구매 후, 이메일로 받은 정보를 이용해 온라인 패널에서 라이선스를 등록하세요. 그 다음 다운로드하여 서버를 보호하세요.",
        },
        multiple_servers: {
          question: "여러 서버에서 WaveShield를 사용할 수 있나요?",
          answer:
            "라이선스 1개는 서버 1대에만 적용됩니다. 여러 서버를 보호하려면 추가 라이선스가 필요합니다. 단, 개발 목적 등으로 IP는 언제든 변경 가능합니다.",
        },
      },
    },

    // Need Help Section
    need_help: {
      title: "도움이 필요하신가요?",
      subtitle:
        "커뮤니티에 참여해 지원을 받고, 최신 소식 및 서버 운영자들과 소통하세요.",
      join_discord: "디스코드 참여",
      get_started: "지금 시작하기",
      stats: {
        experience: {
          label: "운영 경험(년)",
        },
        servers: {
          label: "보호 서버 수",
        },
        bans: {
          label: "누적 차단 수",
        },
      },
    },

    // Footer Section
    footer: {
      description:
        "5년 이상의 실시간 치트 탐지 및 플레이어 모니터링 경험을 바탕으로 한 가장 진보된 FiveM 서버 보안 솔루션.",
      navigation: {
        title: "내비게이션",
        home: "홈",
        features: "기능",
        pricing: "요금제",
        faqs: "자주 묻는 질문",
      },
      legal: {
        title: "법적 고지",
        terms: "이용 약관",
        privacy: "개인정보 처리방침",
        refund: "환불 정책",
      },
      support: {
        title: "고객 지원",
        discord: "디스코드 지원",
        documentation: "문서",
      },
      status: "시스템 상태",
      copyright: "© Copyright {year}, All Rights Reserved by WaveShield",
    },
  },
} as const;