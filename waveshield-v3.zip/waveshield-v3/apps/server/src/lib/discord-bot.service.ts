import { randomUUID } from "crypto";
import type { Interaction } from "discord.js";
import {
  ActivityType,
  AttachmentBuilder,
  ChatInputCommandInteraction,
  Client,
  DiscordAPIError,
  GatewayIntentBits,
  MessageFlags,
  REST,
  Routes,
  SlashCommandBuilder,
} from "discord.js";
import prisma from "../../prisma";
import discordBotConfig from "./discord-bot.config";
import { discordUserService } from "../services/discord-user.service";
import { DiscountType } from "@waveshield/database";

// Define LicenseType enum to match the Prisma schema
type LicenseType =
  | "TRIAL"
  | "MONTHLY"
  | "QUARTERLY"
  | "BIANUALLY"
  | "YEARLY"
  | "LIFETIME";

class DiscordBotService {
  private client: Client;
  private commands: any[] = [];
  private statusUpdateInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.client = new Client({
      intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
    });

    this.registerCommands();
    this.setupEventHandlers();
  }

  private registerCommands() {
    // Ban command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("ban")
        .setDescription("Ban a license key")
        .addStringOption((option) =>
          option
            .setName("license_key")
            .setDescription("The license key to ban")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("reason")
            .setDescription("Reason for banning")
            .setRequired(true)
        )
    );

    // Unban command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("unban")
        .setDescription("Unban a license key")
        .addStringOption((option) =>
          option
            .setName("license_key")
            .setDescription("The license key to unban")
            .setRequired(true)
        )
    );

    // Check Ban command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("checkban")
        .setDescription("Check if a license key is banned")
        .addStringOption((option) =>
          option
            .setName("license_key")
            .setDescription("The license key to check")
            .setRequired(true)
        )
    );

    // Reset IP command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("resetip")
        .setDescription("Reset IP for a license key")
        .addStringOption((option) =>
          option
            .setName("license_key")
            .setDescription("The license key to reset IP for")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("reason")
            .setDescription("Reason for manual IP reset")
            .setRequired(false)
        )
    );

    // Create version command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("createversion")
        .setDescription("Create a new version")
        .addStringOption((option) =>
          option
            .setName("version")
            .setDescription("The version to create")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("changelog")
            .setDescription("Version changelog")
            .setRequired(false)
        )
    );

    // Generate command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("generate")
        .setDescription("Generate new license keys")
        .addStringOption((option) =>
          option
            .setName("type")
            .setDescription("License type")
            .setRequired(true)
            .addChoices(
              { name: "Trial", value: "TRIAL" },
              { name: "Monthly", value: "MONTHLY" },
              { name: "Quarterly", value: "QUARTERLY" },
              { name: "Bi-Annually", value: "BIANUALLY" },
              { name: "Yearly", value: "YEARLY" },
              { name: "Lifetime", value: "LIFETIME" }
            )
        )
        .addIntegerOption((option) =>
          option
            .setName("amount")
            .setDescription("Number of keys to generate")
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(40)
        )
    );

    // Create discount command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("creatediscount")
        .setDescription("Create a new discount code")
        .addStringOption((option) =>
          option
            .setName("code")
            .setDescription("Discount code (3-20 alphanumeric characters)")
            .setRequired(true)
        )
        .addStringOption((option) =>
          option
            .setName("type")
            .setDescription("Discount type")
            .setRequired(true)
            .addChoices(
              { name: "Percentage", value: "PERCENTAGE" },
              { name: "Fixed Amount", value: "FIXED_AMOUNT" }
            )
        )
        .addIntegerOption((option) =>
          option
            .setName("value")
            .setDescription("Discount value (percentage 1-100 or fixed amount in EUR)")
            .setRequired(true)
            .setMinValue(1)
            .setMaxValue(250)
        )
        .addStringOption((option) =>
          option
            .setName("description")
            .setDescription("Discount description")
            .setRequired(false)
        )
        .addBooleanOption((option) =>
          option
            .setName("auto_apply")
            .setDescription("Auto-apply this discount (shown automatically)")
            .setRequired(false)
        )
        .addIntegerOption((option) =>
          option
            .setName("expires_in_days")
            .setDescription("Number of days until expiration (leave empty for no expiration)")
            .setRequired(false)
            .setMinValue(1)
            .setMaxValue(365)
        )
    );

    // Delete discount command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("deletediscount")
        .setDescription("Delete a discount code")
        .addStringOption((option) =>
          option
            .setName("code")
            .setDescription("Discount code to delete")
            .setRequired(true)
        )
    );

    // List discounts command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("listdiscounts")
        .setDescription("List all active discount codes")
        .addBooleanOption((option) =>
          option
            .setName("include_expired")
            .setDescription("Include expired discounts")
            .setRequired(false)
        )
    );

    // Toggle discount command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("togglediscount")
        .setDescription("Enable or disable a discount code")
        .addStringOption((option) =>
          option
            .setName("code")
            .setDescription("Discount code to toggle")
            .setRequired(true)
        )
    );

    // Sync roles command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("syncroles")
        .setDescription("Sync customer roles for all valid license holders")
    );

    // Sync members command
    this.commands.push(
      new SlashCommandBuilder()
        .setName("syncmembers")
        .setDescription("Attempt to join all users with linked Discord accounts to the server")
    );
  }

  private hasPermission(member: any, allowedRoleIds: string[]): boolean {
    // Owner always has permission
    if (member?.user?.id === discordBotConfig.ownerId) return true;

    if (!member || !("roles" in member)) return false;

    try {
      // Check if member.roles is a GuildMemberRoleManager (has cache property)
      if (
        typeof member.roles === "object" &&
        member.roles &&
        "cache" in member.roles
      ) {
        return allowedRoleIds.some((roleId) => member.roles.cache.has(roleId));
      }
      // Check if member.roles is a string array (API member)
      else if (Array.isArray(member.roles)) {
        return allowedRoleIds.some((roleId) => member.roles.includes(roleId));
      }
    } catch (error) {
      console.warn("Error checking permissions", {
        error,
        userId: member?.user?.id,
      });
    }

    return false;
  }

  private setupEventHandlers() {
    this.client.once("ready", async () => {
      console.info("Discord bot is ready!");

      await this.updateBotStatus();

      // Set up status update interval (every 10 minutes)
      this.statusUpdateInterval = setInterval(() => {
        this.updateBotStatus();
      }, 10 * 60 * 1000); // 10 minutes
    });

    this.client.on("interactionCreate", async (interaction) => {
      if (!interaction.isCommand()) return;

      // Ensure we're in a guild context
      if (!interaction.guild || !interaction.member) {
        await this.safeReply(interaction as ChatInputCommandInteraction, {
          content: "This command can only be used in a server.",
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      // Check permissions
      const member = interaction.member;
      const commandName = interaction.commandName;

      // Define commands accessible by support role
      const supportCommands = ["unban", "resetip", "checkban"];

      // Admin role always has access. Support role has access to specific commands.
      const allowedRoles = [discordBotConfig.adminRoleId];
      if (supportCommands.includes(commandName)) {
        allowedRoles.push(discordBotConfig.operatorRoleId);
      }

      // Filter out empty role IDs to avoid false matches if config is missing
      const validAllowedRoles = allowedRoles.filter((id) => id && id.length > 0);

      if (!this.hasPermission(member, validAllowedRoles)) {
        await this.safeReply(interaction as ChatInputCommandInteraction, {
          content: "You do not have permission to use this command.",
          flags: MessageFlags.Ephemeral,
        });
        return;
      }

      await this.handleCommand(interaction as ChatInputCommandInteraction);
    });
  }

  /**
   * Safely reply to an interaction with error handling for expired interactions
   */
  private async safeReply(interaction: Interaction, options: any) {
    try {
      if (!interaction.isRepliable()) return;

      if (interaction.deferred || interaction.replied) {
        await interaction.editReply(options);
      } else {
        await interaction.reply(options);
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        // Interaction has expired or is invalid, log but don't throw
        console.warn("Attempted to respond to an expired interaction", {
          interactionId: interaction.id,
        });
      } else {
        // For other errors, log them
        console.error("Error responding to interaction", { error });
      }
    }
  }

  private async updateBotStatus() {
    try {
      const latestVersion = await prisma.version.findFirst({
        orderBy: {
          updatedAt: "desc",
        },
      });

      if (latestVersion) {
        this.client.user?.setActivity({
          name: `v${latestVersion.version}`,
          type: ActivityType.Watching,
        });

        console.debug("Updated bot status with version", {
          version: latestVersion.version,
        });
      }
    } catch (error) {
      console.error("Failed to update bot status", { error });
    }
  }

  private async handleCommand(interaction: ChatInputCommandInteraction) {
    const commandName = interaction.commandName;

    switch (commandName) {
      case "ban":
        await this.handleBanCommand(interaction);
        break;
      case "unban":
        await this.handleUnbanCommand(interaction);
        break;
      case "checkban":
        await this.handleCheckBanCommand(interaction);
        break;
      case "resetip":
        await this.handleResetIpCommand(interaction);
        break;
      case "generate":
        await this.handleGenerateCommand(interaction);
        break;
      case "createversion":
        await this.handleCreateVersionCommand(interaction);
        break;
      case "creatediscount":
        await this.handleCreateDiscountCommand(interaction);
        break;
      case "deletediscount":
        await this.handleDeleteDiscountCommand(interaction);
        break;
      case "listdiscounts":
        await this.handleListDiscountsCommand(interaction);
        break;
      case "togglediscount":
        await this.handleToggleDiscountCommand(interaction);
        break;
      case "syncroles":
        await this.handleSyncRolesCommand(interaction);
        break;
      case "syncmembers":
        await this.handleSyncMembersCommand(interaction);
        break;
      default:
        await this.safeReply(interaction, {
          content: "Unknown command",
          flags: MessageFlags.Ephemeral,
        });
    }
  }

  private async handleCreateVersionCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({
        flags: MessageFlags.Ephemeral,
      });

      const version = interaction.options.getString("version", true);
      const changelog = interaction.options.getString("changelog");

      // Validate version format - basic validation for x.y.z format
      const versionRegex = /^\d+(\.\d+){0,2}$/;
      if (!versionRegex.test(version)) {
        await this.safeReply(interaction, {
          content: "Invalid version format. Please use a format like 1.2.3",
        });
        return;
      }

      try {
        // First check if version already exists
        const existingVersion = await prisma.version.findUnique({
          where: {
            version: version,
          },
        });

        if (existingVersion) {
          await this.safeReply(interaction, {
            content: `Version ${version} already exists in the database.`,
          });
          return;
        }

        // Insert the new version
        await prisma.version.create({
          data: {
            version: version,
            changelog: changelog || null,
          },
        });

        await this.safeReply(interaction, {
          content: `Version ${version} has been created successfully.`,
        });
        console.info("New version created via Discord", {
          version,
          createdBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error creating new version via Discord", {
          error,
          version,
        });
        await this.safeReply(interaction, {
          content: "Failed to create new version. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while creating version", {
          version: interaction.options.getString("version"),
        });
      } else {
        console.error("Unexpected error in handleCreateVersionCommand", {
          error,
        });
      }
    }
  }

  private async handleBanCommand(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const licenseKey = interaction.options.getString("license_key", true);
      const reason = interaction.options.getString("reason", true);

      try {
        // Check if license exists
        const license = await prisma.license.findUnique({
          where: {
            licenseKey: licenseKey,
          },
        });

        if (!license) {
          await this.safeReply(interaction, {
            content: "License key not found.",
          });
          return;
        }

        if (license.isBanned) {
          await this.safeReply(interaction, {
            content: "License is already banned.",
          });
          return;
        }

        // Ban the license
        await prisma.license.update({
          where: {
            licenseKey: licenseKey,
          },
          data: {
            isBanned: true,
            banReason: reason,
          },
        });

        await this.safeReply(interaction, {
          content: `License key \`${licenseKey}\` has been banned. Reason: ${reason}`,
        });
        console.info("License banned via Discord", {
          licenseKey,
          reason,
          bannedBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error banning license via Discord", {
          error,
          licenseKey,
        });
        await this.safeReply(interaction, {
          content: "Failed to ban license. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while banning license");
      } else {
        console.error("Unexpected error in handleBanCommand", { error });
      }
    }
  }

  private async handleUnbanCommand(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const licenseKey = interaction.options.getString("license_key", true);

      try {
        // Check if license exists
        const license = await prisma.license.findUnique({
          where: {
            licenseKey: licenseKey,
          },
        });

        if (!license) {
          await this.safeReply(interaction, {
            content: "License key not found.",
          });
          return;
        }

        if (!license.isBanned) {
          await this.safeReply(interaction, {
            content: "License is not banned.",
          });
          return;
        }

        // Unban the license
        await prisma.license.update({
          where: {
            licenseKey: licenseKey,
          },
          data: {
            isBanned: false,
            banReason: null,
          },
        });

        await this.safeReply(interaction, {
          content: `License key \`${licenseKey}\` has been unbanned.`,
        });
        console.info("License unbanned via Discord", {
          licenseKey,
          unbannedBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error unbanning license via Discord", {
          error,
          licenseKey,
        });
        await this.safeReply(interaction, {
          content: "Failed to unban license. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while unbanning license");
      } else {
        console.error("Unexpected error in handleUnbanCommand", { error });
      }
    }
  }

  private async handleCheckBanCommand(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const licenseKey = interaction.options.getString("license_key", true);

      try {
        // Check if license exists
        const license = await prisma.license.findUnique({
          where: {
            licenseKey: licenseKey,
          },
          select: {
            isBanned: true,
            banReason: true,
          },
        });

        if (!license) {
          await this.safeReply(interaction, {
            content: "License key not found.",
          });
          return;
        }

        if (license.isBanned) {
          await this.safeReply(interaction, {
            content: `License key \`${licenseKey}\` is **BANNED**.\n**Reason:** ${
              license.banReason || "No reason provided"
            }`,
          });
        } else {
          await this.safeReply(interaction, {
            content: `License key \`${licenseKey}\` is **NOT** banned.`,
          });
        }

        console.info("License ban status checked via Discord", {
          licenseKey,
          isBanned: license.isBanned,
          checkedBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error checking license ban status via Discord", {
          error,
          licenseKey,
        });
        await this.safeReply(interaction, {
          content: "Failed to check license status. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while checking license ban status");
      } else {
        console.error("Unexpected error in handleCheckBanCommand", { error });
      }
    }
  }

  private async handleResetIpCommand(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const licenseKey = interaction.options.getString("license_key", true);
      const reason = interaction.options.getString("reason") || "Manual IP reset via Discord";

      try {
        // Check if license exists
        const license = await prisma.license.findUnique({
          where: {
            licenseKey: licenseKey,
          },
          include: {
            serverInfo: {
              select: {
                lastActiveAt: true,
              },
            },
          },
        });

        if (!license) {
          await this.safeReply(interaction, {
            content: "License key not found.",
          });
          return;
        }

        if (license.isBanned) {
          await this.safeReply(interaction, {
            content: "Cannot reset IP for a banned license.",
          });
          return;
        }

        // Check if server was active in the last 30 days (for informational purposes)
        const now = new Date();
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        const lastActiveAt = license.serverInfo?.lastActiveAt;
        const wasActiveLast30Days = lastActiveAt && lastActiveAt >= thirtyDaysAgo;

        // Reset the IP (manual override - bypasses activity check)
        await prisma.license.update({
          where: {
            licenseKey: licenseKey,
          },
          data: {
            serverIp: null,
          },
        });

        // Log the activity
        await prisma.serverLog.create({
          data: {
            licenseId: license.id,
            systemType: "IP_RESET",
            details: {
              reason: reason,
            },
          },
        });

        const activityStatus = wasActiveLast30Days ? "(server was active in last 30 days)" : "(server was inactive in last 30 days - manual override)";
        
        await this.safeReply(interaction, {
          content: `IP reset successfully for license key \`${licenseKey}\` ${activityStatus}.\nReason: ${reason}`,
        });
        
        console.info("License IP reset via Discord", {
          licenseKey,
          reason,
          wasActiveLast30Days,
          resetBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error resetting IP via Discord", {
          error,
          licenseKey,
        });
        await this.safeReply(interaction, {
          content: "Failed to reset IP. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while resetting IP");
      } else {
        console.error("Unexpected error in handleResetIpCommand", { error });
      }
    }
  }

  private async handleGenerateCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const licenseType = interaction.options.getString(
        "type",
        true
      ) as LicenseType;
      const amount = interaction.options.getInteger("amount", true);

      try {
        const keys: string[] = [];

        // Generate and insert keys
        for (let i = 0; i < amount; i++) {
          // Generate a random license key
          const licenseKey = `waveshield-${licenseType.toLowerCase()}-${randomUUID()}`;

          // Insert into database
          await prisma.redemptionKey.create({
            data: {
              type: licenseType,
              licenseKey: licenseKey,
              generatedBy: interaction.user.tag,
            },
          });

          keys.push(licenseKey);
        }

        // Create a text file with one key per line
        const keysContent = keys.join("\n");
        const buffer = Buffer.from(keysContent, "utf-8");

        // Create attachment with the keys
        const attachment = new AttachmentBuilder(buffer, {
          name: `waveshield-${licenseType.toLowerCase()}-keys-${Date.now()}.txt`,
          description: `Generated ${amount} ${licenseType.toLowerCase()} license keys`,
        });

        await this.safeReply(interaction, {
          content: `Generated ${amount} ${licenseType.toLowerCase()} license key(s). Keys are attached in the file below:`,
          files: [attachment],
        });

        console.info("License keys generated via Discord", {
          amount,
          licenseType,
          generatedBy: interaction.user.id,
        });
      } catch (error) {
        console.error("Error generating license keys via Discord", {
          error,
          licenseType,
          amount,
        });
        await this.safeReply(interaction, {
          content: "Failed to generate license keys. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while generating license keys");
      } else {
        console.error("Unexpected error in handleGenerateCommand", { error });
      }
    }
  }

  private async handleCreateDiscountCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const code = interaction.options.getString("code", true).toUpperCase().trim();
      const type = interaction.options.getString("type", true) as "PERCENTAGE" | "FIXED_AMOUNT";
      const value = interaction.options.getInteger("value", true);
      const description = interaction.options.getString("description");
      const autoApply = interaction.options.getBoolean("auto_apply") ?? false;
      const expiresInDays = interaction.options.getInteger("expires_in_days");

      try {
        // Validate code format
        const codeRegex = /^[A-Z0-9]{3,20}$/;
        if (!codeRegex.test(code)) {
          await this.safeReply(interaction, {
            content: "Invalid discount code format. Use 3-20 alphanumeric characters only.",
          });
          return;
        }

        // Check if code already exists
        const existingDiscount = await prisma.discount.findUnique({
          where: { code },
        });

        if (existingDiscount) {
          await this.safeReply(interaction, {
            content: `Discount code \`${code}\` already exists.`,
          });
          return;
        }

        // Validate value based on type
        if (type === "PERCENTAGE" && (value < 1 || value > 100)) {
          await this.safeReply(interaction, {
            content: "Percentage discount must be between 1 and 100.",
          });
          return;
        }

        // Calculate expiration date
        let expiresAt: Date | null = null;
        if (expiresInDays) {
          expiresAt = new Date();
          expiresAt.setDate(expiresAt.getDate() + expiresInDays);
        }

        // Create discount
        const discount = await prisma.discount.create({
          data: {
            code,
            discountType: type === "PERCENTAGE" ? DiscountType.PERCENTAGE : DiscountType.FIXED_AMOUNT,
            discountAmount: type === "FIXED_AMOUNT" ? value : 0,
            discountPercentage: type === "PERCENTAGE" ? value : 0,
            description: description || null,
            autoApply: autoApply,
            expiresAt,
            isActive: true,
          },
        });

        const typeStr = type === "PERCENTAGE" ? `${value}%` : `€${value}`;
        const expiryStr = expiresAt ? `\nExpires: ${expiresAt.toISOString().split('T')[0]}` : "\nNo expiration";
        const autoApplyStr = autoApply ? "\n✨ **Auto-applied** (shown automatically to users)" : "";

        await this.safeReply(interaction, {
          content: `✅ Discount code created successfully!\n\n**Code:** \`${code}\`\n**Type:** ${typeStr}\n**Description:** ${description || "None"}${expiryStr}${autoApplyStr}`,
        });

        console.info("Discount created via Discord", {
          code,
          type,
          value,
          autoApply,
          createdBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error creating discount via Discord", { error, code });
        await this.safeReply(interaction, {
          content: "Failed to create discount. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while creating discount");
      } else {
        console.error("Unexpected error in handleCreateDiscountCommand", { error });
      }
    }
  }

  private async handleDeleteDiscountCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const code = interaction.options.getString("code", true).toUpperCase().trim();

      try {
        // Check if discount exists
        const discount = await prisma.discount.findUnique({
          where: { code },
        });

        if (!discount) {
          await this.safeReply(interaction, {
            content: `Discount code \`${code}\` not found.`,
          });
          return;
        }

        // Delete the discount
        await prisma.discount.delete({
          where: { code },
        });

        await this.safeReply(interaction, {
          content: `✅ Discount code \`${code}\` has been deleted successfully.`,
        });

        console.info("Discount deleted via Discord", {
          code,
          deletedBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error deleting discount via Discord", { error, code });
        await this.safeReply(interaction, {
          content: "Failed to delete discount. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while deleting discount");
      } else {
        console.error("Unexpected error in handleDeleteDiscountCommand", { error });
      }
    }
  }

  private async handleListDiscountsCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const includeExpired = interaction.options.getBoolean("include_expired") ?? false;

      try {
        const now = new Date();
        
        // Build where clause
        const whereClause: any = {};
        if (!includeExpired) {
          whereClause.OR = [
            { expiresAt: null },
            { expiresAt: { gt: now } },
          ];
        }

        const discounts = await prisma.discount.findMany({
          where: whereClause,
          orderBy: { createdAt: "desc" },
        });

        if (discounts.length === 0) {
          await this.safeReply(interaction, {
            content: includeExpired 
              ? "No discounts found." 
              : "No active discounts found. Use `include_expired: true` to see expired discounts.",
          });
          return;
        }

        // Format discounts into a readable list
        let message = `**Discount Codes (${discounts.length}):**\n\n`;
        
        for (const discount of discounts) {
          const isExpired = discount.expiresAt && discount.expiresAt < now;
          const isActive = discount.isActive && !isExpired;
          
          const statusEmoji = isActive ? "✅" : isExpired ? "⏰" : "❌";
          const typeValue = discount.discountType === DiscountType.PERCENTAGE 
            ? `${discount.discountPercentage}%` 
            : `€${discount.discountAmount}`;
          const autoApplyBadge = discount.autoApply ? " ✨" : "";
          const expiryStr = discount.expiresAt 
            ? ` | Expires: ${discount.expiresAt.toISOString().split('T')[0]}` 
            : "";
          
          message += `${statusEmoji} \`${discount.code}\`${autoApplyBadge} - ${typeValue}${expiryStr}\n`;
          if (discount.description) {
            message += `   └ ${discount.description}\n`;
          }
        }

        message += `\n**Legend:**\n✅ Active | ❌ Disabled | ⏰ Expired | ✨ Auto-applied`;

        await this.safeReply(interaction, {
          content: message,
        });

        console.info("Discounts listed via Discord", {
          count: discounts.length,
          includeExpired,
          requestedBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error listing discounts via Discord", { error });
        await this.safeReply(interaction, {
          content: "Failed to list discounts. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while listing discounts");
      } else {
        console.error("Unexpected error in handleListDiscountsCommand", { error });
      }
    }
  }

  private async handleToggleDiscountCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      const code = interaction.options.getString("code", true).toUpperCase().trim();

      try {
        // Check if discount exists
        const discount = await prisma.discount.findUnique({
          where: { code },
        });

        if (!discount) {
          await this.safeReply(interaction, {
            content: `Discount code \`${code}\` not found.`,
          });
          return;
        }

        // Toggle the active status
        const updatedDiscount = await prisma.discount.update({
          where: { code },
          data: { isActive: !discount.isActive },
        });

        const statusText = updatedDiscount.isActive ? "enabled ✅" : "disabled ❌";

        await this.safeReply(interaction, {
          content: `Discount code \`${code}\` has been ${statusText}.`,
        });

        console.info("Discount toggled via Discord", {
          code,
          newStatus: updatedDiscount.isActive,
          toggledBy: interaction.user.tag,
        });
      } catch (error) {
        console.error("Error toggling discount via Discord", { error, code });
        await this.safeReply(interaction, {
          content: "Failed to toggle discount. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while toggling discount");
      } else {
        console.error("Unexpected error in handleToggleDiscountCommand", { error });
      }
    }
  }

  private async handleSyncRolesCommand(interaction: ChatInputCommandInteraction) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      try {
        // Fetch all distinct discord IDs from non-banned licenses
        const licenses = await prisma.license.findMany({
          where: {
            isBanned: false,
            discordId: {
              not: "", // Ensure not empty
            },
          },
          select: {
            discordId: true,
          },
          distinct: ["discordId"],
        });

        const totalUsers = licenses.length;

        if (totalUsers === 0) {
          await this.safeReply(interaction, {
            content: "No valid license holders found.",
          });
          return;
        }

        // Calculate estimated time (200ms per user)
        const estimatedMinutes = Math.ceil((totalUsers * 250) / 1000 / 60);

        await this.safeReply(interaction, {
          content: `Found **${totalUsers}** unique valid license holders.\nStarting role sync process...\n\n⏱️ Estimated time: ~${estimatedMinutes} minutes.\n\nThis process will run in the background. Check server logs for detailed progress.`,
        });

        console.info("Starting role sync via Discord command", {
          totalUsers,
          requestedBy: interaction.user.tag,
        });

        // Run in background
        this.processRoleSync(licenses.map((l) => l.discordId), interaction).catch(
          (err) => console.error("Background role sync failed", err)
        );
      } catch (error) {
        console.error("Error initiating role sync via Discord", { error });
        await this.safeReply(interaction, {
          content: "Failed to start role sync. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while syncing roles");
      } else {
        console.error("Unexpected error in handleSyncRolesCommand", { error });
      }
    }
  }

  private async processRoleSync(
    discordIds: string[],
    interaction: ChatInputCommandInteraction
  ) {
    let successCount = 0;
    let failCount = 0;
    let skippedCount = 0;

    console.info(`Starting background role sync for ${discordIds.length} users...`);

    const startTime = Date.now();

    for (let i = 0; i < discordIds.length; i++) {
      const userId = discordIds[i];

      try {
        // Rate limiting: 250ms delay (reduced from original plan to be safer)
        // This is a conservative limit to avoid hitting Discord API limits
        await new Promise((resolve) => setTimeout(resolve, 250));

        const result = await discordUserService.addCustomerRole(userId);

        if (result.success) {
          successCount++;
        } else {
          // If user is not in server (404)
          if (result.status === 404) {
            skippedCount++;
          } else {
            failCount++;
          }
        }

        // Log progress every 50 users
        if ((i + 1) % 50 === 0) {
          console.info(
            `Role sync progress: ${i + 1}/${discordIds.length} (Success: ${successCount}, Skipped: ${skippedCount}, Failed: ${failCount})`
          );
        }
      } catch (err) {
        console.error(`Error processing user ${userId} during sync`, err);
        failCount++;
      }
    }

    const durationSeconds = (Date.now() - startTime) / 1000;
    console.info(
      `Role sync completed in ${durationSeconds.toFixed(1)}s. Total: ${
        discordIds.length
      }, Success: ${successCount}, Skipped: ${skippedCount}, Failed: ${failCount}`
    );

    // Try to update the interaction if it's still valid
    try {
      await interaction.editReply({
        content: `✅ **Role Sync Completed**\n\n**Total Scanned:** ${discordIds.length}\n**Success:** ${successCount}\n**Skipped (not in server):** ${skippedCount}\n**Failed:** ${failCount}\n\n⏱️ Time taken: ${durationSeconds.toFixed(1)}s`,
      });
    } catch (e) {
      // Interaction likely expired if the job took too long, which is expected
      console.debug("Could not update interaction with final stats (likely expired)");
    }
  }

  private async handleSyncMembersCommand(
    interaction: ChatInputCommandInteraction
  ) {
    try {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });

      try {
        // Fetch all accounts with Discord provider and access token
        const accounts = await prisma.account.findMany({
          where: {
            providerId: "discord",
            accessToken: {
              not: null,
            },
            accountId: {
              not: "", // Ensure not empty
            },
          },
          select: {
            accountId: true, // This is the Discord User ID
          },
          distinct: ["accountId"],
        });

        const totalUsers = accounts.length;

        if (totalUsers === 0) {
          await this.safeReply(interaction, {
            content: "No users with linked Discord accounts found.",
          });
          return;
        }

        // Calculate estimated time (250ms per user)
        const estimatedMinutes = Math.ceil((totalUsers * 250) / 1000 / 60);

        await this.safeReply(interaction, {
          content: `Found **${totalUsers}** users with linked Discord accounts.\nStarting member join sync process...\n\n⏱️ Estimated time: ~${estimatedMinutes} minutes.\n\nThis process will run in the background. Check server logs for detailed progress.`,
        });

        console.info("Starting member join sync via Discord command", {
          totalUsers,
          requestedBy: interaction.user.tag,
        });

        // Run in background
        this.processMemberSync(
          accounts.map((a) => a.accountId),
          interaction
        ).catch((err) =>
          console.error("Background member sync failed", err)
        );
      } catch (error) {
        console.error("Error initiating member sync via Discord", { error });
        await this.safeReply(interaction, {
          content: "Failed to start member sync. Check logs for details.",
        });
      }
    } catch (error) {
      if (error instanceof DiscordAPIError && error.code === 10062) {
        console.warn("Interaction expired while syncing members");
      } else {
        console.error("Unexpected error in handleSyncMembersCommand", {
          error,
        });
      }
    }
  }

  private async processMemberSync(
    discordIds: string[],
    interaction: ChatInputCommandInteraction
  ) {
    let successCount = 0;
    let alreadyMemberCount = 0;
    let failCount = 0;
    let invalidTokenCount = 0;

    console.info(
      `Starting background member sync for ${discordIds.length} users...`
    );

    const startTime = Date.now();

    for (let i = 0; i < discordIds.length; i++) {
      const userId = discordIds[i];

      try {
        // Rate limiting: 250ms delay
        await new Promise((resolve) => setTimeout(resolve, 250));

        const result = await discordUserService.joinUserToGuild(userId);

        if (result.success) {
          if (result.alreadyMember) {
            alreadyMemberCount++;
          } else {
            successCount++;
          }
        } else {
          // Handle different failure scenarios
          if (result.status === 401 || result.status === 403) {
            // Likely invalid token or revoked access
            invalidTokenCount++;
          } else {
            failCount++;
          }
        }

        // Log progress every 50 users
        if ((i + 1) % 50 === 0) {
          console.info(
            `Member sync progress: ${i + 1}/${
              discordIds.length
            } (Joined: ${successCount}, Already Member: ${alreadyMemberCount}, Invalid Token: ${invalidTokenCount}, Other Fail: ${failCount})`
          );
        }
      } catch (err) {
        console.error(`Error processing user ${userId} during member sync`, err);
        failCount++;
      }
    }

    const durationSeconds = (Date.now() - startTime) / 1000;
    console.info(
      `Member sync completed in ${durationSeconds.toFixed(1)}s. Total: ${
        discordIds.length
      }, Joined: ${successCount}, Already Member: ${alreadyMemberCount}, Invalid Token: ${invalidTokenCount}, Other Fail: ${failCount}`
    );

    // Try to update the interaction if it's still valid
    try {
      await interaction.editReply({
        content: `✅ **Member Join Sync Completed**\n\n**Total Scanned:** ${
          discordIds.length
        }\n**Joined:** ${successCount}\n**Already In Server:** ${alreadyMemberCount}\n**Invalid/Expired Tokens:** ${invalidTokenCount}\n**Other Errors:** ${failCount}\n\n⏱️ Time taken: ${durationSeconds.toFixed(
          1
        )}s`,
      });
    } catch (e) {
      console.debug(
        "Could not update interaction with final stats (likely expired)"
      );
    }
  }

  async registerSlashCommands() {
    try {
      const rest = new REST({ version: "10" }).setToken(discordBotConfig.token);

      // Convert SlashCommandBuilder instances to JSON
      const commandsJson = this.commands.map((command) => command.toJSON());

      console.info("Started refreshing application commands.");

      // Register commands globally or to a specific guild
      let data;
      if (discordBotConfig.guildId) {
        data = await rest.put(
          Routes.applicationGuildCommands(
            discordBotConfig.clientId,
            discordBotConfig.guildId
          ),
          { body: commandsJson }
        );
      } else {
        data = await rest.put(
          Routes.applicationCommands(discordBotConfig.clientId),
          { body: commandsJson }
        );
      }

      console.info(`Successfully reloaded application commands.`);
      return true;
    } catch (error) {
      console.error("Error registering slash commands", { error });
      return false;
    }
  }

  async start() {
    try {
      // Register slash commands
      await this.registerSlashCommands();

      // Login the bot
      await this.client.login(discordBotConfig.token);
      return true;
    } catch (error) {
      console.error("Failed to start Discord bot", { error });
      return false;
    }
  }

  async stop() {
    if (this.statusUpdateInterval) {
      clearInterval(this.statusUpdateInterval);
      this.statusUpdateInterval = null;
    }

    if (this.client) {
      this.client.destroy();
      console.info("Discord bot stopped");
    }
  }
}

export const discordBot = new DiscordBotService();
