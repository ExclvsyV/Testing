import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Get the directory path for the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "../../");

// Load environment variables based on NODE_ENV
const NODE_ENV = process.env.NODE_ENV || "development";

// Only load .env file if DATABASE_URL is not already set (indicating we're not in Docker)
if (NODE_ENV === "development") {
  const envFile = ".env.development";

  // Load the appropriate environment file
  const result = dotenv.config({
    path: path.resolve(rootDir, envFile),
  });

  if (result.error) {
    console.error(`Error loading ${envFile}:`, result.error);
    throw result.error;
  }

  console.log(`Loaded environment configuration from ${envFile}`);
} else {
  console.log("Using environment variables from Docker/system");
}

// Export environment variables with types for better intellisense
export const env = {
  NODE_ENV,
  DATABASE_URL: process.env.DATABASE_URL as string,
  PORT: parseInt(process.env.PORT_SERVER || "3000", 10),
  CORS_ORIGIN: process.env.CORS_ORIGIN_SERVER_APP as string,
  DISCORD_CLIENT_ID: process.env.DISCORD_CLIENT_ID as string,
  DISCORD_CLIENT_SECRET: process.env.DISCORD_CLIENT_SECRET as string,
  DISCORD_BOT_TOKEN: process.env.DISCORD_BOT_TOKEN as string,
  DISCORD_GUILD_ID: process.env.DISCORD_GUILD_ID as string,
  DISCORD_OWNER_ID: process.env.DISCORD_OWNER_ID as string,
  DISCORD_ADMIN_ROLE_ID: process.env.DISCORD_ADMIN_ROLE_ID as string,
  DISCORD_OPERATOR_ROLE_ID: process.env.DISCORD_OPERATOR_ROLE_ID as string,
  DISCORD_CUSTOMER_ROLE_ID: process.env.DISCORD_CUSTOMER_ROLE_ID as string,
  DISCORD_WEBHOOK_URL: process.env.DISCORD_WEBHOOK_URL as string,
  DISCORD_ERROR_WEBHOOK_URL: process.env.DISCORD_ERROR_WEBHOOK_URL as string,
  TOKEN_SECRET_KEY: process.env.TOKEN_SECRET_KEY as string,
  GITHUB_TOKEN: process.env.GITHUB_TOKEN as string,
  INGRESS_API_KEY: process.env.INGRESS_API_KEY as string,
  INGRESS_API_URL: process.env.INGRESS_API_URL as string,
  INGRESS_API_WEBSOCKET_URL: process.env.INGRESS_API_WEBSOCKET_URL as string,
  CLOUDFLARE_TURN_TOKEN_ID: process.env.CLOUDFLARE_TURN_TOKEN_ID as string,
  CLOUDFLARE_TURN_API_TOKEN: process.env.CLOUDFLARE_TURN_API_TOKEN as string,
};
