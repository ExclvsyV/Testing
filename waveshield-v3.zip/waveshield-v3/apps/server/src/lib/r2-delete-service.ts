/**
 * Configured R2 delete service for the server app
 */

import { createR2DeleteService } from '@waveshield/utils'

// Create service instance with environment variables
export const r2DeleteService = createR2DeleteService({
	CLOUDFLARE_ACCOUNT_ID: process.env.CLOUDFLARE_ACCOUNT_ID || '',
	R2_ACCESS_KEY_ID: process.env.R2_ACCESS_KEY_ID || '',
	R2_SECRET_ACCESS_KEY: process.env.R2_SECRET_ACCESS_KEY || '',
	R2_BUCKET_NAME: process.env.R2_BUCKET_NAME || ''
}) 