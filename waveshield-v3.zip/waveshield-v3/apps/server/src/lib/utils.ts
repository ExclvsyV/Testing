import type { Permission } from "@waveshield/database";

export const hasPermission = (
  permissions: Permission[],
  permission: Permission | "ANY"
) => {
  return (
    (permission === "ANY"
      ? permissions.length > 0
      : permissions.includes(permission)) || permissions.includes("ALL")
  );
};
