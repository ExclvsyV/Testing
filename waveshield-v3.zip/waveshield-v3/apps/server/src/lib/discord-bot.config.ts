import { env } from "./env";

export default {
  token: env.DISCORD_BOT_TOKEN || "",
  clientId: env.DISCORD_CLIENT_ID || "",
  guildId: env.DISCORD_GUILD_ID || "",
  ownerId: env.DISCORD_OWNER_ID || "",
  adminRoleId: env.DISCORD_ADMIN_ROLE_ID || "",
  operatorRoleId: env.DISCORD_OPERATOR_ROLE_ID || "",
  customerRoleId: env.DISCORD_CUSTOMER_ROLE_ID || "",
};
