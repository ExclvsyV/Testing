import { hasPermission } from "@/lib/utils";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure } from "../../lib/trpc";
import { isDemoServer, serverIdSchema } from "../../lib/demo-data";
import { r2DeleteService } from "../../lib/r2-delete-service";

// Define the input schema for unbanning a player
const unbanPlayerSchema = z.object({
  serverId: serverIdSchema,
  banId: z.string().min(1),
  unbannedBy: z.string().optional(),
});

export const unbanPlayer = protectedProcedure
  .input(unbanPlayerSchema)
  .mutation(async ({ ctx, input }) => {
    const userId = ctx.session.user.discordId;

    // Check if this is a demo server request
    if (isDemoServer(input.serverId)) {
      throw new TRPCError({
        code: "FORBIDDEN",
        message: "This action is not available in demo mode",
      });
    }

    try {
      // First, check if the user has access to this server
      const license = await ctx.db.license.findUnique({
        where: {
          id: input.serverId,
        },
        select: {
          id: true,
          discordId: true,
          members: {
            where: {
              discordId: userId,
            },
            select: {
              permissions: true,
            },
          },
        },
      });

      if (!license) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Server not found",
        });
      }

      // Check if user is owner or has MANAGE_BANS permission
      const isOwner = license.discordId === userId;
      const member = license.members[0];
      const hasManageBansPermission = hasPermission(
        member?.permissions || [],
        "MANAGE_BANS"
      );

      if (!isOwner && !hasManageBansPermission) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "You do not have permission to unban players on this server",
        });
      }

      // Use transaction to ensure data consistency
      const result = await (ctx.db.$transaction as any)(async (tx: any) => {
        // Find the ban record
        const ban = await tx.ban.findUnique({
          where: {
            licenseId_banId: {
              licenseId: input.serverId,
              banId: input.banId,
            },
          },
          select: {
            id: true,
            banId: true,
            evidenceUrl: true,
            identifiers: true,
            player: {
              select: {
                playerName: true,
              },
            },
          },
        });

        if (!ban) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Ban not found",
          });
        }

        // Delete the ban record
        await tx.ban.delete({
          where: {
            id: ban.id,
          },
        });

        await tx.serverLog.create({
          data: {
            licenseId: input.serverId,
            serverType: "UNBAN_PLAYER",
            details: { banId: input.banId, unbannedBy: userId },
          },
        });

        return {
          success: true,
          playerName: ban.player.playerName,
          banId: input.banId,
          evidenceUrl: ban.evidenceUrl,
        };
      });

      // Delete evidence from R2 storage if it exists and is from our R2 storage
      if (result.evidenceUrl && result.evidenceUrl.includes('r2.waveshield.xyz')) {
        try {
          const deleteResult = await r2DeleteService.deleteByUrls(result.evidenceUrl);
          if (deleteResult.successCount > 0) {
            console.log(`Successfully deleted evidence file for ban ${result.banId}`);
          } else {
            console.warn(`Failed to delete evidence file for ban ${result.banId}`);
          }
        } catch (error) {
          console.error(`Failed to delete evidence file for ban ${result.banId}:`, error);
          // Don't throw error here as the unban was successful
        }
      }

      return result;
    } catch (error) {
      if (error instanceof TRPCError) {
        throw error;
      }
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Error unbanning player",
      });
    }
  });
