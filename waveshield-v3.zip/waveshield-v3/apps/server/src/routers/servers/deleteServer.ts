import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { protectedProcedure } from "../../lib/trpc";

const filterSchema = z.string().uuid();

export const deleteServer = protectedProcedure
  .input(filterSchema)
  .mutation(async ({ ctx, input: serverId }) => {
    const userId = ctx.session.user.discordId;

    try {
      const license = await ctx.db.license.delete({
        where: {
          id: serverId,
          discordId: userId,
        },
      });

      if (!license) {
        throw new TRPCError({
          code: "NOT_FOUND",
          message: "Server not found",
        });
      }

      return {
        success: true,
        message: "Server deleted successfully",
      };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Error deleting server",
      });
    }
  });
