import { z } from "zod";
import { protectedProcedure } from "../../lib/trpc";
import { TRPCError } from "@trpc/server";
import { hasPermission } from "@/lib/utils";
import { emitToServer } from "../../lib/emitToServer";

const executeCommandSchema = z.object({
	serverId: z.string(),
	command: z.string().min(1, "Command cannot be empty"),
});

export const executeCommand = protectedProcedure
	.input(executeCommandSchema)
	.mutation(async ({ ctx, input }) => {
		const { serverId, command } = input;
		const userId = ctx.session.user.discordId;
		const username = ctx.session.user.name || "Web Panel User";

		// Check if user has access to this server
		const server = await ctx.db.license.findUnique({
			where: {
				id: serverId,
			},
			select: {
				id: true,
				discordId: true,
				members: {
					where: {
						discordId: userId,
					},
					select: {
						permissions: true,
					},
				},
			},
		});

		if (!server) {
			throw new TRPCError({
				code: "NOT_FOUND",
				message: "Server not found or access denied",
			});
		}

		const isOwner = server.discordId === userId;
		const member = server.members[0];
		const hasRunCommandsPermission = hasPermission(
			member?.permissions || [],
			"RUN_COMMANDS"
		);

		if (!isOwner && !hasRunCommandsPermission) {
			throw new TRPCError({
				code: "FORBIDDEN",
				message: "You do not have permission to run commands on this server",
			});
		}

		// Rate limiting check (optional - you can implement rate limiting here)
		// For now, we'll rely on the existing socket rate limiting

		try {
			// Emit the command to the ingress API which will forward it to the FiveM server
			await emitToServer(serverId, "console:command", { command, username }, true);

			return {
				success: true,
				message: "Command sent successfully",
			};
		} catch (error) {
			throw new TRPCError({
				code: "INTERNAL_SERVER_ERROR",
				message: "Failed to send command to server",
			});
		}
	}); 