import { Router } from 'express'
import type { Request, Response } from 'express'
import rateLimit from 'express-rate-limit'
import { r2UploadService } from '../services/r2-upload.service'

const router = Router()

const uploadLimiter = rateLimit({
	windowMs: 60 * 1000, // 1 minute
	max: 10,
	message: {
		error: 'Too many upload requests, please try again later',
		code: 429
	},
	standardHeaders: true,
	legacyHeaders: false
})

router.post('/upload', uploadLimiter, async (req: Request, res: Response): Promise<void> => {
	try {
		const userAgent = req.get('User-Agent') || ''
		if (!userAgent.toLowerCase().includes('citizenfx')) {
			res.status(403).json({
				success: false,
			})
			return
		}

		const { fileType, contentType, fileSize } = req.body

		if (!fileType || !contentType) {
			res.status(400).json({
				success: false,
			})
			return
		}

		const result = await r2UploadService.generateUploadUrl(fileType, contentType)

		res.json({
			success: true,
			data: result
		})
	} catch (error) {
		console.error('R2 upload URL generation failed:', error)
		res.status(500).json({
			success: false,
			error: 'Failed to generate upload URL'
		})
	}
})

export default router 