# WaveShield V3 - Server Component

This is the server component of the WaveShield anti-cheat system. It provides APIs for FiveM servers to connect and authenticate with the WaveShield service.

## Features

- License authentication and validation
- Configuration management
- Version tracking
- Security monitoring and ban management
- Discord integration for alerts and monitoring

## Directory Structure

```
server/
├── assets/            # Static assets
│   ├── files/         # Lua script files for production
│   ├── beta-files/    # Beta version Lua script files
│   └── defaultConfig.json  # Default configuration
├── prisma/            # Database schema and migrations
├── src/               # Source code
│   ├── lib/           # Utility libraries
│   ├── routers/       # tRPC API routes
│   │   ├── fivem/     # FiveM-specific API endpoints
│   │   ├── licenses/  # License management endpoints
│   │   └── users/     # User management endpoints
│   ├── types/         # TypeScript type definitions
│   ├── legacy-routes.ts  # Express routes for FiveM compatibility
│   └── index.ts       # Main application entry point
└── README.md          # This file
```

## Setup

1. Install dependencies:

```bash
npm install
# or
yarn install
# or
bun install
```

2. Set up environment variables:

Create a `.env` file in the server directory with:

```env
# Database
DATABASE_URL="postgresql://user:password@localhost:5432/waveshield"

# Auth
DISCORD_CLIENT_ID="your_discord_client_id"
DISCORD_CLIENT_SECRET="your_discord_client_secret"

# Discord Webhooks
DISCORD_WEBHOOK_URL="your_discord_webhook_url"
DISCORD_ERROR_WEBHOOK_URL="your_discord_error_webhook_url"

# Security
TOKEN_SECRET_KEY="your_secret_key"

# CORS
CORS_ORIGIN="https://your-web-app-domain.com"

# Server
PORT=3000
```

3. Run Prisma migrations:

```bash
npx prisma migrate dev
# or
yarn prisma migrate dev
# or
bunx prisma migrate dev
```

4. Start the server:

```bash
npm run dev
# or
yarn dev
# or
bun dev
```

## API Endpoints

### FiveM Server Endpoints

These endpoints are accessible via both tRPC and REST APIs:

- `POST /api/license` - Authenticate license and retrieve script file
- `GET /api/config` - Get server configuration
- `POST /api/security` - Report security incidents
- `GET /api/version` - Get latest version information

### Web App Endpoints

These endpoints are accessible via tRPC:

- `/trpc/users.getUserServersList` - Get servers owned by a user
- `/trpc/licenses.redeemLicenseKey` - Redeem a license key

## License

Copyright © 2025 WaveShield, All rights reserved.
