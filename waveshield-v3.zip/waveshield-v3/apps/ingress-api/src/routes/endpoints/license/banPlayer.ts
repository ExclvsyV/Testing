import type { Prisma } from "@waveshield/database";
import { RequestHandler } from "express";
import { z } from "zod";
import { env } from "../../../lib/env";
import prisma from "../../../lib/prisma";
import { parseIdentifierType } from "../../../lib/utils";

const schema = z.object({
  playerLicense: z.string().min(1, "Player license is required"),
  reason: z.string().min(1, "Ban reason is required"),
  details: z
    .union([
      z.record(
        z.union([z.string(), z.number(), z.boolean(), z.array(z.string())])
      ),
      z.array(z.string()),
    ])
    .optional(),
  evidenceUrl: z.string().url().optional(),
  duration: z.number().optional(), // Duration in seconds
  bannedBy: z.string().optional(),
});

export const banPlayer: RequestHandler = async (req, res) => {
  const licenseKey = req.params.licenseKey;
  const clientIp = req.clientIp!;

  if (!licenseKey || licenseKey.trim().length === 0) {
    res.status(400).json({
      error: "License key is required in URL",
      code: 400,
    });
    return;
  }

  try {
    const body = schema.parse(req.body);
    const { playerLicense, reason, details, evidenceUrl, duration, bannedBy } =
      body;

    const result = await (
      prisma.$transaction as (
        fn: (tx: Prisma.TransactionClient) => Promise<any>
      ) => Promise<any>
    )(async (tx) => {
      // 1. Verify license exists and is valid
      const license = await tx.license.findUnique({
        where: { licenseKey: licenseKey.trim() },
        select: {
          id: true,
          discordId: true,
          isBanned: true,
          serverIp: true,
          expiresAt: true,
          serverInfo: {
            select: {
              version: true,
            },
          },
        },
      });

      if (!license) {
        throw new Error("LICENSE_NOT_FOUND");
      }

      if (license.isBanned) {
        throw new Error("LICENSE_BANNED");
      }

      if (license.serverIp && license.serverIp !== clientIp) {
        throw new Error("LICENSE_IP_MISMATCH");
      }

      if (new Date() >= license.expiresAt) {
        throw new Error("LICENSE_EXPIRED");
      }

      // 2. Find the player and collect all their identifiers (current and old)
      const player = await tx.player.findUnique({
        where: {
          licenseId_playerLicense: {
            licenseId: license.id,
            playerLicense,
          },
        },
        select: {
          id: true,
          playerName: true,
          identifiers: true,
          oldIdentifiers: true,
        },
      });

      if (!player) {
        throw new Error("PLAYER_NOT_FOUND");
      }

      // 3. Collect all identifiers (current and historical)
      const currentIdentifiers = Array.isArray(player.identifiers)
        ? (player.identifiers as string[])
        : [];
      const oldIdentifiers = Array.isArray(player.oldIdentifiers)
        ? (player.oldIdentifiers as string[])
        : [];

      const allIdentifiers = [
        ...new Set([...currentIdentifiers, ...oldIdentifiers]),
      ];

      if (allIdentifiers.length === 0) {
        throw new Error("NO_IDENTIFIERS_FOUND");
      }

      // 4. Generate unique 5-digit ban ID for this license
      let banId: string;
      let attempts = 0;
      const maxAttempts = 100;

      do {
        // Generate random 5-digit number (10000-99999)
        banId = (Math.floor(Math.random() * 90000) + 10000).toString();
        attempts++;

        // Check if this banId already exists for this license
        const existingBan = await tx.ban.findUnique({
          where: {
            licenseId_banId: {
              licenseId: license.id,
              banId,
            },
          },
        });

        if (!existingBan) {
          break; // Found unique banId
        }

        if (attempts >= maxAttempts) {
          throw new Error("UNABLE_TO_GENERATE_UNIQUE_BAN_ID");
        }
      } while (true);

      const expirationDate =
        duration && duration > 0
          ? (() => {
              const calculatedDate = new Date(
                new Date().getTime() + duration * 1000
              );
              return isNaN(calculatedDate.getTime()) ? null : calculatedDate;
            })()
          : null;

      const ban = await tx.ban.create({
        data: {
          playerId: player.id,
          licenseId: license.id,
          banId,
          reason,
          details: details || {},
          evidenceUrl: evidenceUrl || null,
          expiresAt: expirationDate,
          bannedBy: bannedBy || null,
          bannedAt: new Date(),
        },
      });

      await tx.banHistory.create({
        data: {
          playerId: player.id,
          licenseId: license.id,
          reason,
          details: details || {},
          evidenceUrl: evidenceUrl || null,
        },
      });

      // 5. Create banned identifier records for all identifiers
      const bannedIdentifierData = allIdentifiers.map((identifier) => ({
        banId: ban.id,
        type: parseIdentifierType(identifier),
        value: identifier,
      }));

      await tx.bannedIdentifier.createMany({
        data: bannedIdentifierData,
        skipDuplicates: true, // Skip if identifier is already banned
      });

      // Extract Discord IDs from banned identifiers
      const discordIds = allIdentifiers
        .filter((identifier) => identifier.startsWith("discord:"))
        .map((identifier) => identifier.replace("discord:", ""));

      const discordMentions = discordIds.length > 0 
        ? `\nDiscord: ${discordIds.map(id => `<@${id}>`).join(" ")}`
        : "";

      const isEvidenceUrl = evidenceUrl && evidenceUrl.length > 0;
      const isEvidenceVideo =
        evidenceUrl && (evidenceUrl.includes("waveshield-capture.webm") || (evidenceUrl.includes("r2.waveshield.xyz") && evidenceUrl.includes("webm")));

      const embed = {
        color: 3447003,
        type: "rich",
        description: `**Player banned**\n\nLicense: **${licenseKey}**\nLicense Owner: **<@${license.discordId}>**\nPlayer: **${
          player.playerName
        }**\nReason: **${reason}**\nDetails: \`\`\`${
          details ? JSON.stringify(details, null, 2) : "No details"
        }\`\`\`${discordMentions}`,
        url: "https://www.waveshield.xyz/",
        author: {
          name: "New player banned",
          url: "https://www.waveshield.xyz/",
          icon_url:
            "https://media.discordapp.net/attachments/778562688925696020/1097717519244079136/LOGO_STATIC.png",
        },
        footer: {
          text: `WaveShield ${license.serverInfo?.version || "Unknown"}`,
        },
        ...(isEvidenceUrl &&
          !isEvidenceVideo && {
            image: {
              url: evidenceUrl,
            },
          }),
        timestamp: new Date().toISOString(),
      };

      await fetch(env.SERVERS_BAN_WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: isEvidenceVideo ? evidenceUrl : undefined,
          embeds: [embed],
        }),
      });

      await tx.serverLog.create({
        data: {
          licenseId: license.id,
          serverType: "BAN_PLAYER",
          playerLicense,
          details: { reason: reason },
        },
      });
      
      return {
        success: true,
        ban: {
          banId,
          playerName: player.playerName,
          playerLicense,
          reason,
          details,
          evidenceUrl,
          expiresAt: expirationDate,
          isPermanent: expirationDate === null,
          identifiersBanned: allIdentifiers.length,
        },
      };
    });

    res.status(200).json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.log(req.body);
      console.error(
        "BanPlayer ZodError:",
        error.errors.map((err) => ({
          field: err.path.join("."),
          message: err.message,
        }))
      );
      res.status(400).json({
        error: "Invalid request data",
        details: error.errors.map((err) => ({
          field: err.path.join("."),
          message: err.message,
        })),
      });
      return;
    }

    console.error("BanPlayer error:", error);

    if (error instanceof Error) {
      switch (error.message) {
        case "LICENSE_NOT_FOUND":
          res.status(404).json({ error: "License not found", code: 404 });
          return;
        case "LICENSE_BANNED":
          res.status(404).json({ error: "License banned", code: 404 });
          return;
        case "LICENSE_EXPIRED":
          res.status(404).json({ error: "License expired", code: 404 });
          return;
        case "PLAYER_NOT_FOUND":
          res.status(404).json({ error: "Player not found", code: 404 });
          return;
        case "LICENSE_IP_MISMATCH":
          res.status(404).json({ error: "License IP mismatch", code: 404 });
          return;
        case "NO_IDENTIFIERS_FOUND":
          res
            .status(404)
            .json({ error: "No identifiers found for player", code: 404 });
          return;
        case "UNABLE_TO_GENERATE_UNIQUE_BAN_ID":
          res
            .status(500)
            .json({ error: "Unable to generate unique ban ID", code: 500 });
          return;
      }
    }

    res.status(500).json({ error: "Internal server error", code: 500 });
  }
};
