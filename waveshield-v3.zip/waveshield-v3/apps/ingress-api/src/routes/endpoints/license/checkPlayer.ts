import type { Prisma } from "@waveshield/database";
import { calculateTrustScore } from "@waveshield/utils";
import { RequestHandler } from "express";
import { z } from "zod";
import prisma from "../../../lib/prisma";
import { parseIdentifierType } from "../../../lib/utils";

const schema = z.object({
  identifiers: z.array(z.string()).min(2, "Identifiers is required"),
  tokens: z.array(z.string()).min(1).optional(),
  playerName: z.string().min(1, "Player name is required"),
  playerLicense: z.string().min(1, "Player license is required"),
});

export const checkPlayer: RequestHandler = async (req, res) => {
  const licenseKey = req.params.licenseKey;
  const clientIp = req.clientIp!;

  if (!licenseKey || licenseKey.trim().length === 0) {
    res.status(400).json({
      error: "License key is required in URL",
      code: 400,
    });
    return;
  }

  try {
    const body = schema.parse(req.body);
    const { identifiers, tokens, playerName, playerLicense } = body;

    // Combine all identifiers
    const allCurrentIdentifiers = [...identifiers, ...(tokens || [])];

    // Start transaction for atomic operations
    const result = await (
      prisma.$transaction as (
        fn: (tx: Prisma.TransactionClient) => Promise<any>
      ) => Promise<any>
    )(async (tx) => {
      // 1. Verify license exists and is valid
      const license = await tx.license.findUnique({
        where: { licenseKey: licenseKey.trim() },
        select: {
          id: true,
          serverIp: true,
          isBanned: true,
          expiresAt: true,
          members: {
            where: {
              discordId: {
                in: identifiers
                  .filter((id) => id.startsWith("discord:"))
                  .map((id) => id.replace("discord:", "")),
              },
            },
            select: {
              permissions: true,
            },
          },
        },
      });

      if (!license) {
        throw new Error("LICENSE_NOT_FOUND");
      }

      if (license.serverIp && license.serverIp !== clientIp) {
        throw new Error("LICENSE_IP_MISMATCH");
      }

      if (license.isBanned) {
        throw new Error("LICENSE_BANNED");
      }

      if (new Date() >= license.expiresAt) {
        throw new Error("LICENSE_EXPIRED");
      }

      // 2. Check for active bans using optimized query
      const activeBan = await tx.bannedIdentifier.findFirst({
        where: {
          value: { in: allCurrentIdentifiers },
          ban: {
            licenseId: license.id,
          },
        },
        select: {
          ban: {
            select: {
              id: true,
              banId: true,
              reason: true,
              details: true,
              evidenceUrl: true,
              expiresAt: true,
            },
          },
        },
      });

      if (activeBan) {
        // Player is banned - ban all current identifiers using the same ban record
        const bannedIdentifierData = allCurrentIdentifiers.map(
          (identifier) => ({
            banId: activeBan.ban.id,
            type: parseIdentifierType(identifier),
            value: identifier,
          })
        );

        await tx.bannedIdentifier.createMany({
          data: bannedIdentifierData,
          skipDuplicates: true, // Unique constraint handles duplicates
        });

        return {
          banned: true,
          ban: {
            banId: activeBan.ban.banId,
            reason: activeBan.ban.reason,
            details: activeBan.ban.details,
            evidenceUrl: activeBan.ban.evidenceUrl,
            expiresAt: activeBan.ban.expiresAt,
            isPermanent: activeBan.ban.expiresAt === null,
          },
        };
      }

      // 3. Update or create server-specific player record with identifier tracking
      const currentTime = new Date();

      const existingPlayer = await tx.player.findUnique({
        where: {
          licenseId_playerLicense: {
            licenseId: license.id,
            playerLicense,
          },
        },
        select: {
          identifiers: true,
          oldIdentifiers: true,
          playTime: true,
        },
      });

      let oldIdentifiers: string[] = [];

      const allCurrentIdentifiersWithFid = [
        ...allCurrentIdentifiers,
        ...(Array.isArray(existingPlayer?.identifiers)
          ? (existingPlayer.identifiers as string[]).filter((id: string) =>
              id.startsWith("fid:") || id.startsWith("sid:") || id.startsWith("sid2:")
            )
          : []),
      ];

      if (existingPlayer) {
        // Merge current identifiers into old identifiers (without duplicates)
        const currentDbIds = Array.isArray(existingPlayer.identifiers)
          ? (existingPlayer.identifiers as string[])
          : [];
        const previousDbIds = Array.isArray(existingPlayer.oldIdentifiers)
          ? (existingPlayer.oldIdentifiers as string[])
          : [];

        // Add current identifiers that are not in the new set to old identifiers
        const newIdentifiersSet = new Set(allCurrentIdentifiers);

        // don't move ip addresses and fid and tokens
        const identifiersToMove = currentDbIds.filter((id) => {
          // Skip if the identifier is still present in new identifiers
          if (newIdentifiersSet.has(id)) return false;

          // Skip ip addresses, HWID, and fid/sid identifiers
          if (
            id.startsWith("ip:") ||
            parseIdentifierType(id) === "HWID" ||
            id.startsWith("fid:") ||
            id.startsWith("sid:") ||
            id.startsWith("sid2:")
          ) {
            return false;
          }

          // For discord identifiers, only move if there's a different discord identifier in newIdentifiersSet
          if (id.startsWith("discord:")) {
            const hasAnyDiscordInNew = allCurrentIdentifiers.some((newId) =>
              newId.startsWith("discord:")
            );
            return hasAnyDiscordInNew;
          }

          return true;
        });

        oldIdentifiers = [
          ...new Set([...previousDbIds, ...identifiersToMove]),
        ].filter(id => !allCurrentIdentifiersWithFid.includes(id));
      }

      const updatedPlayer = await tx.player.upsert({
        where: {
          licenseId_playerLicense: {
            licenseId: license.id,
            playerLicense,
          },
        },
        update: {
          playerName,
          identifiers: allCurrentIdentifiersWithFid,
          oldIdentifiers,
          lastJoin: currentTime,
        },
        create: {
          licenseId: license.id,
          playerName,
          playerLicense,
          identifiers: allCurrentIdentifiers,
          oldIdentifiers: [],
          firstJoin: currentTime,
          lastJoin: currentTime,
        },
        select: {
          id: true,
          playerName: true,
          playerLicense: true,
          identifiers: true,
          oldIdentifiers: true,
          firstJoin: true,
          lastJoin: true,
          playTime: true,
          licenseId: true,
        },
      });

      if (!updatedPlayer) {
        throw new Error("Failed to retrieve player data");
      }

      const threatScoreResult = await calculateTrustScore(
        tx as any,
        updatedPlayer,
        license.id
      );

      const isBypass = license.members.some(
        (member: any) =>
          member.permissions.includes("BYPASS") ||
          member.permissions.includes("ALL")
      );
      const isAdmin = license.members.some(
        (member: any) => member.permissions.length > 0
      );

      await tx.serverLog.create({
        data: {
          licenseId: license.id,
          serverType: "PLAYER_JOIN",
          playerLicense: updatedPlayer.playerLicense,
        },
      });

      return {
        banned: false,
        playTime: updatedPlayer.playTime || 0,
        threatScore: threatScoreResult.score,
        isBypass,
        isAdmin,
      };
    });

    res.status(200).json(result);
  } catch (error) {
    if (error instanceof z.ZodError) {
      console.log(req.body);
      console.error(
        "CheckPlayer ZodError:",
        error.errors.map((err) => ({
          field: err.path.join("."),
          message: err.message,
        }))
      );
      res.status(400).json({
        error: "Invalid request data",
        details: error.errors.map((err) => ({
          field: err.path.join("."),
          message: err.message,
        })),
      });
      return;
    }

    console.error("CheckPlayer error:", error);

    if (error instanceof Error) {
      switch (error.message) {
        case "LICENSE_NOT_FOUND":
          res.status(404).json({ error: "License not found", code: 404 });
          return;
        case "LICENSE_BANNED":
          res.status(404).json({ error: "License banned", code: 404 });
          return;
        case "LICENSE_IP_MISMATCH":
          res.status(404).json({ error: "License IP mismatch", code: 404 });
          return;
        case "LICENSE_EXPIRED":
          res.status(404).json({ error: "License expired", code: 404 });
          return;
      }
    }

    res.status(500).json({ error: "Internal server error", code: 500 });
  }
};
