import { createPrismaClient } from "@waveshield/database";

const prisma = createPrismaClient({
  log: false,
  accelerate: true,
});

export default prisma;
