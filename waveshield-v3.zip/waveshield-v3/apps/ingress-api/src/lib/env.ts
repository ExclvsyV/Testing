import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";

// Get the directory path for the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, "../../");

// Load environment variables based on NODE_ENV
const NODE_ENV = process.env.NODE_ENV || "development";

// Only load .env file if DATABASE_URL is not already set (indicating we're not in Docker)
if (NODE_ENV === "development") {
  const envFile = ".env.development";

  // Load the appropriate environment file
  const result = dotenv.config({
    path: path.resolve(rootDir, envFile),
  });

  if (result.error) {
    console.error(`Error loading ${envFile}:`, result.error);
    throw result.error;
  }

  console.log(`Loaded environment configuration from ${envFile}`);
} else {
  console.log("Using environment variables from Docker/system");
}

// Export environment variables with types for better intellisense
export const env = {
  NODE_ENV,
  DATABASE_URL: process.env.DATABASE_URL as string,
  PORT: parseInt(process.env.PORT_INGRESS || "3002", 10),
  CORS_ORIGIN: process.env.CORS_ORIGIN_INGRESS_API as string,
  FIVEM_USER_AGENT: process.env.FIVEM_USER_AGENT as string,
  ANTI_CRACK_WEBHOOK_URL: process.env.ANTI_CRACK_WEBHOOK_URL as string,
  SERVERS_AUTH_WEBHOOK_URL: process.env.SERVERS_AUTH_WEBHOOK_URL as string,
  SERVERS_BAN_WEBHOOK_URL: process.env.SERVERS_BAN_WEBHOOK_URL as string,
  INGRESS_API_KEY: process.env.INGRESS_API_KEY as string,
};
