import { License } from "@waveshield/database";
import { logger } from "../lib/logger";
import prisma from "../lib/prisma";

function isCloudflarePseudoIPv4(ip: string): boolean {
  const parts = ip.split(".").map(Number);
  if (parts.length !== 4 || parts.some((n) => isNaN(n))) return false;
  if (!parts[0] || !parts[1] || !parts[2] || !parts[3]) return false;

  // Class D: 224.0.0.0 - 239.255.255.255
  if (parts[0] >= 224 && parts[0] <= 239) return true;

  // Class E: 240.0.0.0 - 255.255.255.254
  if (parts[0] >= 240 && parts[0] <= 255) return true;

  // TEST-NET-1: 192.0.2.0/24
  if (parts[0] === 192 && parts[1] === 0 && parts[2] === 2) return true;

  // TEST-NET-2: 198.51.100.0/24
  if (parts[0] === 198 && parts[1] === 51 && parts[2] === 100) return true;

  // TEST-NET-3: 203.0.113.0/24
  if (parts[0] === 203 && parts[1] === 0 && parts[2] === 113) return true;

  return false;
}

class LicenseService {
  async validateServer(licenseKey: string, clientIp: string): Promise<any> {
    try {
      const license = await prisma.license.findUnique({
        where: {
          licenseKey,
          isBanned: false,
          expiresAt: {
            gt: new Date(),
          },
        },
        select: {
          id: true,
          serverIp: true,
        },
      });

      if (
        !isCloudflarePseudoIPv4(clientIp) &&
        !isCloudflarePseudoIPv4(license?.serverIp ?? "") &&
        license?.serverIp !== clientIp
      ) {
        return;
      }

      return license;
    } catch (error) {
      logger.error("Error validating server", { error, licenseKey, clientIp });
      return;
    }
  }

  async validateServerQuery(licenseKey: string | undefined, clientIp: string | undefined): Promise<{
    valid: boolean;
    license?: {
      id: string;
    } | null;
  }> {
    try {
      if (!licenseKey || licenseKey.trim().length === 0) {
        return {
          valid: false,
        };
      }

      if (!clientIp || clientIp.trim().length === 0) {
        return {
          valid: false,
        };
      }

      const license = await prisma.license.findUnique({
        where: {
          licenseKey,
          isBanned: false,
          expiresAt: {
            gt: new Date(),
          },
          serverIp: clientIp,
        },
        select: {
          id: true,
        },
      });

      return {
        valid: license !== null,
        license: license,
      };
    } catch (error) {
      logger.error("Error validating server query", { error, licenseKey, clientIp });
      return {
        valid: false,
      };
    }
  }
}

export default new LicenseService();
