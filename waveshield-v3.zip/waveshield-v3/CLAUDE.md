# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

WaveShield v3 is a FiveM Anti-Cheat Management System built as a monorepo using Turborepo. It provides server owners with a web dashboard to manage their FiveM servers' anti-cheat system, player bans, logs, and configurations.

## Architecture

This is a TypeScript monorepo with the following main applications:

- **apps/web/**: Next.js 15 frontend dashboard (runs on port 3001)
- **apps/server/**: Express.js backend API with tRPC (runs on port 3000) 
- **apps/ingress-api/**: Express.js API for FiveM server communication
- **packages/**: Shared utilities, types, database schema, and config

## Key Technologies

- **Frontend**: Next.js 15, TypeScript, Tailwind CSS v4, shadcn/ui, Radix UI, better-auth
- **Backend**: Express.js, tRPC, Prisma with Accelerate, better-auth
- **Database**: PostgreSQL with Prisma ORM
- **Runtime**: Bun (package manager and runtime)
- **Monorepo**: Turborepo

## Development Commands

All commands should be run from the repository root:

### Main Development
- `bun dev` - Start all apps in development mode
- `bun build` - Build all applications
- `bun start` - Start all applications in production mode
- `bun check-types` - Type check across all apps

### Individual Apps
- `bun dev:web` - Start only the web application
- `bun dev:server` - Start only the server
- `bun dev:native` - Start native development

### Database Operations
- `bun db:push` - Push schema changes to database
- `bun db:studio` - Open Prisma Studio
- `bun db:generate` - Generate Prisma client
- `bun db:migrate` - Run database migrations
- `bun db:reset` - Reset database

### Individual App Commands
- Web app: `bun lint` (from apps/web/)
- Server: `bun compile` (from apps/server/) - Compile to binary
- Ingress API: `bun copy-assets` (from apps/ingress-api/)

## Code Style & Conventions

The project follows these conventions based on .cursorrules:

- **Indentation**: Tabs
- **Quotes**: Single quotes (except to avoid escaping)
- **Semicolons**: Omitted (unless required)
- **Naming**:
  - PascalCase: Components, types, interfaces
  - kebab-case: Directory and file names
  - camelCase: Variables, functions, methods, hooks
  - UPPERCASE: Environment variables, constants

## Database Schema

The project uses a PostgreSQL database with Prisma ORM. Key models include:
- User management with permissions system
- Server configurations and analytics
- Player bans and identifiers (HWID, Steam, Discord, etc.)
- System logs and audit trails

The schema is located at `packages/database/prisma/schema.prisma`.

## Package Structure

- **@waveshield/config**: Configuration constants and defaults
- **@waveshield/database**: Prisma client and database utilities  
- **@waveshield/types**: Shared TypeScript type definitions
- **@waveshield/utils**: Common utility functions

## Security Focus

This is a defensive security application for FiveM anti-cheat management. The codebase handles:
- Player ban management and tracking
- Server security configurations
- Anti-cheat detection rules
- Audit logging for security events

All work should maintain the defensive security focus and follow security best practices.