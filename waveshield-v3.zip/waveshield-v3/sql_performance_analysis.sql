-- ==================================================
-- WAVESHIELD - ANALYSE DE PERFORMANCE PostgreSQL
-- Commandes pg_stat_statements pour optimisation
-- ==================================================

-- 1. REMETTRE LES STATS À ZÉRO (pour commencer une nouvelle analyse)
-- ⚠️ Attention: ça efface toutes les statistiques précédentes
SELECT pg_stat_statements_reset();

-- 2. REQUÊTES LES PLUS LENTES (par temps moyen d'exécution)
-- 🐌 Identifie les requêtes qui prennent le plus de temps individuellement
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  max_exec_time,
  min_exec_time,
  rows,
  100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) AS hit_percent
FROM pg_stat_statements 
WHERE mean_exec_time > 10 -- Plus de 10ms en moyenne
ORDER BY mean_exec_time DESC 
LIMIT 15;

-- 3. REQUÊTES LES PLUS APPELÉES (problème de fréquence)
-- 🔄 Identifie les requêtes appelées trop souvent (comme ton problème user)
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  calls * mean_exec_time AS impact_score
FROM pg_stat_statements 
ORDER BY calls DESC 
LIMIT 15;

-- 4. REQUÊTES QUI CONSOMMENT LE PLUS DE TEMPS TOTAL
-- ⏱️ Impact global sur les performances
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  (total_exec_time/sum(total_exec_time) OVER()) * 100 AS percentage_of_total_time
FROM pg_stat_statements 
WHERE total_exec_time > 100 -- Plus de 100ms au total
ORDER BY total_exec_time DESC 
LIMIT 15;

-- 5. ANALYSE SPÉCIFIQUE DES REQUÊTES USER (ton problème principal)
-- 👤 Focus sur les requêtes user pour voir l'amélioration
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  rows
FROM pg_stat_statements 
WHERE query ILIKE '%user%' 
   OR query ILIKE '%session%'
ORDER BY calls DESC;

-- 6. REQUÊTES AVEC MAUVAIS CACHE HIT RATIO
-- 💾 Requêtes qui lisent beaucoup depuis le disque (lent)
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  shared_blks_hit,
  shared_blks_read,
  100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) AS hit_percent
FROM pg_stat_statements 
WHERE shared_blks_read > 0
  AND 100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) < 95
ORDER BY shared_blks_read DESC
LIMIT 10;

-- 7. ANALYSE DES REQUÊTES D'ÉCRITURE (INSERT/UPDATE/DELETE)
-- ✏️ Requêtes qui modifient les données
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time
FROM pg_stat_statements 
WHERE query ILIKE '%INSERT%' 
   OR query ILIKE '%UPDATE%' 
   OR query ILIKE '%DELETE%'
ORDER BY total_exec_time DESC 
LIMIT 10;

-- 8. TOP 10 DES REQUÊTES PAR IMPACT GLOBAL
-- 🎯 Score d'impact = fréquence × temps moyen
SELECT 
  query,
  calls,
  mean_exec_time,
  total_exec_time,
  (calls * mean_exec_time) AS impact_score,
  100.0 * shared_blks_hit / nullif(shared_blks_hit + shared_blks_read, 0) AS hit_percent
FROM pg_stat_statements 
ORDER BY impact_score DESC 
LIMIT 10;

-- 9. SURVEILLANCE EN TEMPS RÉEL
-- 📊 À exécuter toutes les 5-10 minutes pour surveiller
SELECT 
  NOW() as timestamp,
  COUNT(*) as total_queries,
  SUM(calls) as total_calls,
  SUM(total_exec_time) as total_time,
  AVG(mean_exec_time) as avg_time
FROM pg_stat_statements;

-- 10. ANALYSE DES REQUÊTES PRISMA SPÉCIFIQUES
-- 🔍 Focus sur les patterns Prisma de ton app
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time
FROM pg_stat_statements 
WHERE query ILIKE '%public%'
  AND (
    query ILIKE '%license%' OR
    query ILIKE '%server%' OR
    query ILIKE '%player%' OR
    query ILIKE '%ban%' OR
    query ILIKE '%activity%'
  )
ORDER BY calls DESC 
LIMIT 15;

-- 11. REQUÊTES QUI FONT DES SCANS DE TABLE COMPLÈTE
-- 🚨 Requêtes potentiellement dangereuses sans index
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  rows
FROM pg_stat_statements 
WHERE mean_exec_time > 50 -- Plus de 50ms
  AND rows > 1000 -- Retourne beaucoup de lignes
ORDER BY mean_exec_time DESC;

-- 12. ÉTAT DES INDEX (à exécuter séparément)
-- 📇 Vérifier si les index sont utilisés
SELECT 
  schemaname,
  tablename,
  indexname,
  idx_tup_read,
  idx_tup_fetch,
  idx_scan
FROM pg_stat_user_indexes 
ORDER BY idx_scan DESC;

-- ==================================================
-- COMMANDES POUR MONITORING CONTINU
-- ==================================================

-- SCRIPT DE SURVEILLANCE (à exécuter toutes les 10 minutes)
-- CREATE VIEW performance_monitor AS
SELECT 
  'TOP_SLOWEST' as metric_type,
  query,
  calls,
  mean_exec_time,
  total_exec_time
FROM pg_stat_statements 
WHERE mean_exec_time > 20
ORDER BY mean_exec_time DESC 
LIMIT 5;

-- ALERTE SI TROP DE REQUÊTES USER (après ton fix)
-- Si tu vois plus de 1000 calls par minute sur user, il y a encore un problème
SELECT 
  'USER_QUERY_ALERT' as alert_type,
  query,
  calls,
  mean_exec_time
FROM pg_stat_statements 
WHERE query ILIKE '%user%_id%'
  AND calls > 1000;

-- ==================================================
-- UTILISATION RECOMMANDÉE:
-- 
-- 1. Exécute pg_stat_statements_reset() avant de tester ton fix
-- 2. Utilise ton app normalement pendant 30 minutes
-- 3. Exécute les requêtes 2, 3, 4 pour voir les nouveaux patterns
-- 4. Exécute la requête 5 pour vérifier que les requêtes user ont diminué
-- 5. Utilise la requête 10 pour identifier les prochains problèmes
-- ================================================== 