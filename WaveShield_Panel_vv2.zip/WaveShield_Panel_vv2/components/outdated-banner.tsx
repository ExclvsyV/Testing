"use client"

import { ExternalLink } from "lucide-react"

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"

export function OutdatedBanner() {
  const handleBannerClick = () => {
    window.open("https://waveshield.xyz/dashboard", "_blank")
  }

  return (
    <Alert
      className="fixed inset-x-0 top-0 z-50 animate-pulse cursor-pointer rounded-none border-0 bg-gradient-to-r from-purple-600 via-blue-800 to-indigo-900 py-3 text-white shadow-lg"
      onClick={handleBannerClick}
    >
      <div className="flex w-full items-center justify-center text-center">
        <div className="flex-1">
          <AlertTitle className="mb-1 text-base font-bold text-white">
            ⚠️ OUTDATED VERSION - ACTION REQUIRED ⚠️
          </AlertTitle>
          <AlertDescription className="text-xs text-white/90">
            This dashboard version is outdated and no longer supported. Please
            download the latest files and update immediately.
          </AlertDescription>
        </div>
        <div className="ml-4 flex items-center">
          <Button
            variant="secondary"
            size="sm"
            className="bg-white px-3 py-1 text-xs font-semibold text-purple-700 shadow-md hover:bg-gray-100"
            onClick={(e) => {
              e.stopPropagation()
              window.open("https://waveshield.xyz/dashboard", "_blank")
            }}
          >
            <ExternalLink className="mr-1 size-3" />
            Update Now
          </Button>
        </div>
      </div>
    </Alert>
  )
}
