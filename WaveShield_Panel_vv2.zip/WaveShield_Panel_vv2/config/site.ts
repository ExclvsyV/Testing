export type SiteConfig = typeof siteConfig

export const siteConfig = {
  name: "WaveShield - Web Panel",
  description:
    "Manage anti-cheat settings and server remotely. User-friendly interface for convenience.",
}
