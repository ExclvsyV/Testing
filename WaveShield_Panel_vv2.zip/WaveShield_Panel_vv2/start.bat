npm run dev
pause