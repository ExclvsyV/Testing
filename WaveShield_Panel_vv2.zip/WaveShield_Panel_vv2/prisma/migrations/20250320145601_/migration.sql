-- AlterTable
ALTER TABLE "License" ADD COLUMN     "bannerUrl" TEXT;
