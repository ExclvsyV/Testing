-- AlterTable
ALTER TABLE "Server_Infos" ADD CONSTRAINT "Server_Infos_pkey" PRIMARY KEY ("id");
