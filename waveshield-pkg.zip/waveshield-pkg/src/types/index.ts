/**
 * WaveShield Types
 * Comprehensive type definitions for the FiveM resource
 */

// Player-related types
export enum PlayerStatus {
  SWIMMING = "SWIMMING",
  ON_FOOT = "ON_FOOT",
  IN_VEHICLE = "IN_VEHICLE",
  ARMED = "ARMED",
  DEAD = "DEAD",
}

export interface PlayerIdentifiers {
  readonly steam?: string;
  readonly license: string;
  readonly discord?: string;
  readonly ip: string;
}

export interface PlayerCoordinates {
  readonly x: number;
  readonly y: number;
}

export interface PlayerData {
  readonly id: number;
  readonly name: string;
  readonly license: string;
  readonly ping: number;
  readonly playTime: number;
  readonly threatScore: number;
  readonly timeOnline: number;
  readonly admin: boolean;
  readonly coords: PlayerCoordinates;
  readonly status: PlayerStatus;
  readonly health: number;
}

// Ban-related types
export interface BanData {
  readonly id: string;
  readonly playerId: number;
  readonly playerName: string;
  readonly reason: string;
  readonly bannedBy: string;
  readonly bannedAt: string;
  readonly expiresAt?: string;
  readonly identifiers: PlayerIdentifiers;
}

// Socket event types
export interface SocketEventMap {
  // Authentication events
  authenticated: (data: { success: boolean; message?: string }) => void;
  authenticationFailed: (data: { reason: string }) => void;

  // Player management events
  kickPlayer: (data: { playerId: number; reason: string; by: string }) => void;
  banPlayer: (data: { playerId: number; reason: string; by: string }) => void;
  unbanPlayer: (data: { banId: string; reason: string; by: string }) => void;
  unbanAllPlayers: (data: { by: string }) => void;

  // Data requests
  requestUpdatePlayerList: () => void;
  requestUpdateBanList: () => void;

  // Data updates
  updatePlayerList: (players: PlayerData[]) => void;
  updateBanList: (bans: BanData[]) => void;

  // Configuration events
  configUpdated: (config: Record<string, unknown>) => void;

  // Monitoring events
  onPlayerJoin: (player: PlayerData) => void;
  onPlayerLeave: (playerId: number) => void;
  onPlayerKick: (playerId: number) => void;
  onPlayerBan: (ban: BanData) => void;
  onPlayerUnban: (banId: string) => void;
  onUnbanAll: () => void;

  // Admin actions
  DMPlayer: (data: { playerId: number; message: string }) => void;
  ScreenshotPlayer: (data: { playerId: number }) => void;
  SpectatePlayer: (data: { playerId: number }) => void;
}

// API response types
export interface APIResponse<T = unknown> {
  readonly success: boolean;
  readonly data?: T;
  readonly error?: string;
  readonly message?: string;
}

// Error types
export enum ErrorCode {
  CONNECTION_FAILED = "CONNECTION_FAILED",
  AUTHENTICATION_FAILED = "AUTHENTICATION_FAILED",
  INVALID_LICENSE = "INVALID_LICENSE",
  RATE_LIMITED = "RATE_LIMITED",
  SERVER_ERROR = "SERVER_ERROR",
  VALIDATION_ERROR = "VALIDATION_ERROR",
}

export interface WaveShieldError {
  readonly code: ErrorCode;
  readonly message: string;
  readonly details?: Record<string, unknown>;
  readonly timestamp: string;
}

// Utility types
export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
export type DeepReadonly<T> = {
  readonly [P in keyof T]: T[P] extends object ? DeepReadonly<T[P]> : T[P];
};

// Event handler types
export type EventHandler<T = unknown> = (data: T) => void | Promise<void>;
export type EventMap = Record<string, EventHandler>;
