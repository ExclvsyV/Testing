/**
 * WaveShield Configuration
 * Centralized configuration for the FiveM resource
 */

export interface WaveShieldConfig {
  readonly api: {
    readonly url: string;
    readonly timeout: number;
    readonly userAgent: string;
  };
  readonly connection: {
    readonly reconnectAttempts: number;
    readonly reconnectDelay: number;
    readonly connectionTimeout: number;
  };
  readonly monitoring: {
    readonly updateInterval: number;
    readonly playerBatchSize: number;
  };
  readonly logging: {
    readonly prefix: string;
    readonly verboseMode: boolean;
  };
}

/**
 * Default configuration values
 */

const defaultConfig: WaveShieldConfig = {
  api: {
    url:
      process.env.NODE_ENV === "production"
        ? "https://waveshield.cloud"
        : "http://localhost:3002",
    timeout: 15000,
    userAgent: "WaveShield_Server",
  },
  connection: {
    reconnectAttempts: 1000,
    reconnectDelay: 15000,
    connectionTimeout: 15000,
  },
  monitoring: {
    updateInterval: 15000,
    playerBatchSize: 50,
  },
  logging: {
    prefix: "[WaveShield]",
    verboseMode: false,
  },
};

/**
 * Get the current configuration
 */
export const getConfig = (): WaveShieldConfig => defaultConfig;

/**
 * Validate configuration values
 */
export const validateConfig = (config: WaveShieldConfig): boolean => {
  if (!config.api.url || config.api.timeout <= 0) {
    return false;
  }

  if (
    config.connection.reconnectAttempts <= 0 ||
    config.connection.reconnectDelay <= 0
  ) {
    return false;
  }

  if (
    config.monitoring.updateInterval <= 0 ||
    config.monitoring.playerBatchSize <= 0
  ) {
    return false;
  }

  return true;
};
