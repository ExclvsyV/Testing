/**
 * WaveShield Client Configuration
 * Configuration for the client-side UI that doesn't depend on server functions
 */

export interface ClientConfig {
  readonly ui: {
    readonly debugMode: boolean;
    readonly verboseLogging: boolean;
  };
  readonly recording: {
    readonly maxDuration: number;
    readonly quality: string;
    readonly framerate: number;
  };
  readonly heartbeat: {
    readonly interval: number;
    readonly timeout: number;
  };
}

/**
 * Default client configuration values
 */
const defaultClientConfig: ClientConfig = {
  ui: {
    debugMode: false,
    verboseLogging: false,
  },
  recording: {
    maxDuration: 10000, // 10 seconds
    quality: "medium",
    framerate: 30,
  },
  heartbeat: {
    interval: 5000, // 5 seconds
    timeout: 15000, // 15 seconds
  },
};

/**
 * Get the current client configuration
 */
export const getClientConfig = (): ClientConfig => defaultClientConfig;
