/**
 * WaveShield Constants
 * Application-wide constants and enums
 */

export const APP_NAME = "WaveShield Anti-Cheat Package";
export const VERSION = "1.0.0";
export const RESOURCE_NAME = "waveshield-pkg";

export enum Events {
  WAVESHIELD_START = "__WaveShield_internal:onWaveShieldStart",
  WAVESHIELD_EMIT = "__WaveShield:ws:emit",
}

export enum PlayerWeapons {
  UNARMED = -1569615261,
}

export enum LogContexts {
  SOCKET_MANAGER = "SOCKET_MANAGER",
  SERVER_MONITOR = "SERVER_MONITOR",
  FILE_OPS = "FILE_OPS",
  AUTH = "AUTH",
  CONNECTION = "CONNECTION",
  TIMING = "TIMING",
  INIT = "INIT",
  SYSTEM = "SYSTEM",
}
