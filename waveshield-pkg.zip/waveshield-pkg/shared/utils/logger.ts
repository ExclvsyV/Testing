/**
 * WaveShield Logger Utility
 * Professional logging system for the FiveM resource
 */

import { getConfig } from "../../src/config";

export enum LogLevel {
  ERROR = 0,
  WARN = 1,
  INFO = 2,
  DEBUG = 3,
  TRACE = 4,
}

interface LogEntry {
  readonly timestamp: string;
  readonly level: LogLevel;
  readonly message: string;
  readonly context?: string | undefined;
  readonly meta?: Record<string, unknown> | undefined;
}

class Logger {
  private readonly config = getConfig();
  private readonly prefix = this.config.logging.prefix;
  private readonly verboseMode = this.config.logging.verboseMode;

  /**
   * Format timestamp for logs
   */
  private formatTimestamp(): string {
    return new Date().toISOString();
  }

  /**
   * Format log message
   */
  private formatMessage(entry: LogEntry): string {
    const context = entry.context ? `[${entry.context}]` : "";

    if (this.verboseMode) {
      return `${this.prefix} [${entry.timestamp}] ${context}: ${entry.message}`;
    }

    return `${this.prefix} ${context}: ${entry.message}`;
  }

  /**
   * Internal logging method
   */
  private log(
    level: LogLevel,
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    const entry: LogEntry = {
      timestamp: this.formatTimestamp(),
      level,
      message,
      context,
      meta,
    };

    const formattedMessage = this.formatMessage(entry);

    // Output to console based on level
    switch (level) {
      case LogLevel.ERROR:
        console.error(formattedMessage);
        break;
      case LogLevel.WARN:
        console.warn(formattedMessage);
        break;
      case LogLevel.INFO:
        console.info(formattedMessage);
        break;
      case LogLevel.DEBUG:
      case LogLevel.TRACE:
        if (this.verboseMode) {
          console.log(formattedMessage);
        }
        break;
      default:
        console.log(formattedMessage);
    }

    // Include meta information in verbose mode
    if (this.verboseMode && meta && Object.keys(meta).length > 0) {
      console.log(`${this.prefix} Meta:`, meta);
    }
  }

  /**
   * Log error message
   */
  public error(
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.log(LogLevel.ERROR, message, context, meta);
  }

  /**
   * Log warning message
   */
  public warn(
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.log(LogLevel.WARN, message, context, meta);
  }

  /**
   * Log info message
   */
  public info(
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.log(LogLevel.INFO, message, context, meta);
  }

  /**
   * Log debug message
   */
  public debug(
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.log(LogLevel.DEBUG, message, context, meta);
  }

  /**
   * Log trace message
   */
  public trace(
    message: string,
    context?: string | undefined,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.log(LogLevel.TRACE, message, context, meta);
  }

  /**
   * Log socket-related messages (backwards compatibility)
   */
  public socket(
    message: string,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.info(message, "SOCKET", meta);
  }

  /**
   * Log connection-related messages
   */
  public connection(
    message: string,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.info(message, "CONNECTION", meta);
  }

  /**
   * Log monitoring-related messages
   */
  public monitor(
    message: string,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.debug(message, "MONITOR", meta);
  }

  /**
   * Log authentication-related messages
   */
  public auth(
    message: string,
    meta?: Record<string, unknown> | undefined
  ): void {
    this.info(message, "AUTH", meta);
  }

  /**
   * Log with performance timing
   */
  public time<T>(label: string, fn: () => T): T {
    const start = Date.now();
    const result = fn();
    const duration = Date.now() - start;

    this.debug(`${label} completed`, "TIMING", { duration: `${duration}ms` });

    return result;
  }

  /**
   * Log with async performance timing
   */
  public async timeAsync<T>(label: string, fn: () => Promise<T>): Promise<T> {
    const start = Date.now();
    const result = await fn();
    const duration = Date.now() - start;

    this.debug(`${label} completed`, "TIMING", { duration: `${duration}ms` });

    return result;
  }
}

// Create singleton logger instance
const logger = new Logger();

// Export logger instance and utility functions
export { logger };

/**
 * Backwards compatibility function
 * @deprecated Use logger.socket() instead
 */
export const logMessage = (message: string): void => {
  logger.socket(message);
};
