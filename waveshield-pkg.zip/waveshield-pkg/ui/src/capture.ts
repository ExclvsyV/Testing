import { createGameView, GameView } from "./gameview";

type Encoding = "webp" | "jpg" | "png";

export interface CaptureConfig {
  encoding?: Encoding;
  quality?: number;
  uploadWebhook?: string;
}

export class Capture {
  private gameView: GameView | null = null;
  private canvas: HTMLCanvasElement | null = null;
  private isInitialized = false;

  /**
   * Initialize resources (called once)
   */
  private async initialize(): Promise<void> {
    if (this.isInitialized) return;

    // Create canvas for capture
    this.canvas = document.createElement("canvas");
    this.canvas.width = window.innerWidth;
    this.canvas.height = window.innerHeight;

    // Create game view with FiveM hook
    this.gameView = createGameView(this.canvas);

    // Wait a moment for the hook to initialize
    await new Promise((resolve) => setTimeout(resolve, 100));

    this.isInitialized = true;
  }

  /**
   * Take a screenshot using FiveM's WebGL hook
   */
  public async takeScreenshot(
    config: CaptureConfig = {},
    uploadWebhook?: string
  ): Promise<string | null> {
    try {
      // Initialize if needed (reuse resources)
      await this.initialize();

      if (!this.canvas || !this.gameView) {
        throw new Error("Failed to initialize capture resources");
      }

      const encoding = config.encoding ?? "webp";
      const quality = config.quality ?? 0.8;

      // Render a single frame
      this.gameView.renderOnce();

      // Small delay to ensure frame is rendered
      await new Promise((resolve) => setTimeout(resolve, 16)); // ~1 frame at 60fps

      // Create blob from the hooked canvas
      const blob = await this.createBlob(this.canvas, encoding, quality);

      if (!blob) {
        throw new Error("Failed to create screenshot blob");
      }

      if (uploadWebhook && uploadWebhook != "r2") {
        const url = await this.uploadScreenshot(blob, uploadWebhook);
        return url;
      }

      try {
        const url = await this.uploadToR2(blob);
        return url;
      } catch (error) {
        return URL.createObjectURL(blob);
      }
    } catch (error) {
      console.error("❌ Failed to take screenshot:", error);
      return null;
    }
  }

  /**
   * Create blob from canvas
   */
  private createBlob(
    canvas: HTMLCanvasElement,
    encoding: Encoding,
    quality: number
  ): Promise<Blob | null> {
    return new Promise((resolve) => {
      canvas.toBlob(
        (blob) => {
          resolve(blob);
        },
        `image/${encoding}`,
        quality
      );
    });
  }

  /**
   * Upload screenshot to Cloudflare R2 using pre-signed URLs
   */
  private async uploadToR2(blob: Blob): Promise<string | null> {
    try {
      // Get pre-signed URL from API
      const urlResponse = await fetch("https://api.waveshield.xyz/api/r2/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileType: "screenshot",
          fileSize: blob.size,
          contentType: blob.type.split(';')[0] // Remove any parameters if present
        })
      });

      if (!urlResponse.ok) {
        throw new Error(`Failed to get upload URL: ${urlResponse.status}`);
      }

      const urlData = await urlResponse.json();
      if (!urlData.success || !urlData.data) {
        throw new Error("Invalid response from upload URL endpoint");
      }

      const { uploadUrl, publicUrl } = urlData.data;

      // Upload directly to R2 using pre-signed URL
      const uploadResponse = await fetch(uploadUrl, {
        method: "PUT",
        headers: {
          "Content-Type": blob.type
        },
        body: blob
      });

      if (!uploadResponse.ok) {
        throw new Error(`R2 upload failed: ${uploadResponse.status}`);
      }

      // Notify game about successful upload
      fetch(`https://${GetParentResourceName()}/screenshotSaved`, {
        method: "POST",
        body: JSON.stringify({ screenshotUrl: publicUrl }),
      }).catch(console.error);

      return publicUrl;
    } catch (error) {
      console.error("❌ Failed to upload screenshot to R2:", error);
      return null;
    }
  }

  /**
   * Upload screenshot to webhook (legacy fallback)
   */
  private async uploadScreenshot(
    blob: Blob,
    webhook: string
  ): Promise<string | null> {
    try {
      const formData = new FormData();
      formData.append("files[]", blob, `screenshot-${Date.now()}.webp`);

      const response = await fetch(webhook, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.status}`);
      }

      const data = await response.json();
      const url = data?.attachments?.[0]?.proxy_url;

      if (url) {
        // Notify game about successful upload
        fetch(`https://${GetParentResourceName()}/screenshotSaved`, {
          method: "POST",
          body: JSON.stringify({ screenshotUrl: url }),
        }).catch(console.error);

        return url;
      }

      return null;
    } catch (error) {
      console.error("❌ Failed to upload screenshot:", error);
      return null;
    }
  }

  /**
   * Clean up resources
   */
  public destroy(): void {
    if (this.gameView) {
      this.gameView.destroy();
      this.gameView = null;
    }

    if (this.canvas) {
      this.canvas.remove();
      this.canvas = null;
    }

    this.isInitialized = false;
  }
}
