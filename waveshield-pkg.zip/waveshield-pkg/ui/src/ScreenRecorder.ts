import { Capture, CaptureConfig } from "./capture";
import { CaptureStream, StreamConfig } from "./capture-stream";

interface ScreenRecorderConfig {
  maxVideoFPS?: number;
  videoBitrate?: number;
  recordingSegmentDuration?: number;
  screenshotQuality?: number;
  videoWidth?: number;
  videoHeight?: number;
}

const DEFAULT_CONFIG: Required<ScreenRecorderConfig> = {
  maxVideoFPS: 24,
  videoBitrate: 6500000,
  recordingSegmentDuration: 5000,
  screenshotQuality: 0.8,
  videoWidth: 1280,
  videoHeight: 720,
};

export class ScreenRecorder {
  private config: Required<ScreenRecorderConfig>;
  private capture: Capture;
  private captureStream: CaptureStream | null = null;
  private isStreaming = false;
  private isCaptureInitializing = false;
  private activeConnections: Map<string, RTCPeerConnection> = new Map();
  private connectionTimestamps: Map<string, number> = new Map();
  private lastOfferTimes: Map<string, number> = new Map();
  private connectingStreams: Map<
    string,
    { startTime: number; timeout: NodeJS.Timeout }
  > = new Map();
  private streamIceServers: Map<string, RTCIceServer[]> = new Map();
  private cleanupInterval: NodeJS.Timeout | null = null;
  private maxConnectionsPerStream = 3;

  constructor(config: ScreenRecorderConfig = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.capture = new Capture();
    this.setupNUICallbacks();
    this.startPeriodicCleanup();
  }

  private setupNUICallbacks(): void {
    window.addEventListener("message", async (event) => {
      if (!event.data?.type) return;

      const { type, data } = event.data;

      try {
        let response: any = { success: false };

        switch (type) {
          case "webrtc_offer":
            const iceServers = this.streamIceServers.get(data.streamId);
            const answer = await this.handleWebRTCOffer(
              data.offer,
              data.streamId,
              iceServers
            );
            if (answer) {
              this.sendToClientScript("webrtc_answer", {
                answer,
                streamId: data.streamId,
              });
              response = { success: true };
            } else {
              this.resetStreamState(data.streamId);
              response = { success: false, error: "Failed to create answer" };
            }
            break;

          case "webrtc_ice_candidate":
            await this.handleICECandidate(data.candidate, data.streamId);
            response = { success: true };
            break;

          case "start_stream":
            if (data.iceServers) {              
              let processedIceServers: RTCIceServer[];
              
              if (Array.isArray(data.iceServers)) {
                processedIceServers = data.iceServers;
              } else if (typeof data.iceServers === 'object' && data.iceServers.urls) {
                processedIceServers = [data.iceServers];
              } else {
                processedIceServers = [];
              }
              
              if (processedIceServers.length > 0) {
                this.streamIceServers.set(data.streamId, processedIceServers);
              }
            }
            await this.startStreaming(data.streamId);
            response = { success: true };
            break;

          case "stop_stream":
            this.stopStreaming(data.streamId);
            response = { success: true };
            break;

          default:
            return;
        }

        this.sendToClientScript(`${type}_response`, response);
      } catch (error) {
        console.error(`Failed to handle ${type}:`, error);
        if (data?.streamId) this.resetStreamState(data.streamId);
        this.sendToClientScript(`${type}_response`, {
          success: false,
          error: error instanceof Error ? error.message : "Unknown error",
        });
      }
    });
  }

  public async takeScreenshot(uploadWebhook?: string): Promise<string | null> {
    try {
      const captureConfig: CaptureConfig = {
        encoding: "webp",
        quality: this.config.screenshotQuality,
        ...(uploadWebhook && { uploadWebhook }),
      };
      return await this.capture.takeScreenshot(captureConfig, uploadWebhook);
    } catch (error) {
      console.error("Failed to take screenshot:", error);
      return null;
    }
  }

  public async startRecording(): Promise<void> {
    if (this.captureStream) {
      console.warn("Recording already started");
      return;
    }

    const streamConfig: StreamConfig = {
      videoBitrate: this.config.videoBitrate,
      segmentDuration: this.config.recordingSegmentDuration,
      maxVideoFPS: this.config.maxVideoFPS,
      videoWidth: this.config.videoWidth,
      videoHeight: this.config.videoHeight,
    };

    this.captureStream = new CaptureStream(streamConfig);
    await this.captureStream.startRecording();
  }

  public async sendLastRecording(uploadWebhook?: string): Promise<void> {
    if (!this.captureStream) {
      console.warn("No recording available - call startRecording() first");
      return;
    }
    await this.captureStream.sendLastRecording(uploadWebhook);
  }

  private async handleWebRTCOffer(
    offer: RTCSessionDescriptionInit,
    streamId: string,
    iceServers?: RTCIceServer[]
  ): Promise<RTCSessionDescriptionInit | undefined> {
    const now = Date.now();

    if (this.isRapidDuplicate(streamId, now)) return;

    this.lastOfferTimes.set(streamId, now);
    this.cleanupInactiveConnections(streamId);

    if (!this.enforceConnectionLimits(streamId)) return;

    this.setConnectionTimeout(streamId, now);

    try {
      if (!this.captureStream?.mediaStream) {
        console.error(
          "Failed to start capture stream, enable gameplay capture in configuration"
        );
        this.resetStreamState(streamId);
        return;
      }

      const peerConnection = this.createPeerConnection(iceServers);
      const connectionId = this.generateConnectionId(streamId);

      this.setupPeerConnectionHandlers(peerConnection, connectionId, streamId);
      this.addVideoTrack(peerConnection, connectionId, streamId);

      await peerConnection.setRemoteDescription(offer);
      const answer = await peerConnection.createAnswer({
        offerToReceiveVideo: false,
        offerToReceiveAudio: false,
      });
      await peerConnection.setLocalDescription(answer);

      this.activeConnections.set(connectionId, peerConnection);

      return answer;
    } catch (error) {
      console.error(
        `Failed to handle WebRTC offer for stream ${streamId}:`,
        error
      );
      this.resetStreamState(streamId);
      throw error;
    }
  }

  private isRapidDuplicate(streamId: string, now: number): boolean {
    const connectingStream = this.connectingStreams.get(streamId);
    if (connectingStream && now - connectingStream.startTime < 1000) {
      console.warn(`Blocking rapid duplicate for stream ${streamId}`);
      return true;
    }

    const lastOfferTime = this.lastOfferTimes.get(streamId);
    if (lastOfferTime && now - lastOfferTime < 1000) {
      console.warn(`Blocking rapid duplicate offer for ${streamId}`);
      return true;
    }

    return false;
  }

  private enforceConnectionLimits(streamId: string): boolean {
    const existingConnections = this.getConnectionsForStream(streamId);

    if (existingConnections.length >= this.maxConnectionsPerStream) {
      console.warn(
        `Max connections (${this.maxConnectionsPerStream}) reached for stream ${streamId}`
      );

      const oldestConnection = existingConnections
        .map(([connectionId]) => ({
          connectionId,
          timestamp: this.connectionTimestamps.get(connectionId) || 0,
        }))
        .sort((a, b) => a.timestamp - b.timestamp)[0];

      if (oldestConnection) {
        this.cleanupConnection(oldestConnection.connectionId);
      }
    }

    return true;
  }

  private setConnectionTimeout(streamId: string, startTime: number): void {
    const existingStream = this.connectingStreams.get(streamId);
    if (existingStream) {
      clearTimeout(existingStream.timeout);
    }

    const timeout = setTimeout(() => {
      if (this.connectingStreams.has(streamId)) {
        console.warn(`⏰ Connection timeout for stream ${streamId}`);
        this.resetStreamState(streamId);
      }
    }, 15000);

    this.connectingStreams.set(streamId, { startTime, timeout });
  }

  private createPeerConnection(iceServers?: RTCIceServer[]): RTCPeerConnection {
    // 🎯 BANDWIDTH OPTIMIZATION: STUN-FIRST with TURN FALLBACK
    const stunServers: RTCIceServer[] = [
      { 
        urls: [
          "stun:stun1.l.google.com:19302",
          "stun:stun2.l.google.com:19302",
          "stun:stun.cloudflare.com:3478",
          "stun:openrelay.metered.ca:80"
        ]
      }
    ];

    // Smart ICE server configuration: STUN-first, TURN fallback
    let finalIceServers = stunServers;
    
    if (iceServers && iceServers.length > 0) {
      // Add provided TURN servers AFTER STUN (WebRTC will prefer STUN naturally)
      finalIceServers = [...stunServers, ...iceServers];
    }

    return new RTCPeerConnection({
      iceServers: finalIceServers,
      iceTransportPolicy: "all", // Allow both, prefer STUN naturally
      iceCandidatePoolSize: 10, // Pre-gather candidates for faster connection
      bundlePolicy: "max-bundle", // Bundle all media in one connection
      rtcpMuxPolicy: "require", // Multiplex RTCP with RTP
    });
  }

  private generateConnectionId(streamId: string): string {
    return `${streamId}_${Date.now()}_${Math.random()
      .toString(36)
      .substr(2, 9)}`;
  }

  private setupPeerConnectionHandlers(
    peerConnection: RTCPeerConnection,
    connectionId: string,
    streamId: string
  ): void {
    peerConnection.onconnectionstatechange = () => {
      if (this.activeConnections.get(connectionId) !== peerConnection) return;

      const state = peerConnection.connectionState;

      if (state === "connected") {
        this.resetStreamState(streamId);
        this.connectionTimestamps.set(connectionId, Date.now());
      } else if (["failed", "disconnected", "closed"].includes(state)) {
        this.resetStreamState(streamId);
        this.cleanupConnection(connectionId);
      } else if (state === "connecting") {
        setTimeout(() => {
          if (
            this.activeConnections.get(connectionId) === peerConnection &&
            peerConnection.connectionState === "connecting"
          ) {
            this.cleanupConnection(connectionId);
          }
        }, 10000);
      }
    };

    peerConnection.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendToClientScript("ice_candidate", {
          candidate: event.candidate,
          streamId,
        });
      }
    };
  }

  private addVideoTrack(
    peerConnection: RTCPeerConnection,
    connectionId: string,
    streamId: string
  ): void {
    if (!this.captureStream?.mediaStream) return;

    const videoTracks = this.captureStream.mediaStream.getVideoTracks();
    if (videoTracks.length === 0) {
      console.warn("No video tracks available");
      return;
    }

    const clonedTrack = videoTracks[0]!.clone();
    const sender = peerConnection.addTrack(
      clonedTrack,
      this.captureStream.mediaStream
    );

    // 🎯 BANDWIDTH OPTIMIZATION: Aggressive encoding settings
    const params = sender.getParameters();
    if (params.encodings?.[0]) {
      // Lower bitrate for bandwidth savings
      params.encodings[0].maxBitrate = Math.min(this.config.videoBitrate, 2500000); // Cap at 2.5Mbps
      params.encodings[0].maxFramerate = Math.min(this.config.maxVideoFPS, 20); // Cap at 20fps
      // Additional optimizations
      params.encodings[0].scaleResolutionDownBy = 1.0; // No scaling unless needed
      sender.setParameters(params);
    }
  }

  private async handleICECandidate(
    candidate: RTCIceCandidateInit,
    streamId: string
  ): Promise<void> {
    const connections = this.getConnectionsForStream(streamId);

    for (const [connectionId, peerConnection] of connections) {
      try {
        await peerConnection.addIceCandidate(candidate);
      } catch (error) {
        console.warn(
          `Failed to add ICE candidate to ${connectionId}:`,
          error
        );
      }
    }
  }

  private getConnectionsForStream(
    streamId: string
  ): [string, RTCPeerConnection][] {
    return Array.from(this.activeConnections.entries()).filter(([key]) =>
      key.startsWith(`${streamId}_`)
    );
  }

  private cleanupConnection(connectionId: string): void {
    const peerConnection = this.activeConnections.get(connectionId);
    if (!peerConnection) return;

    peerConnection.getSenders().forEach((sender) => {
      if (sender.track) {
        sender.track.stop();
        peerConnection.removeTrack(sender);
      }
    });

    peerConnection.close();
    this.activeConnections.delete(connectionId);
    this.connectionTimestamps.delete(connectionId);
  }

  private cleanupInactiveConnections(streamId?: string): void {
    const connections = streamId
      ? this.getConnectionsForStream(streamId)
      : Array.from(this.activeConnections.entries());

    let cleaned = 0;
    connections.forEach(([connectionId, conn]) => {
      if (["failed", "disconnected", "closed"].includes(conn.connectionState)) {
        this.cleanupConnection(connectionId);
        cleaned++;
      }
    });
  }

  private resetStreamState(streamId?: string): void {
    if (streamId) {
      const connectingStream = this.connectingStreams.get(streamId);
      if (connectingStream) {
        clearTimeout(connectingStream.timeout);
        this.connectingStreams.delete(streamId);
      }
      this.streamIceServers.delete(streamId);
    } else {
      this.isStreaming = false;
      this.connectingStreams.forEach((value) => clearTimeout(value.timeout));
      this.connectingStreams.clear();
      this.streamIceServers.clear();
    }
  }

  public async startStreaming(streamId?: string): Promise<void> {
    if (!this.captureStream?.mediaStream) {
      console.warn(
        "No capture stream available, enable gameplay capture in configuration"
      );
      return;
    }

    this.isStreaming = true;
    this.sendToClientScript("stream_started", { streamId });
  }

  public stopStreaming(streamId?: string): void {
    if (streamId) {
      this.resetStreamState(streamId);
      this.getConnectionsForStream(streamId).forEach(([connectionId]) =>
        this.cleanupConnection(connectionId)
      );
      this.sendToClientScript("stream_stopped", { streamId });

      if (this.activeConnections.size === 0) {
        this.isStreaming = false;
      }
    } else {
      this.isStreaming = false;
      this.resetStreamState();

      Array.from(this.activeConnections.keys()).forEach((connectionId) =>
        this.cleanupConnection(connectionId)
      );

      this.lastOfferTimes.clear();
      this.streamIceServers.clear();
      this.sendToClientScript("stream_stopped", {});
    }
  }

  private sendToClientScript(eventType: string, data: any): void {
    if (
      typeof fetch !== "undefined" &&
      typeof GetParentResourceName !== "undefined"
    ) {
      fetch(`https://${GetParentResourceName()}/webrtc_event`, {
        method: "POST",
        headers: { "Content-Type": "application/json; charset=UTF-8" },
        body: JSON.stringify({ eventType, data }),
      }).catch((error) =>
        console.error("Failed to send to client script:", error)
      );
    }
  }

  private startPeriodicCleanup(): void {
    this.cleanupInterval = setInterval(
      () => this.cleanupInactiveConnections(),
      5000
    );
  }

  public destroy(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }

    this.stopStreaming();
    this.resetStreamState();

    if (this.captureStream) {
      this.captureStream.destroy();
      this.captureStream = null;
    }

    this.capture.destroy();
    this.isStreaming = false;
  }
}
