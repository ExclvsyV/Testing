export class HardwareIdentifier {
  public static async GetHWID(): Promise<string | null> {
    try {
      const videoCardInfos = await this.getVideoCardInfo();
      const audioContext = new (window.AudioContext ||
        (window as any).webkitAudioContext)();
      const storage = await navigator.storage.estimate();

      const audioDevices = await navigator.mediaDevices.enumerateDevices();
      const audioDeviceLabels = audioDevices
        .map((device) => device.label || "Unknown Device")
        .join(", ");

      // Need to cast to any for browser compatibility
      const navigator_any = navigator as any;
      const performance_any = performance as any;

      // Gather hardware information
      const hwComponents = [
        videoCardInfos.vendor,
        videoCardInfos.renderer,
        navigator.hardwareConcurrency,
        navigator_any.deviceMemory,
        screen.width,
        screen.height,
        screen.colorDepth,
        devicePixelRatio,
        navigator.language,
        navigator_any.connection?.rtt,
        navigator_any.connection?.effectiveType,
        navigator_any.connection?.type,
        performance_any.memory?.jsHeapSizeLimit,
        storage.quota || 0,
        audioDeviceLabels,
        Intl.DateTimeFormat().resolvedOptions().timeZone,
        new Date().getTimezoneOffset(),
        audioContext.sampleRate,
      ];

      const hwid = hwComponents.join("|");

      return "fid:" + (await this.SHA256(hwid));
    } catch (error) {
      console.error("Error generating HWID:", error);
      return null;
    }
  }

  public static async GetStorageId(): Promise<string | null> {
    try {
      let uidNui = localStorage.getItem("__WS_UID_NUI");
      if (!uidNui) {
        uidNui = await this.generateUID();
        localStorage.setItem("__WS_UID_NUI", uidNui);
      }
      return "sid:" + uidNui;
    } catch (error) {
      console.error("Error getting UID from localStorage:", error);
      return null;
    }
  }

  public static IsValidSystemLanguage(): boolean {
    try {
      return Intl.getCanonicalLocales(nuiSystemLanguages).length > 0;
    } catch (e) {
      return false;
    }
  }

  public static IsValidTimezone(): boolean {
    try {
      const userTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const testDate = new Date('2025-01-01T12:00:00Z');
      const formatter = new Intl.DateTimeFormat('en-US', { 
        timeZone: userTimeZone,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
      });
      
      const formatted = formatter.format(testDate);
      
      const isValidFormat = Boolean(formatted && formatted.length > 0);
      const isNotEmpty = Boolean(userTimeZone && userTimeZone.trim().length > 0);
      const hasValidFormat = (
        userTimeZone.includes('/') ||
        userTimeZone === 'UTC'
      );
      
      return isValidFormat && isNotEmpty && hasValidFormat;
    } catch (error) {
      return false;
    }
  }

  private static async generateUID(): Promise<string> {
    return this.SHA256(Math.random().toString(36).substr(2, 9));
  }

  private static async SHA256(message: string): Promise<string> {
    const encoder = new TextEncoder();
    const data = encoder.encode(message);
    const hashBuffer = await crypto.subtle.digest("SHA-256", data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray
      .map((byte) => byte.toString(16).padStart(2, "0"))
      .join("");
    return hashHex;
  }

  private static async getVideoCardInfo(): Promise<{
    vendor: string;
    renderer: string;
  }> {
    try {
      const canvas = document.createElement("canvas");
      const gl =
        (canvas.getContext("webgl") as WebGLRenderingContext) ||
        (canvas.getContext("experimental-webgl") as WebGLRenderingContext);

      if (!gl) {
        throw new Error("Could not create WebGL context");
      }

      const debugInfo = gl.getExtension("WEBGL_debug_renderer_info");

      const vendor = debugInfo
        ? gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL)
        : "Unknown Vendor";
      const renderer = debugInfo
        ? gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL)
        : "Unknown Renderer";

      return { vendor, renderer };
    } catch (error) {
      console.error("Error getting video card info:", error);
      return { vendor: "Unknown Vendor", renderer: "Unknown Renderer" };
    }
  }
}
