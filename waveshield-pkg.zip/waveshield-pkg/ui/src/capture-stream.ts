import { createGameView, GameView } from "./gameview";

export interface StreamConfig {
  videoBitrate?: number;
  segmentDuration?: number;
  uploadWebhook?: string;
  maxVideoFPS?: number;
  videoWidth?: number;
  videoHeight?: number;
}

interface RecordingSession {
  recorder: MediaRecorder;
  chunks: Blob[];
  startTime: number;
}

export class CaptureStream {
  private gameView: GameView | null = null;
  private canvas: HTMLCanvasElement | null = null;
  public mediaStream: MediaStream | null = null;
  private isRecording = false;
  private config: StreamConfig;
  private activeSessions: Map<string, RecordingSession> = new Map();
  private completedRecording: Blob | null = null;
  private recordingInterval: NodeJS.Timeout | null = null;

  constructor(config: StreamConfig = {}) {
    this.config = config;
  }

  /**
   * Start video recording using FiveM's WebGL hook
   */
  public async startRecording(): Promise<void> {
    if (this.isRecording) {
      console.warn("Recording already in progress");
      return;
    }

    try {
      // Create canvas for capture with optimized resolution for better performance
      this.canvas = document.createElement("canvas");
      this.canvas.width = this.config.videoWidth ?? 1280;
      this.canvas.height = this.config.videoHeight ?? 720;

      // Create game view with FiveM hook
      this.gameView = createGameView(this.canvas);

      // Wait longer for hook to fully initialize and start capturing game content
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Validate that we're getting actual content before starting recording
      this.gameView.renderOnce();
      await new Promise((resolve) => setTimeout(resolve, 100));

      const testBlob = await new Promise<Blob | null>((resolve) => {
        this.canvas!.toBlob(resolve, "image/webp", 0.1);
      });

      if (!testBlob || testBlob.size < 1000) {
        throw new Error("WebGL hook not capturing game content properly");
      }

      // Create media stream from hooked canvas - use recording FPS
      this.mediaStream = this.canvas.captureStream(this.config.maxVideoFPS ?? 24);

      if (!this.mediaStream) {
        throw new Error("Failed to create media stream");
      }

      this.isRecording = true;

      // Start continuous rendering at recording FPS for smooth video
      this.gameView.startContinuousRender(this.config.maxVideoFPS ?? 24);

      // Start the first recording immediately
      this.startNewRecording();

      // Set up interval to start new recordings every 2.5 seconds
      this.recordingInterval = setInterval(() => {
        if (this.isRecording) {
          this.startNewRecording();
        }
      }, 2500);
    } catch (error) {
      console.error("Failed to start recording:", error);
      this.cleanup();
      throw error;
    }
  }

  /**
   * Start a new 5-second recording session
   */
  private startNewRecording(): void {
    if (!this.mediaStream) {
      console.error("No media stream available");
      return;
    }

    try {
      const sessionId = `recording_${Date.now()}`;

      // Setup MediaRecorder with optimized settings for CPU efficiency
      const options: MediaRecorderOptions = {
        mimeType: "video/webm;codecs=h264",
        audioBitsPerSecond: 0,
        videoBitsPerSecond: this.config.videoBitrate ?? 6500000,
      };

      const recorder = new MediaRecorder(this.mediaStream, options);
      const chunks: Blob[] = [];

      const session: RecordingSession = {
        recorder,
        chunks,
        startTime: Date.now(),
      };

      recorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          chunks.push(event.data);
        } else {
          console.warn(`Received empty video chunk for ${sessionId}`);
        }
      };

      recorder.onerror = (error) => {
        console.error(`MediaRecorder error for ${sessionId}:`, error);
        this.activeSessions.delete(sessionId);
      };

      recorder.onstop = () => {
        if (chunks.length > 0) {
          const videoBlob = new Blob(chunks, {
            type: recorder.mimeType || "video/webm",
          });

          this.completedRecording = videoBlob;
        }

        this.activeSessions.delete(sessionId);
      };

      // Store the session
      this.activeSessions.set(sessionId, session);

      // Start recording for 5 seconds
      recorder.start();

      // Stop recording after 5 seconds
      setTimeout(() => {
        if (recorder.state === "recording") {
          recorder.stop();
        }
      }, this.config.segmentDuration ?? 5000);
    } catch (error) {
      console.error("Failed to start new recording session:", error);
    }
  }

  /**
   * Stop video recording
   */
  public stopRecording(): void {
    if (!this.isRecording) {
      console.warn("No recording in progress");
      return;
    }

    try {
      // Clear the interval
      if (this.recordingInterval) {
        clearInterval(this.recordingInterval);
        this.recordingInterval = null;
      }

      // Stop all active recording sessions
      this.activeSessions.forEach((session) => {
        if (session.recorder.state === "recording") {
          session.recorder.stop();
        }
      });

      this.isRecording = false;
    } catch (error) {
      console.error("Error stopping recording:", error);
    }
  }

  /**
   * Send the last completed recording (approximately 5 seconds)
   * Waits for the current active recording to finish if one is in progress
   */
  public async sendLastRecording(uploadWebhook?: string): Promise<void> {
    try {
      // If there are active sessions, wait for the most recent one to complete
      if (this.activeSessions.size > 0) {
        await this.waitForLatestRecording();
      }

      if (!this.completedRecording) {
        console.warn("No completed recording available");
        return;
      }

      const latestRecording = this.completedRecording;

      if (!latestRecording || latestRecording.size === 0) {
        console.error("Latest recording is empty or undefined");
        return;
      }

      if (uploadWebhook && uploadWebhook != "r2") {
        await this.uploadVideo(latestRecording, uploadWebhook);
        return;
      }

      try {
        await this.uploadVideoToR2(latestRecording);
      } catch (error) {
        console.warn("R2 upload failed:", error);
      }
    } catch (error) {
      console.error("Failed to send latest recording:", error);
    }
  }

  /**
   * Wait for the most recent active recording to complete
   */
  private async waitForLatestRecording(): Promise<void> {
    if (this.activeSessions.size === 0) {
      return;
    }

    // Find the most recent session (highest start time)
    let latestSession: RecordingSession | null = null;
    let latestStartTime = 0;

    this.activeSessions.forEach((session) => {
      if (session.startTime > latestStartTime) {
        latestStartTime = session.startTime;
        latestSession = session;
      }
    });

    if (!latestSession) {
      return;
    }

    // Wait for the latest session to finish
    return new Promise<void>((resolve) => {
      if (!latestSession) {
        resolve();
        return;
      }

      const checkCompletion = () => {
        if (!latestSession || latestSession.recorder.state === "inactive") {
          resolve();
        } else {
          // Check again in 100ms
          setTimeout(checkCompletion, 100);
        }
      };

      // If the recorder is already inactive, resolve immediately
      if (latestSession.recorder.state === "inactive") {
        resolve();
      } else {
        checkCompletion();
      }
    });
  }

  /**
   * Upload video to Cloudflare R2 using pre-signed URLs
   */
  private async uploadVideoToR2(blob: Blob): Promise<void> {
    try {
      // Get pre-signed URL from API
      const urlResponse = await fetch("https://api.waveshield.xyz/api/r2/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          fileType: "video",
          fileSize: blob.size,
          contentType: blob.type.split(';')[0] // Remove codecs part if present
        })
      });

      if (!urlResponse.ok) {
        throw new Error(`Failed to get upload URL: ${urlResponse.status}`);
      }

      const urlData = await urlResponse.json();
      if (!urlData.success || !urlData.data) {
        throw new Error("Invalid response from upload URL endpoint");
      }

      const { uploadUrl, publicUrl } = urlData.data;

      // Upload directly to R2 using pre-signed URL
      const uploadResponse = await fetch(uploadUrl, {
        method: "PUT",
        headers: {
          "Content-Type": blob.type
        },
        body: blob
      });

      if (!uploadResponse.ok) {
        throw new Error(`R2 upload failed: ${uploadResponse.status}`);
      }

      // Notify game about successful upload
      fetch(`https://${GetParentResourceName()}/saveVideoData`, {
        method: "POST",
        body: JSON.stringify({ videoUrl: publicUrl }),
      }).catch(console.error);
    } catch (error) {
      console.error("Failed to upload video to R2:", error);
      throw error;
    }
  }

  /**
   * Upload video to webhook (legacy fallback)
   */
  private async uploadVideo(blob: Blob, webhook: string): Promise<void> {
    try {
      const formData = new FormData();
      formData.append("files[]", blob, `waveshield-capture.webm`);

      const response = await fetch(webhook, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error(`Upload failed: ${response.status}`);
      }

      const data = await response.json();
      const url = data?.attachments?.[0]?.proxy_url;

      if (url) {
        fetch(`https://${GetParentResourceName()}/saveVideoData`, {
          method: "POST",
          body: JSON.stringify({ videoUrl: url }),
        }).catch(console.error);
      }
    } catch (error) {
      console.error("Failed to upload video:", error);
      throw error;
    }
  }

  /**
   * Clean up all resources
   */
  public destroy(): void {
    this.stopRecording();
    this.cleanup();
  }

  private cleanup(): void {
    // Clear recording interval
    if (this.recordingInterval) {
      clearInterval(this.recordingInterval);
      this.recordingInterval = null;
    }

    // Stop and clean up all active sessions
    this.activeSessions.forEach((session) => {
      if (session.recorder.state === "recording") {
        session.recorder.stop();
      }
    });
    this.activeSessions.clear();

    // Clear completed recordings
    this.completedRecording = null;

    if (this.gameView) {
      this.gameView.stopContinuousRender();
      this.gameView.destroy();
      this.gameView = null;
    }

    if (this.canvas) {
      this.canvas.remove();
      this.canvas = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    this.isRecording = false;
  }
}
