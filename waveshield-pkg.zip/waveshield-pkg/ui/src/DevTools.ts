export class DevTools {
  private static detectionObject: any = null;
  private static isMonitoring: boolean = false;

  public static startMonitoring(): void {
    if (this.isMonitoring) return;

    this.isMonitoring = true;
    this.setupDetectionObject();
  }

  public static stopMonitoring(): void {
    this.isMonitoring = false;
    this.detectionObject = null;
  }

  private static setupDetectionObject(): void {
    this.detectionObject = Object.defineProperties(new Error(), {
      message: {
        get: () => {
          this.handleDetection();
          return "";
        },
        configurable: false,
      },
      toString: {
        value: () => {
          if (new Error().stack?.includes("toString@")) {
            console.log("Safari dev tools detected");
          }
          return "";
        },
        configurable: false,
      },
    });

    console.log(this.detectionObject);
  }

  private static handleDetection(): void {
    if (!this.isMonitoring) return;

    try {
      fetch(`https://${GetParentResourceName()}/devtools`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
        body: JSON.stringify({}),
      }).catch((err) => console.error("Failed to report devtools:", err));
    } catch (error) {
      console.error("DevTools detection error:", error);
    }
  }
}
