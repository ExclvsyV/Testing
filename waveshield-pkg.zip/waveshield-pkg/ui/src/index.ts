import { DevTools } from "./DevTools";
import { HardwareIdentifier } from "./HardwareIdentifier";
import { HeartbeatSystem } from "./HeartbeatSystem";
import { ScreenRecorder } from "./ScreenRecorder";

declare global {
  interface Window {
    waveshield: {
      recorder: ScreenRecorder;
      heartbeat: typeof HeartbeatSystem;
      hardware: typeof HardwareIdentifier;
      devtools: typeof DevTools;
    };
  }
}

class WaveShieldUI {
  private recorder: ScreenRecorder;
  private isInitialized = false;

  constructor() {
    this.recorder = new ScreenRecorder();
    this.setupNUIMessageHandler();
    this.init();
  }

  private async init(): Promise<void> {
    try {
      DevTools.startMonitoring();
      this.isInitialized = true;
    } catch (error) {
      console.error("❌ Failed to initialize WaveShield UI:", error);
    }
  }

  private setupNUIMessageHandler(): void {
    // Listen for NUI messages from FiveM client
    window.addEventListener("message", (event) => {
      if (event.data) {
        this.handleNUIMessage(event.data);
      }
    });
  }

  private async handleNUIMessage(message: any): Promise<void> {
    const { command, ...data } = message;

    try {
      switch (command) {
        case "INIT":
          //HeartbeatSystem.start();
          break;
        case "GET_TOKENS":
          await this.handleGetTokens();
          break;

        case "TAKE_SCREENSHOT":
          await this.recorder.takeScreenshot(data.uploadWebhook);
          break;

        case "START_RECORDING":
          await this.recorder.startRecording();
          break;

        case "SEND_LAST_RECORDING":
          await this.recorder.sendLastRecording(data.uploadWebhook);
          break;
        default:
      }
    } catch (error) {
      console.error(
        "Failed to handle NUI message (command: " + command + "):",
        error
      );
    }
  }

  // Original WaveShield event handlers
  private async handleGetTokens(): Promise<void> {
    const hwid = await HardwareIdentifier.GetHWID();
    const storageId = await HardwareIdentifier.GetStorageId();
    const spooferFlagged =
      !HardwareIdentifier.IsValidTimezone() ||
      !HardwareIdentifier.IsValidSystemLanguage();

    const tokens = {
      a: hwid,
      b: storageId,
      c: spooferFlagged,
    };

    await fetch(`https://${GetParentResourceName()}/tokens`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({ tokens }),
    });
  }

  public async takeScreenshot(): Promise<string | null> {
    if (!this.isInitialized) {
      return null;
    }

    return await this.recorder.takeScreenshot();
  }

  public async sendLastRecording(webhook: string): Promise<void> {
    if (!this.isInitialized) {
      return;
    }

    await this.recorder.sendLastRecording(webhook);
  }

  public destroy(): void {
    this.recorder.destroy();
    HeartbeatSystem.stop();
    DevTools.stopMonitoring();
    this.isInitialized = false;
  }
}

window.addEventListener("DOMContentLoaded", () => {
  const waveshield = new WaveShieldUI();
  window.waveshield = {
    recorder: waveshield["recorder"],
    heartbeat: HeartbeatSystem,
    hardware: HardwareIdentifier,
    devtools: DevTools,
  };
});
