export class HeartbeatSystem {
  private static interval: number | undefined;
  private static heartbeatFrequency: number = 10000; // ms between heartbeats
  private static isRunning: boolean = false;

  public static start(): void {
    if (this.isRunning) return;

    this.isRunning = true;

    this.setupNUIListener();
    this.startHeartbeatLoop();
  }

  public static stop(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = undefined;
    }
    this.isRunning = false;
  }

  private static setupNUIListener(): void {
    window.addEventListener('message', (event) => {
      if (event.data.action === 'heartbeat_request') {
        this.handleHeartbeatRequest(event.data);
      }
    });
  }

  private static async handleHeartbeatRequest(data: any): Promise<void> {
    try {
      if (!data.token) {
        return;
      }

      await this.sendHeartbeatResponse(data.token);
    } catch (error) {}
  }

  private static async sendHeartbeatResponse(token: string): Promise<void> {
    fetch(`https://${GetParentResourceName()}/nui_heartbeat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({
        type: "heartbeat_request",
        token: token,
      }),
    });
  }

  private static startHeartbeatLoop(): void {
    this.interval = window.setInterval(() => {
      this.sendHeartbeatLoop();
    }, this.heartbeatFrequency);
  }

  private static async sendHeartbeatLoop(): Promise<void> {
    try {
      const response = await fetch(`https://${GetParentResourceName()}/nui_heartbeat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json; charset=UTF-8",
        },
        body: JSON.stringify({
          type: "heartbeat_loop",
        }),
      });

      if (!response.ok) {
        this.handleFailedHeartbeat("no_response");
        return;
      }

      const data = await response.text();
      if (!data || !Number(data)) {
        this.handleFailedHeartbeat("no_callback");
        return;
      } else if (Number(data) > 30000) {
        this.handleFailedHeartbeat("thread");
        return;
      }
    } catch (error) {
    }
  }

  private static handleFailedHeartbeat(reason: string = ""): void {
    fetch(`https://${GetParentResourceName()}/no_heartbeat`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json; charset=UTF-8",
      },
      body: JSON.stringify({
        reason: reason,
      }),
    });
  }
}