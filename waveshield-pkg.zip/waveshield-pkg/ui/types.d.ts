/// <reference lib="dom" />
/// <reference lib="dom.iterable" />
/// <reference lib="webworker" />

declare global {
  interface Window {
    gameView?: any;
    webkitAudioContext: typeof AudioContext;
  }

  // FiveM NUI globals
  declare var nuiSystemLanguages: string[];
  declare function GetParentResourceName(): string;
}

export {};
