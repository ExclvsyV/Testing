const path = require("path");
const nodeExternals = require("webpack-node-externals");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const WebpackObfuscator = require("webpack-obfuscator");
const TerserPlugin = require("terser-webpack-plugin");

module.exports = (env, argv) => {
  const isProduction = argv.mode === "production";

  console.log(
    `🔧 Building server in ${isProduction ? "PRODUCTION" : "DEVELOPMENT"} mode`
  );
  console.log(`🔒 Obfuscation will be applied: ${isProduction ? "YES" : "NO"}`);

  return {
    entry: "./server/main.ts",
    target: "node",
    externals: [nodeExternals()],
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          use: {
            loader: "ts-loader",
            options: {
              configFile: path.resolve(__dirname, "../tsconfig.server.json"),
              transpileOnly: false,
              compilerOptions: {
                sourceMap: !isProduction,
              },
            },
          },
          exclude: /node_modules/,
        },
      ],
    },
    plugins: [
      new CleanWebpackPlugin({
        cleanOnceBeforeBuildPatterns: ["dist/server.js", "dist/server.js.map"],
      }),
      // Apply obfuscation only in production
      ...(isProduction
        ? [
            new WebpackObfuscator({
              compact: true,
              controlFlowFlattening: true, // Disable - causes runtime errors
              controlFlowFlatteningThreshold: 0.5,
              deadCodeInjection: false, // Disable for size
              debugProtection: false,
              identifierNamesGenerator: "mangled-shuffled",
              log: false,
              numbersToExpressions: false,
              renameGlobals: true,
              renameProperties: false,
              reservedNames: [
                "require",
                "exports",
                "module",
                "global",
                "process",
                "__dirname",
                "__filename",
              ],
              reservedStrings: [],
              rotateStringArray: true,
              seed: Math.floor(Math.random() * 100000),
              selfDefending: true,
              simplify: true,
              sourceMap: false,
              splitStrings: true,
              splitStringsChunkLength: 8,
              stringArray: true,
              stringArrayCallsTransform: true,
              stringArrayCallsTransformThreshold: 0.8,
              stringArrayEncoding: ["base64"],
              stringArrayIndexShift: true,
              stringArrayRotate: true,
              stringArrayShuffle: true,
              stringArrayWrappersCount: 2,
              stringArrayWrappersChainedCalls: false,
              stringArrayWrappersParametersMaxCount: 3,
              stringArrayWrappersType: "variable",
              stringArrayThreshold: 0.75,
              target: "node",
              transformObjectKeys: false,
              unicodeEscapeSequence: false,
            }),
          ]
        : []),
    ],
    optimization: {
      minimize: isProduction,
      minimizer: [
        new TerserPlugin({
          terserOptions: {
            format: {
              comments: false,
            },
            compress: {
              drop_console: false,
              drop_debugger: true,
              pure_funcs: [],
            },
            mangle: {
              keep_fnames: false,
              properties: {
                regex: /^_/,
              },
            },
          },
          extractComments: false,
        }),
      ],
    },
    resolve: {
      extensions: [".tsx", ".ts", ".js"],
      alias: {
        "@client": path.resolve(__dirname, "../client"),
        "@server": path.resolve(__dirname, "../server"),
        "@shared": path.resolve(__dirname, "../shared"),
        "@types": path.resolve(__dirname, "../src/types"),
        "@config": path.resolve(__dirname, "../src/config"),
      },
    },
    output: {
      filename: "server.js",
      path: path.resolve(__dirname, "../dist"),
      clean: true,
    },
    devtool: isProduction ? false : "source-map",
    stats: {
      colors: true,
      modules: false,
      chunks: false,
      chunkModules: false,
    },
  };
};
