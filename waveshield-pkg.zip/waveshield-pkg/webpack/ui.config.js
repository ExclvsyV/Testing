const path = require("path");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const TerserPlugin = require("terser-webpack-plugin");
const WebpackObfuscator = require("webpack-obfuscator");

module.exports = (env, argv) => {
  const isProduction = argv.mode === "production";

  console.log(
    `🔧 Building UI in ${isProduction ? "PRODUCTION" : "DEVELOPMENT"} mode`
  );
  console.log(
    `🔒 UI Obfuscation will be applied: ${isProduction ? "YES" : "NO"}`
  );

  return {
    entry: "./ui/src/index.ts",
    target: "web",
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          use: {
            loader: "ts-loader",
            options: {
              configFile: path.resolve(__dirname, "../tsconfig.ui.json"),
              transpileOnly: false,
              compilerOptions: {
                sourceMap: !isProduction,
              },
            },
          },
          exclude: /node_modules/,
        },
      ],
    },
    plugins: [
      new CleanWebpackPlugin({
        cleanOnceBeforeBuildPatterns: [
          "dist/ui.js",
          "dist/ui.html",
          "dist/ui.js.map",
        ],
      }),
      new HtmlWebpackPlugin({
        template: "./ui/index.html",
        filename: "ui.html",
        inject: false,
      }),
      // Apply obfuscation only in production
      ...(isProduction
        ? [
            new WebpackObfuscator({
              // Balanced security with performance optimization for browser
              compact: true,
              controlFlowFlattening: true,
              controlFlowFlatteningThreshold: 0.5,
              deadCodeInjection: false, // Disable for size
              debugProtection: true,
              debugProtectionInterval: 4000,
              identifierNamesGenerator: "mangled-shuffled",
              log: false,
              numbersToExpressions: false,
              renameGlobals: true,
              renameProperties: false,
              reservedNames: ["window", "document"],
              reservedStrings: [],
              rotateStringArray: true,
              seed: Math.floor(Math.random() * 100000),
              selfDefending: true,
              simplify: true,
              sourceMap: false,
              splitStrings: true,
              splitStringsChunkLength: 8,
              stringArray: true,
              stringArrayCallsTransform: true,
              stringArrayCallsTransformThreshold: 0.8,
              stringArrayEncoding: ["base64"],
              stringArrayIndexShift: true,
              stringArrayRotate: true,
              stringArrayShuffle: true,
              stringArrayWrappersCount: 2,
              stringArrayWrappersChainedCalls: false,
              stringArrayWrappersParametersMaxCount: 3,
              stringArrayWrappersType: "variable",
              stringArrayThreshold: 0.75,
              target: "browser",
              transformObjectKeys: false,
              unicodeEscapeSequence: false,
            }),
          ]
        : []),
    ],
    optimization: {
      minimize: isProduction,
      minimizer: [
        new TerserPlugin({
          terserOptions: {
            format: {
              comments: false,
            },
            compress: {
              drop_console: false,
              drop_debugger: true,
              pure_funcs: [],
            },
            mangle: {
              keep_fnames: false,
              properties: {
                regex: /^_/,
              },
            },
          },
          extractComments: false,
        }),
      ],
    },
    resolve: {
      extensions: [".tsx", ".ts", ".js"],
      alias: {
        "@config": path.resolve(__dirname, "../src/config"),
      },
    },
    output: {
      filename: "ui.js",
      path: path.resolve(__dirname, "../dist"),
    },
    devtool: isProduction ? false : "source-map",
    stats: {
      colors: true,
      modules: false,
      chunks: false,
      chunkModules: false,
    },
  };
};
