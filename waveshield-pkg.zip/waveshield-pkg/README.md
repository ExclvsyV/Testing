# WaveShield WebRTC Streaming System

This document describes the WebRTC streaming system that allows viewing FiveM players' game views from a web application.

## Architecture Overview

The system uses a multi-tier architecture for secure and scalable WebRTC streaming:

```
FiveM Browser (ScreenRecorder) ↔ FiveM Client Script ↔ FiveM Server Script ↔ Server App ↔ Ingress API ↔ Web App
```

### Communication Flow

1. **FiveM Browser** (ScreenRecorder.ts): Captures game view using WebGL hooks
2. **FiveM Client Script** (client.ts): Handles NUI communication and WebRTC signaling
3. **FiveM Server Script** (server.ts): Manages server-side events and connects to Server App
4. **Server App**: Acts as a proxy and WebRTC handler between FiveM and Ingress API
5. **Ingress API**: Manages WebRTC signaling and session state
6. **Web App**: Provides the streaming interface for administrators

## Installation

### 1. FiveM Server Setup

1. Copy the WaveShield package to your FiveM server's `resources` folder
2. Add the following to your `server.cfg`:

```cfg
# WaveShield configuration
set ws_server_app_url "http://localhost:3001"
set ws_server_id "your_server_id"

# Ensure WaveShield starts
ensure waveshield
```

### 2. Server App Configuration

The Server App needs to be running and accessible from your FiveM server.

Set environment variables:

```bash
INGRESS_API_URL=http://localhost:3002
PORT=3001
```

### 3. Ingress API Configuration

The Ingress API should be running on the configured port (default: 3002).

## Usage

### Starting a Stream

#### From FiveM Game

Players can start streaming using in-game commands:

```
/ws_start_stream
```

#### From Web Application

Administrators can request streams from specific players through the web interface.

### Stopping a Stream

#### From FiveM Game

```
/ws_stop_stream
```

#### From Web Application

Use the stop button in the stream viewer interface.

### Administrative Commands

#### FiveM Server Console

```
ws_list_streams          # List all active streams
ws_stop_all_streams      # Stop all active streams
```

#### FiveM Client

```
/ws_stream_status        # Check your streaming status
/ws_test_stream          # Test streaming functionality
/ws_test_stop           # Test stopping stream
/ws_status              # Show current stream info
```

## API Documentation

### Server App Endpoints

#### Get Active Sessions

```http
GET /api/webrtc/sessions
```

Response:

```json
{
  "success": true,
  "sessions": [
    {
      "streamId": "stream_123_1234567890",
      "playerId": "123",
      "playerName": "John Doe",
      "serverName": "My FiveM Server",
      "startTime": 1234567890000,
      "duration": 30
    }
  ],
  "count": 1
}
```

#### Send WebRTC Offer

```http
POST /api/webrtc/offer
Content-Type: application/json

{
  "playerId": "123",
  "streamId": "stream_123_1234567890",
  "offer": {
    "type": "offer",
    "sdp": "v=0\r\no=..."
  }
}
```

#### Send ICE Candidate

```http
POST /api/webrtc/ice-candidate
Content-Type: application/json

{
  "playerId": "123",
  "streamId": "stream_123_1234567890",
  "candidate": {
    "candidate": "candidate:...",
    "sdpMLineIndex": 0,
    "sdpMid": "0"
  }
}
```

#### Request Stream

```http
POST /api/webrtc/request-stream
Content-Type: application/json

{
  "playerId": "123"
}
```

### WebSocket Events

The system uses WebSocket connections for real-time communication:

#### Server App ↔ FiveM Server

- `server:register` - FiveM server registration
- `webrtc:offer` - WebRTC offer forwarding
- `webrtc:answer` - WebRTC answer forwarding
- `webrtc:ice_candidate` - ICE candidate forwarding
- `webrtc:stream_started` - Stream started notification
- `webrtc:stream_stopped` - Stream stopped notification

#### Web App ↔ Server App (via Socket.IO)

- `stream:started` - New stream available
- `stream:stopped` - Stream ended
- `webrtc:answer` - WebRTC answer from FiveM
- `webrtc:ice_candidate` - ICE candidate from FiveM

## Testing

### 1. Start Services

```bash
# Start Ingress API (port 3002)
cd waveshield-v3/apps/ingress-api
npm run dev

# Start Server App (port 3001)
cd waveshield-v3/apps/server
npm run dev

# Start Web App (port 3000)
cd waveshield-v3/apps/web
npm run dev
```

### 2. Start FiveM Server

Make sure the WaveShield resource is installed and started.

### 3. Test Stream

1. Connect to your FiveM server
2. Run `/ws_start_stream` in game
3. Go to `http://localhost:3000/dashboard/stream-test`
4. You should see the active stream in the list
5. Click on the stream to start viewing

## Troubleshooting

### Common Issues

#### Connection Issues

- Verify all services are running on correct ports
- Check firewall settings
- Ensure WebSocket connections are allowed

#### Stream Not Starting

- Check FiveM console for errors
- Verify NUI is properly loaded
- Check browser console for WebRTC errors

#### No Video/Audio

- Check WebRTC peer connection state
- Verify MediaStream is being captured
- Check browser permissions for media access

### Debug Commands

#### FiveM Client

```
/ws_status              # Show current stream status
/ws_test_stream         # Test stream functionality
```

#### Check Logs

- FiveM server logs for server-side issues
- Browser console for client-side issues
- Server App logs for API issues
- Ingress API logs for WebRTC signaling issues

### WebRTC Connection States

Monitor these connection states for debugging:

- `new` - Initial state
- `connecting` - Establishing connection
- `connected` - Successfully connected
- `disconnected` - Connection lost
- `failed` - Connection failed
- `closed` - Connection closed

## Security Considerations

1. **Authentication**: Implement proper authentication for stream requests
2. **Authorization**: Verify users have permission to view specific streams
3. **Rate Limiting**: Implement rate limiting for API endpoints
4. **HTTPS**: Use HTTPS in production for secure WebRTC signaling
5. **CORS**: Configure CORS properly for cross-origin requests

## Performance Optimization

1. **Video Quality**: Adjust bitrate and FPS based on network conditions
2. **ICE Servers**: Use TURN servers for NAT traversal in production
3. **Caching**: Implement proper caching for session data
4. **Load Balancing**: Consider load balancing for multiple FiveM servers

## Development

### Architecture Components

1. **ScreenRecorder.ts**: WebGL game capture and WebRTC peer handling
2. **client.ts**: FiveM client-side script for command handling
3. **server.ts**: FiveM server-side script for session management
4. **webrtc-handler.ts**: Server App service for WebRTC coordination
5. **webrtc.routes.ts**: Ingress API routes for WebRTC signaling
6. **stream-test/page.tsx**: Web App streaming interface

### Adding Features

To add new streaming features:

1. Update the relevant interface definitions
2. Add handlers in the appropriate layer
3. Test the entire communication chain
4. Update documentation

### Environment Variables

| Variable                 | Description                    | Default                 |
| ------------------------ | ------------------------------ | ----------------------- |
| `ws_server_app_url`      | Server App WebSocket URL       | `http://localhost:3001` |
| `ws_server_id`           | Unique FiveM server identifier | Auto-generated          |
| `INGRESS_API_URL`        | Ingress API URL for Server App | `http://localhost:3002` |
| `NEXT_PUBLIC_SERVER_URL` | Server App URL for Web App     | `http://localhost:3001` |
