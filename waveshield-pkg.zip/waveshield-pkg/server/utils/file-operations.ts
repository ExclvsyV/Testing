/**
 * WaveShield File Operations Utility
 * Secure file handling operations for the FiveM resource
 */

import { logger } from "@shared/utils/logger";
import * as fs from "fs";

/**
 * Save data to a resource file
 */
export function saveResourceFile(
  resourceName: string,
  fileName: string,
  data: string
): boolean {
  const filePath = GetResourcePath(resourceName) + "/" + fileName;

  try {
    fs.writeFileSync(filePath, data);
    return true;
  } catch (error) {
    console.log(error);
    logger.error(`Error saving file ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}

/**
 * Load data from a resource file
 */
export function loadResourceFile(
  resourceName: string,
  fileName: string
): string | null {
  try {
    const filePath = GetResourcePath(resourceName) + "/" + fileName;
    const data = fs.readFileSync(filePath, "utf8");
    return data;
  } catch (error) {
    logger.warn(`Error reading file ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return null;
  }
}

/**
 * Create a directory in the resource path
 */
export function createDirectory(
  resourceName: string,
  dirName: string
): boolean {
  const dirPath = GetResourcePath(resourceName) + "/" + dirName;

  try {
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }
    return true;
  } catch (error) {
    logger.error(`Error creating directory ${dirName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}

/**
 * Check if a file exists
 */
export function fileExists(resourceName: string, fileName: string): boolean {
  const filePath = GetResourcePath(resourceName) + "/" + fileName;
  return fs.existsSync(filePath);
}

/**
 * Get file stats
 */
export function getFileStats(
  resourceName: string,
  fileName: string
): fs.Stats | null {
  try {
    const filePath = GetResourcePath(resourceName) + "/" + fileName;
    return fs.statSync(filePath);
  } catch (error) {
    logger.warn(`Error getting file stats for ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return null;
  }
}

/**
 * Delete a file
 */
export function deleteFile(resourceName: string, fileName: string): boolean {
  try {
    const filePath = GetResourcePath(resourceName) + "/" + fileName;
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  } catch (error) {
    logger.error(`Error deleting file ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}

/**
 * Read JSON file and parse it
 */
export function loadJsonFile<T = unknown>(
  resourceName: string,
  fileName: string
): T | null {
  const data = loadResourceFile(resourceName, fileName);
  if (!data) {
    return null;
  }

  try {
    return JSON.parse(data) as T;
  } catch (error) {
    logger.error(`Error parsing JSON file ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return null;
  }
}

/**
 * Save object as JSON file
 */
export function saveJsonFile(
  resourceName: string,
  fileName: string,
  data: unknown
): boolean {
  try {
    const jsonString = JSON.stringify(data, null, 2);
    return saveResourceFile(resourceName, fileName, jsonString);
  } catch (error) {
    logger.error(`Error stringifying JSON for file ${fileName}`, "FILE_OPS", {
      error: error instanceof Error ? error.message : String(error),
    });
    return false;
  }
}

/**
 * Emergency stop server function
 */
export function stopServer(): void {
  process.exit(0);
}

// Export functions for FiveM resource compatibility
globalThis.exports("SaveResourceFile", saveResourceFile);
globalThis.exports("LoadResourceFile", loadResourceFile);
globalThis.exports("CreateDirectory", createDirectory);
globalThis.exports("DeleteFile", deleteFile);
globalThis.exports("StopServer", stopServer);
globalThis.exports("js_loaded", () => true);
