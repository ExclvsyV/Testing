/// <reference types="@citizenfx/server" />

import { Events } from "@shared/constants";
import { logger } from "@shared/utils/logger";
import { SocketManager } from "./services/socket-manager";
import { ConsoleManager } from "./services/console-manager";
// Import file operations to ensure exports are preserved in build
import "./utils/file-operations";

/**
 * Initialize the server
 */
const init = (licenseKey: string, version: string) => {
  // Initialize console manager (will set up console capture)
  ConsoleManager.getInstance();
  
  // Initialize socket manager
  const socketManager = SocketManager.getInstance();
  const initialized = socketManager.initialize(licenseKey, version);

  if (!initialized) {
    logger.error("Failed to initialize socket connection", "INIT");
  }
};

on(Events.WAVESHIELD_START, (licenseKey: string, version: string) => {
  if (global.source > 0) return;
  init(licenseKey, version);
});

// Clean up on resource stop
on("onResourceStop", (resourceName: string) => {
  if (GetCurrentResourceName() !== resourceName) return;
  SocketManager.getInstance().cleanup();
  ConsoleManager.getInstance().cleanup();
});
