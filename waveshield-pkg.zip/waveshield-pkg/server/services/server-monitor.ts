import { Events, LogContexts, PlayerWeapons } from "@shared/constants";
import { logger } from "@shared/utils/logger";
import { getConfig } from "../../src/config";
import { PlayerData, PlayerStatus } from "../../src/types";
import { SocketManager } from "./socket-manager";

export class ServerMonitor {
  private static interval: NodeJS.Timeout | null = null;
  private static readonly config = getConfig();
  private static monitoring: boolean = false;
  private static playerCache = new Map<number, PlayerData>();
  private static resourceName = GetCurrentResourceName();
  private static exports = globalThis.exports[this.resourceName];
  /**
   * Start monitoring server information and sending updates
   */
  public static startMonitoring(): void {
    if (this.monitoring) return;

    this.stopMonitoring();
    this.monitoring = true;

    // Initialize player cache with current players
    this.initializePlayerCache();

    // Send initial update
    this.updateServerInfos();

    // Set up recurring updates for dynamic data only
    this.interval = setInterval(async () => {
      await this.updateDynamicPlayerData();
      await this.updateServerInfos();
    }, this.config.monitoring.updateInterval);

    // Set up player join/leave event handlers
    this.setupPlayerEventHandlers();

    const socketManager = SocketManager.getInstance();

    on(
      Events.WAVESHIELD_EMIT,
      (eventName: string, data: any, _cb?: Function) => {
        const result = socketManager.emit(eventName, data);
        _cb?.(result);
      }
    );

    socketManager.on("kickPlayer", async (data: any, cb?: Function) => {
      const { playerId, reason, by } = data;
      if (this.exports?.kickPlayer) {
        const success = await this.exports.kickPlayer(
          Number(playerId),
          reason,
          {
            kickedBy: by,
          }
        );

        cb?.(success);
        return;
      }
      cb?.(undefined);
    });

    socketManager.on("banPlayer", async (data: any, cb?: Function) => {
      const { playerId, reason, by, duration } = data;
      if (this.exports?.banPlayer) {
        const success = await this.exports.banPlayer(
          Number(playerId),
          reason,
          {
            bannedBy: by,
          },
          duration
        );
        cb?.(success);
        return;
      }
      cb?.(undefined);
    });

    socketManager.on("screenshotPlayer", async (data: any, cb?: Function) => {
      const { playerId } = data;
      if (this.exports?.screenshot) {
        const screenshotUrl = await this.exports.screenshot(Number(playerId), "r2");
        cb?.(screenshotUrl);
        return;
      }
      cb?.(undefined);
    });

    socketManager.on("RequestPlayerStream", (data: any) => {
      const { playerId } = data;
      logger.debug(
        `Stream requested for player ${playerId}`,
        LogContexts.SERVER_MONITOR
      );
      // TODO: Implement spectate functionality
    });
  }

  /**
   * Initialize player cache with all current players
   */
  private static async initializePlayerCache(): Promise<void> {
    const totalPlayers = GetNumPlayerIndices();

    for (let i = 0; i < totalPlayers; i++) {
      try {
        const playerId = Number(GetPlayerFromIndex(i));
        await this.addPlayerToCache(playerId);
      } catch (error) {
        logger.warn(
          `Error initializing player ${i} in cache`,
          LogContexts.SERVER_MONITOR,
          { error: error instanceof Error ? error.message : String(error) }
        );
      }
    }
  }

  /**
   * Set up event handlers for player join/leave
   */
  private static setupPlayerEventHandlers(): void {
    // Handle player connecting (permanent data)
    on("playerJoining", async () => {
      const playerSrc = global.source;
      if (typeof playerSrc === "undefined" || playerSrc === null) {
        return;
      }
      const playerId = Number(playerSrc);

      // Small delay to ensure player data is available
      setTimeout(async () => {
        await this.addPlayerToCache(playerId);
      }, 5000);
    });

    // Handle player dropping (remove from cache)
    on("playerDropped", (reason: string) => {
      const playerSrc = global.source;
      if (typeof playerSrc === "undefined" || playerSrc === null) {
        return;
      }
      const playerId = Number(playerSrc);
      const playerData = this.playerCache.get(playerId);

      if (playerData) {
        logger.debug(
          `Player ${playerId} (${playerData.name}) disconnected: ${reason}`,
          LogContexts.SERVER_MONITOR
        );
        this.playerCache.delete(playerId);
      }
    });
  }

  /**
   * Add a player to the cache with permanent data
   */
  private static async addPlayerToCache(playerId: number): Promise<void> {
    try {
      const playerSrc = playerId.toString();
      const playerName = GetPlayerName(playerSrc);

      if (!playerName || typeof playerName !== 'string') {
        return;
      }

      const playerState = Player(playerId).state;
      const playerLicense = GetPlayerIdentifierByType(playerSrc, "license") || "";
      const isAdmin =
        IsPlayerAceAllowed(playerSrc, "WaveShield.Bypass") ||
        playerState?.["WS:isAdmin"] ||
        playerState?.["WS:isBypass"];

      // Get initial dynamic data
      const dynamicData = await this.getPlayerDynamicData(playerId);

      const cachedPlayer: PlayerData = {
        // Permanent data
        id: playerId,
        license: playerLicense,
        name: playerName,
        admin: isAdmin,
        threatScore: playerState?.["WS:threatScore"] || 0,
        // Initial dynamic data
        ...dynamicData,
      };

      this.playerCache.set(playerId, cachedPlayer);
    } catch (error) {
      console.log(error);
      logger.error(
        `Failed to add player ${playerId} to cache`,
        LogContexts.SERVER_MONITOR,
        { error: error instanceof Error ? error.message : String(error) }
      );
    }
  }

  /**
   * Get dynamic player data that changes frequently
   */
  private static async getPlayerDynamicData(playerId: number): Promise<{
    ping: number;
    coords: { x: number; y: number };
    health: number;
    status: PlayerStatus;
    timeOnline: number;
    playTime: number;
  }> {
    const playerSrc = playerId.toString();
    const playerPed = GetPlayerPed(playerSrc);
    const playerState = Player(playerId).state;
    const playerCoords = GetEntityCoords(playerPed);
    const playerHealth = GetEntityHealth(playerPed);
    const playerMaxHealth = GetEntityMaxHealth(playerPed);
    const playerVehicle = GetVehiclePedIsIn(playerPed, false);
    const playerWeapon = GetSelectedPedWeapon(playerPed);
    const playerTimeOnlineRaw = GetPlayerTimeOnline(playerSrc);
    const playerTimeOnline = parseFloat(
      typeof playerTimeOnlineRaw === 'number' 
        ? (playerTimeOnlineRaw / 60).toFixed() 
        : "0"
    );

    return {
      ping: GetPlayerPing(playerSrc) || 0,
      coords: {
        x: parseFloat(playerCoords[0]?.toFixed(2) || "0"),
        y: parseFloat(playerCoords[1]?.toFixed(2) || "0"),
      },
      health: Math.floor((playerHealth / playerMaxHealth) * 100) || 0,
      status: this.getPlayerStatus(playerHealth, playerVehicle, playerWeapon),
      timeOnline: playerTimeOnline,
      playTime: (playerState?.["WS:playTime"] || 0) + playerTimeOnline,
    };
  }

  /**
   * Update dynamic data for all cached players
   */
  private static async updateDynamicPlayerData(): Promise<void> {
    const playerIds = Array.from(this.playerCache.keys());
    const batchSize = this.config.monitoring.playerBatchSize || 50;

    for (let i = 0; i < playerIds.length; i += batchSize) {
      const batch = playerIds.slice(i, i + batchSize);

      await Promise.all(
        batch.map(async (playerId) => {
          try {
            const playerSrc = playerId.toString();

            const cachedPlayer = this.playerCache.get(playerId);
            if (!cachedPlayer) return;

            // Check if player still exists on server
            const currentPlayerName = GetPlayerName(playerSrc);
            if (!currentPlayerName || typeof currentPlayerName !== 'string') {
              // Player no longer exists, remove from cache
              this.playerCache.delete(playerId);
              return;
            }

            // Update only dynamic data
            const dynamicData = await this.getPlayerDynamicData(playerId);

            // Merge with existing cached data
            this.playerCache.set(playerId, {
              ...cachedPlayer,
              ...dynamicData,
            });
          } catch (error) {
            logger.warn(
              `Error updating dynamic data for player ${playerId}`,
              LogContexts.SERVER_MONITOR,
              { error: error instanceof Error ? error.message : String(error) }
            );
          }
        })
      );

      // Small delay between batches to prevent blocking
      if (i + batchSize < playerIds.length) {
        await new Promise((resolve) => setTimeout(resolve, 25));
      }
    }
  }

  /**
   * Stop monitoring server information
   */
  public static stopMonitoring(): void {
    if (this.interval) {
      clearInterval(this.interval);
      this.interval = null;
    }
    this.monitoring = false;
    this.playerCache.clear();
  }

  /**
   * Determine player status based on vehicle and weapon
   */
  public static getPlayerStatus(
    health: number,
    vehicle: number,
    weapon: number
  ): PlayerStatus {
    if (health <= 0) return PlayerStatus.DEAD;
    if (vehicle && vehicle !== 0) return PlayerStatus.IN_VEHICLE;
    if (weapon !== PlayerWeapons.UNARMED && weapon !== 0)
      return PlayerStatus.ARMED;

    return PlayerStatus.ON_FOOT;
  }

  /**
   * Get the current player list from cache (optimized)
   */
  public static async getPlayerList(): Promise<PlayerData[]> {
    const playerList: PlayerData[] = [];

    for (const [playerId, cachedPlayer] of this.playerCache.entries()) {
      try {
        const playerData: PlayerData = {
          id: cachedPlayer.id,
          license: cachedPlayer.license,
          name: cachedPlayer.name,
          ping: cachedPlayer.ping,
          admin: cachedPlayer.admin,
          threatScore: cachedPlayer.threatScore,
          playTime: cachedPlayer.playTime,
          coords: cachedPlayer.coords,
          health: cachedPlayer.health,
          status: cachedPlayer.status,
          timeOnline: cachedPlayer.timeOnline,
        };

        playerList.push(playerData);
      } catch (error) {
        logger.warn(
          `Error processing cached player ${playerId}`,
          LogContexts.SERVER_MONITOR,
          {
            error: error instanceof Error ? error.message : String(error),
          }
        );

        // Remove invalid cached data
        this.playerCache.delete(playerId);
      }
    }

    logger.debug(
      `Retrieved ${playerList.length} players from cache`,
      LogContexts.SERVER_MONITOR
    );
    return playerList;
  }

  /**
   * Get cached player count
   */
  public static getCachedPlayerCount(): number {
    return this.playerCache.size;
  }

  /**
   * Update server information and send to API (optimized)
   */
  private static async updateServerInfos(): Promise<void> {
    const serverInfos: any = {
      players: await this.getPlayerList(),
      slots: GetConvarInt("sv_maxclients", 32),
    };
    SocketManager.getInstance().emit("updateServerInfos", serverInfos);
  }
}
