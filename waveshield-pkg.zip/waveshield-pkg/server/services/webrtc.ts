import { SocketManager } from "./socket-manager";

interface StreamSession {
  streamId: string;
  playerId: string;
  playerName: string;
  startTime: number;
}

export class WebRTCService {
  private static instance: WebRTCService;
  private activeStreams = new Map<string, StreamSession>();
  private socketManager: SocketManager;
  private initialized = false;

  private constructor() {
    this.socketManager = SocketManager.getInstance();
  }

  public static getInstance(): WebRTCService {
    if (!WebRTCService.instance) {
      WebRTCService.instance = new WebRTCService();
    }
    return WebRTCService.instance;
  }

  /**
   * Initialize WebRTC handlers after authentication
   */
  public initialize(): void {
    if (this.initialized) {
      return;
    }

    this.setupSocketHandlers();
    this.setupNetHandlers();

    this.initialized = true;
  }

  /**
   * Setup socket event handlers for WebRTC
   */
  private setupSocketHandlers(): void {
    // Register WebRTC event handlers
    this.socketManager.on("webrtc:offer", (data: any) => {
      this.handleWebRTCOffer(data.playerId, data.streamId, data.offer);
    });

    this.socketManager.on("webrtc:ice_candidate_remote", (data: any) => {
      this.handleRemoteICECandidate(
        data.playerId,
        data.streamId,
        data.candidate
      );
    });

    this.socketManager.on("webrtc:start_stream_request", (data: any) => {
      this.handleStartStreamRequest(data.playerId, data.streamId, data.iceServers);
    });
  }

  /**
   * Setup FiveM net event handlers
   */
  private setupNetHandlers(): void {
    // Handle stream started from client
    onNet("_WS:webrtc:stream_started", (data: any) => {
      const playerId = global.source.toString();

      const session: StreamSession = {
        streamId: data.streamId,
        playerId: playerId.toString(),
        playerName: GetPlayerName(playerId.toString()) || `Player ${playerId}`,
        startTime: Date.now(),
      };

      this.activeStreams.set(data.streamId, session);

      // Notify server app via SocketManager
      if (this.socketManager?.isAuthenticated()) {
        this.socketManager.emit("webrtc:stream_started", {
          ...session,
        });
      }
    });

    // Handle stream stopped from client
    onNet("_WS:webrtc:stream_stopped", (data: any) => {
      const playerId = global.source.toString();

      // Find and remove the stream
      const streamToRemove = Array.from(this.activeStreams.entries()).find(
        ([, session]) => session.playerId === playerId
      );

      if (streamToRemove) {
        const [streamId, session] = streamToRemove;
        this.activeStreams.delete(streamId);

        // Notify server app via SocketManager
        if (this.socketManager?.isAuthenticated()) {
          this.socketManager.emit("webrtc:stream_stopped", {
            streamId,
            playerId: playerId,
            playerName: session.playerName,
            reason: data.reason || "User stopped",
          });
        }
      }
    });

    // Handle WebRTC answer from client
    onNet("_WS:webrtc:answer", (data: any) => {
      const playerId = global.source.toString();

      // Forward to server app via SocketManager
      if (this.socketManager?.isAuthenticated()) {
        this.socketManager.emit("webrtc:answer", {
          playerId: playerId.toString(),
          streamId: data.streamId,
          answer: data.answer,
        });
      }
    });

    // Handle ICE candidate from client
    onNet("_WS:webrtc:ice_candidate", (data: any) => {
      const playerId = global.source.toString();

      // Forward to server app via SocketManager
      if (this.socketManager?.isAuthenticated()) {
        this.socketManager.emit("webrtc:ice_candidate", {
          playerId: playerId.toString(),
          streamId: data.streamId,
          candidate: data.candidate,
          source: "fivem_client",
        });
      }
    });

    // Handle player disconnect cleanup
    on("playerDropped", (reason: string) => {
      const playerId = source.toString();

      // Clean up any active streams for this player
      const streamsToRemove = Array.from(this.activeStreams.entries()).filter(
        ([, session]) => session.playerId === playerId
      );

      for (const [streamId, session] of streamsToRemove) {
        this.activeStreams.delete(streamId);

        // Notify server app via SocketManager
        if (this.socketManager?.isAuthenticated()) {
          this.socketManager.emit("webrtc:stream_stopped", {
            streamId,
            playerId,
            playerName: session.playerName,
            reason: `Player disconnected: ${reason}`,
          });
        }
      }
    });
  }

  /**
   * Handle WebRTC offer from web app (via server app)
   */
  private handleWebRTCOffer(
    playerId: string,
    streamId: string,
    offer: any
  ): void {
    // Forward to client script
    emitNet("_WS:webrtc:offer", parseInt(playerId), {
      streamId,
      offer,
    });
  }

  /**
   * Handle remote ICE candidate from web app (via server app)
   */
  private handleRemoteICECandidate(
    playerId: string,
    streamId: string,
    candidate: any
  ): void {
    // Forward to client script
    emitNet("_WS:webrtc:ice_candidate", parseInt(playerId), {
      streamId,
      candidate,
    });
  }

  /**
   * Handle stream request from web app
   */
  private handleStartStreamRequest(playerId: string, streamId: string, iceServers?: any[]): void {
    // Send stream request to specific player with ICE servers
    emitNet("_WS:webrtc:start_stream_request", parseInt(playerId), {
      streamId,
      iceServers,
    });
  }

  /**
   * Get all active streams
   */
  public getActiveStreams(): StreamSession[] {
    return Array.from(this.activeStreams.values());
  }

  /**
   * Stop a player's stream
   */
  public stopPlayerStream(playerId: string): void {
    emitNet("_WS:webrtc:stop_stream", parseInt(playerId));
  }

  /**
   * Check if service is initialized
   */
  public isInitialized(): boolean {
    return this.initialized;
  }
}
