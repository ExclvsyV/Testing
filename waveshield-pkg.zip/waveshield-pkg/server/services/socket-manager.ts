import { ServerMonitor } from "@server/services/server-monitor";
import { logger } from "@shared/utils/logger";
import { io, Socket } from "socket.io-client";
import { getConfig, validateConfig } from "../../src/config";
import { WebRTCService } from "./webrtc";
import { ConsoleManager } from "./console-manager";

export class SocketManager {
  private static instance: SocketManager;
  private socket: Socket | null = null;
  private authenticated = false;
  private eventHandlers: Map<
    string,
    Set<(data: any, callback?: Function) => void>
  > = new Map();
  private connectionTimeout: NodeJS.Timeout | null = null;
  private readonly config = getConfig();

  private constructor() {
    // Private constructor for singleton pattern
    if (!validateConfig(this.config)) {
      logger.error("Invalid configuration detected", "SOCKET_MANAGER");
      throw new Error("Invalid configuration");
    }
  }

  /**
   * Get the singleton instance of SocketManager
   */
  public static getInstance(): SocketManager {
    if (!SocketManager.instance) {
      SocketManager.instance = new SocketManager();
    }
    return SocketManager.instance;
  }

  /**
   * Initialize the socket connection with authentication
   */
  public initialize(licenseKey: string, version: string): boolean {
    this.socket = io(this.config.api.url, {
      reconnection: true,
      reconnectionAttempts: this.config.connection.reconnectAttempts,
      reconnectionDelay: this.config.connection.reconnectDelay,
      timeout: this.config.connection.connectionTimeout,
      query: {
        version: version,
        licenseKey: licenseKey,
      },
      extraHeaders: {
        "User-Agent": this.config.api.userAgent,
      },
    });

    this.setupSocketEvents();

    return true;
  }

  /**
   * Set up basic socket event listeners
   */
  private setupSocketEvents(): void {
    if (!this.socket) return;

    // Set connection timeout
    this.connectionTimeout = setTimeout(() => {
      if (!this.authenticated) {
        logger.error(
          "Connection timeout - Failed to authenticate in time",
          "SOCKET_MANAGER"
        );
        this.shutdown();
      }
    }, this.config.connection.connectionTimeout);

    // Connection established
    this.socket.on("connect", () => {});

    // Connection errors (including authentication failures)
    this.socket.on("connect_error", (error) => {
      logger.error(`Connection failed: ${error.message}`, "SOCKET_MANAGER");

      // Clear timeout since we got a response
      if (this.connectionTimeout) {
        clearTimeout(this.connectionTimeout);
        this.connectionTimeout = null;
      }
    });

    // Authentication events
    this.socket.on("authenticated", (data) => {
      if (data.success) {
        this.authenticated = true;
        if (this.connectionTimeout) {
          clearTimeout(this.connectionTimeout);
          this.connectionTimeout = null;
        }
        logger.auth("Successfully authenticated with the websocket server");
        ServerMonitor.startMonitoring();

        // Initialize WebRTC service after authentication
        const webrtcService = WebRTCService.getInstance();
        webrtcService.initialize();

        // Initialize Console manager after authentication
        const consoleManager = ConsoleManager.getInstance();
        consoleManager.handleConsoleConnected();
      }
    });

    // Disconnection events
    this.socket.on("disconnect", (reason) => {
      this.authenticated = false;
      logger.connection(`Disconnected from websocket server: ${reason}`);
    });

    // Reconnection events
    this.socket.io.on("reconnect", (attempt) => {
      logger.connection(`Reconnected to server after ${attempt} attempts`);
    });

    this.socket.io.on("reconnect_attempt", (attempt) => {
      logger.connection(`Reconnection attempt ${attempt}...`);
    });

    this.socket.io.on("reconnect_error", () => {
      //logger.error(`Reconnection error: ${error.message}`, "SOCKET_MANAGER");
    });

    this.socket.io.on("reconnect_failed", () => {
      logger.error("Failed to reconnect after all attempts", "SOCKET_MANAGER");
    });

    // Error handling
    this.socket.on("error", (error) => {
      logger.error(`Socket error: ${error.toString()}`, "SOCKET_MANAGER");
    });

    this.socket.on("config-update", (_data) => {
      globalThis.exports.WaveShield?.ReloadConfiguration?.();
    });

    // Console event handlers
    this.socket.on("console:subscribe", (_data) => {
      const consoleManager = ConsoleManager.getInstance();
      consoleManager.handleConsoleConnected();
    });

    this.socket.on("console:unsubscribe", (_data) => {
      const consoleManager = ConsoleManager.getInstance();
      consoleManager.handleConsoleDisconnected("Unsubscribed");
    });

    this.socket.on("console:command", (data) => {
      if (data.command) {
        const consoleManager = ConsoleManager.getInstance();
        consoleManager.executeCommand(data.username, data.command);
      }
    });
  }

  /**
   * Register an event handler for a specific event type
   */
  public on(
    eventName: string,
    handler: (data: any, callback?: Function) => void
  ): void {
    if (!this.eventHandlers.has(eventName)) {
      this.eventHandlers.set(eventName, new Set());

      // Register with the socket if we have an active connection
      if (this.socket) {
        this.socket.on(eventName, (data: any, callback?: Function) => {
          const handlers = this.eventHandlers.get(eventName);
          if (handlers) {
            handlers.forEach((h) => h(data, callback));
          }
        });
      }
    }

    // Add the handler to our internal collection
    const handlers = this.eventHandlers.get(eventName);
    if (handlers) {
      handlers.add(handler);
    }
  }

  /**
   * Remove a specific handler for an event type
   */
  public off(
    eventName: string,
    handler?: (data: any, callback?: Function) => void
  ): void {
    if (!this.eventHandlers.has(eventName)) return;

    if (handler) {
      // Remove specific handler
      const handlers = this.eventHandlers.get(eventName);
      if (handlers) {
        handlers.delete(handler);

        // If no handlers left, remove the event listener from socket
        if (handlers.size === 0) {
          this.eventHandlers.delete(eventName);
          this.socket?.off(eventName);
        }
      }
    } else {
      // Remove all handlers for this event
      this.eventHandlers.delete(eventName);
      this.socket?.off(eventName);
    }
  }

  /**
   * Emit an event to the server
   */
  public emit(
    eventName: string,
    data?: any,
    callback?: (response: any) => void
  ): void {
    if (!this.socket || !this.socket.connected) {
      return;
    }

    if (callback) {
      this.socket.emit(eventName, data, callback);
    } else {
      this.socket.emit(eventName, data);
    }
  }

  /**
   * Shutdown due to authentication failure
   */
  private shutdown(): void {
    logger.error(
      "CRITICAL: Authentication failed - shutting down server",
      "SOCKET_MANAGER"
    );
    this.cleanup();

    // Give some time for cleanup and logging
    setTimeout(() => {
      // process.exit(0);
    }, 2000);
  }

  /**
   * Clean up resources
   */
  public cleanup(): void {
    if (this.connectionTimeout) {
      clearTimeout(this.connectionTimeout);
      this.connectionTimeout = null;
    }

    // Clean up console manager
    const consoleManager = ConsoleManager.getInstance();
    consoleManager.cleanup();

    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }

    this.eventHandlers.clear();
    this.authenticated = false;
  }

  /**
   * Check if the socket is authenticated
   */
  public isAuthenticated(): boolean {
    return this.authenticated && this.socket?.connected === true;
  }

  /**
   * Check if the socket is connected
   */
  public isConnected(): boolean {
    return this.socket?.connected === true;
  }

  /**
   * Get the socket instance for direct access if needed
   */
  public getSocket(): Socket | null {
    return this.socket;
  }
}
