import { logger } from "@shared/utils/logger";
import { SocketManager } from "./socket-manager";

export class ConsoleManager {
  private static instance: ConsoleManager;
  private isConnected = false;
  private outputBuffer: string[] = [];
  private maxBufferSize = 1000; // Maximum lines to buffer
  private flushInterval: NodeJS.Timeout | null = null;
  private rateLimitMap = new Map<string, number>();
  private lastFlush = 0;
  private minFlushInterval = 100; // Minimum 100ms between flushes

  private constructor() {
    this.setupConsoleCapture();
  }

  public static getInstance(): ConsoleManager {
    if (!ConsoleManager.instance) {
      ConsoleManager.instance = new ConsoleManager();
    }
    return ConsoleManager.instance;
  }

  /**
   * Set up console output capture using FiveM's native functions
   */
  private setupConsoleCapture(): void {
    // Set up regular flushing (every 1 second to avoid spam)
    this.flushInterval = setInterval(() => {
      this.flushBuffer();
    }, 1000); // Flush every 1 second
  }

  /**
   * Start capturing console output using FiveM natives
   */
  private startNativeConsoleCapture(): void {
    try {
      RegisterConsoleListener((channel: string, message: string) => {
        this.captureOutput(`[${channel}] ${message}`);
      });
    } catch (error) {
      logger.error(`Failed to initialize console capture: ${error}`, "CONSOLE_MANAGER");
    }
  }

  /**
   * Capture a line of output
   */
  private captureOutput(output: string): void {
    if (!output || output.trim().length === 0) return;

    // Rate limiting per unique output line (more lenient since we buffer for 1 second)
    const now = Date.now();
    const rateLimitKey = output.slice(0, 50); // Use first 50 chars as key
    const lastSeen = this.rateLimitMap.get(rateLimitKey) || 0;
    
    // If same output was seen less than 500ms ago, skip it (reduced from 1000ms)
    if (now - lastSeen < 500) {
      return;
    }
    this.rateLimitMap.set(rateLimitKey, now);

    // Clean up old rate limit entries (keep last 5 minutes)
    if (this.rateLimitMap.size > 1000) {
      for (const [key, timestamp] of this.rateLimitMap.entries()) {
        if (now - timestamp > 300000) { // 5 minutes
          this.rateLimitMap.delete(key);
        }
      }
    }

    // Add to buffer
    this.outputBuffer.push(output);

    // Prevent buffer overflow
    if (this.outputBuffer.length > this.maxBufferSize) {
      this.outputBuffer = this.outputBuffer.slice(-this.maxBufferSize + 100);
    }

    // Flush immediately for errors, warnings, or if buffer is getting full
    if (output.includes('^1') || output.includes('^3') || this.outputBuffer.length >= 10) {
      this.flushBuffer();
    }
  }

  /**
   * Flush the output buffer to the socket
   */
  private flushBuffer(): void {
    if (this.outputBuffer.length === 0 || !this.isConnected) return;

    const now = Date.now();
    if (now - this.lastFlush < this.minFlushInterval) return;

    const socketManager = SocketManager.getInstance();
    if (!socketManager.isAuthenticated()) return;

    // Send all buffered output as one message
    const output = this.outputBuffer.join('\n');
    this.outputBuffer = [];
    this.lastFlush = now;

    try {
      socketManager.emit("console:output", { output });
    } catch (error) {
      logger.error(`Failed to send console output: ${error}`, "CONSOLE_MANAGER");
    }
  }

  /**
   * Handle console connection status
   */
  public handleConsoleConnected(): void {
    if (this.isConnected) {
      const socketManager = SocketManager.getInstance();
      if (socketManager.isAuthenticated()) {
        socketManager.emit("console:connected", {});
      }
      return;
    }

    this.isConnected = true;
    
    // Start native console capture
    this.startNativeConsoleCapture();

    // Small delay to ensure server is properly registered in rooms
    setTimeout(() => {
      const socketManager = SocketManager.getInstance();
      if (socketManager.isAuthenticated()) {
        socketManager.emit("console:connected", {});
      }
    }, 100);
  }

  /**
   * Handle console disconnection
   */
  public handleConsoleDisconnected(_reason?: string): void {
    // Don't actually disconnect console capture, just log it
    // The console should stay active as long as the server is running
    
    // Don't send disconnected event or set isConnected to false
    // This allows the console to continue capturing for other potential subscribers
  }

  /**
   * Execute a console command
   */
  public executeCommand(username: string, command: string): void {
    try {
      ExecuteCommand(command);
      
      // Send success result
      const socketManager = SocketManager.getInstance();
      socketManager.emit("console:command_result", {
        command,
        success: true,
        output: `${username} executed command: ${command}`
      });
      
    } catch (error) {
      logger.error(`Failed to execute command '${command}': ${error}`, "CONSOLE_MANAGER");
    }
  }

  /**
   * Clean up resources
   */
  public cleanup(): void {
    this.isConnected = false;
    
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
      this.flushInterval = null;
    }

    // Final flush
    this.flushBuffer();
    
    this.outputBuffer = [];
    this.rateLimitMap.clear();
  }
} 